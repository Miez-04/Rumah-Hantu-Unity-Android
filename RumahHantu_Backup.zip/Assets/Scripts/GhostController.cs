using UnityEngine;

// The player. One finger to fly around, then you control the object you possess:
//  - tap empty space (or drag): the ghost floats there (it passes through walls, it has no collider)
//  - tap a Possessable: the ghost flies in and possesses it
//  - while possessed: on-screen buttons (TouchPad) to move, jump, use the object's special power, or leave (KELUAR)
public class GhostController : MonoBehaviour
{
    public static GhostController Instance { get; private set; }

    [Header("References")]
    public Transform visual;          // child with SpriteRenderer + SpriteSheetAnimator
    public LayerMask furnitureMask;   // the Furniture layer
    public Camera cam;

    [Header("Movement")]
    public float moveSpeed = 8f;
    public float bobHeight = 0.12f;
    [Tooltip("How generous touches are when picking furniture (world units).")]
    public float pickRadius = 0.5f;

    [Header("Energy (spent by special powers)")]
    public float maxEnergy = 100f;
    public float regenPerSecond = 6f;

    public float Energy { get; private set; }
    public float Energy01 { get { return maxEnergy > 0f ? Energy / maxEnergy : 0f; } }
    public bool IsPossessing { get { return inside && possessed != null; } }

    SpriteRenderer sr;
    SpriteSheetAnimator anim;
    TouchPad pad;
    Possessable possessed;
    Possessable approaching;
    bool inside;
    bool swallow; // ignore the finger that is still down after pressing KELUAR
    Vector2 goal;

    void Awake()
    {
        Instance = this;
        Energy = maxEnergy;
        goal = transform.position;
        if (cam == null) cam = Camera.main;
        if (visual == null && transform.childCount > 0) visual = transform.GetChild(0);
        if (visual != null)
        {
            sr = visual.GetComponent<SpriteRenderer>();
            anim = visual.GetComponent<SpriteSheetAnimator>();
        }
        pad = GetComponent<TouchPad>();
        if (pad == null) pad = gameObject.AddComponent<TouchPad>();
    }

    void Start()
    {
        if (anim != null && anim.Load("Sprites/ghost"))
        {
            anim.Define("float", 0, 4, 6f);
            anim.Define("possess", 4, 1, 1f);
            anim.Play("float");
        }
    }

    void Update()
    {
        bool playing = GameManager.Instance == null || GameManager.Instance.State == GameState.Playing;
        float dt = Time.deltaTime;

        if (playing) HandleInput();
        else ExitPossession();

        // the possessed object was smashed
        if (inside && possessed == null) ExitPossession();

        if (pad != null)
        {
            pad.Visible = playing && inside && possessed != null;
            if (pad.Visible) pad.ActionLabel = possessed.SpecialLabel + "\n(" + Mathf.RoundToInt(possessed.specialEnergy) + ")";
        }

        Vector2 pos = transform.position;
        Vector2 target = goal;
        if (inside) target = possessed.transform.position;
        else if (approaching != null) target = approaching.transform.position;

        Vector2 next = inside
            ? Vector2.Lerp(pos, target, 1f - Mathf.Exp(-14f * dt))
            : Vector2.MoveTowards(pos, target, moveSpeed * dt);
        transform.position = new Vector3(next.x, next.y, 0f);

        if (!inside && approaching != null && Vector2.Distance(next, target) < 0.8f)
            EnterPossession(approaching);

        float dx = target.x - pos.x;
        if (sr != null)
        {
            sr.enabled = !inside; // the ghost is inside the object
            if (Mathf.Abs(dx) > 0.05f) sr.flipX = dx < 0f;
        }
        if (visual != null) visual.localPosition = new Vector3(0f, Mathf.Sin(Time.time * 3f) * bobHeight, 0f);
        if (anim != null) anim.Play(inside ? "possess" : "float");

        Energy = Mathf.Min(maxEnergy, Energy + regenPerSecond * dt);
    }

    void HandleInput()
    {
        if (cam == null) return;

        if (swallow)
        {
            if (!Input.GetMouseButton(0) && Input.touchCount == 0) swallow = false;
            return;
        }

        // while possessing, all input goes to the TouchPad (move / jump / special / KELUAR)
        if (inside)
        {
            if (pad != null && pad.ExitDown)
            {
                ExitPossession();
                swallow = true;
            }
            return;
        }

        Vector2 wp = cam.ScreenToWorldPoint(Input.mousePosition);

        if (Input.GetMouseButtonDown(0))
        {
            Possessable p = PickPossessable(wp);
            if (p != null)
            {
                approaching = p;
            }
            else
            {
                approaching = null;
                goal = wp;
            }
        }
        else if (Input.GetMouseButton(0) && approaching == null)
        {
            goal = wp; // drag to steer
        }
    }

    Possessable PickPossessable(Vector2 wp)
    {
        Collider2D[] cols = Physics2D.OverlapCircleAll(wp, pickRadius, furnitureMask);
        Possessable best = null;
        float bestD = float.MaxValue;
        foreach (Collider2D c in cols)
        {
            Possessable q = c.GetComponentInParent<Possessable>();
            if (q == null) continue;
            float d = Vector2.Distance(c.ClosestPoint(wp), wp);
            if (d < bestD)
            {
                bestD = d;
                best = q;
            }
        }
        return best;
    }

    void EnterPossession(Possessable p)
    {
        possessed = p;
        approaching = null;
        inside = true;
        p.BeginPossess();
    }

    void ExitPossession()
    {
        if (possessed != null) possessed.EndPossession();
        possessed = null;
        inside = false;
        goal = transform.position;
    }

    // Called when the possessed object is destroyed.
    public void ForceRelease()
    {
        ExitPossession();
    }

    public bool TrySpend(float amount)
    {
        if (Energy < amount) return false;
        Energy -= amount;
        return true;
    }

    public void Spend(float amount)
    {
        Energy = Mathf.Max(0f, Energy - amount);
    }
}
