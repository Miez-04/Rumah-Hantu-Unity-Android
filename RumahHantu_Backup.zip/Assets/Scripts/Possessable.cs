using System.Collections;
using UnityEngine;

// The big special power of each object (the large button while possessing it).
public enum HauntKind
{
    Stomp,   // jump high and slam down: shockwave + screen shake (table)
    Charge,  // dash forward and bowl guests over (chair)
    Pounce,  // leap forward and crush (couch)
    Topple,  // fall over with a crash, then stand back up (bookshelf)
    Giggle,  // creepy spin and laugh (doll)
    Flash,   // blinding flash and electric buzz (lamp)
    Gong,    // loud gong and shockwave (clock)
    Throw,   // throw itself and smash (vase, bottle, candle)
    Drop     // hanging things fall and smash (mirror, picture, chandelier)
}

// Put this on furniture: Rigidbody2D + Collider2D on the Furniture layer, with a child called "Visual" that holds the SpriteRenderer.
// Flow: tap it -> the ghost flies in -> you control it (move, jump, big special) -> KELUAR to leave.
[RequireComponent(typeof(Rigidbody2D))]
public class Possessable : MonoBehaviour
{
    [Header("Special power (the big button)")]
    public HauntKind special = HauntKind.Stomp;
    public float specialEnergy = 18f;
    public float specialCooldown = 2.5f;
    public float specialScare = 40f;
    public float specialRadius = 9f;

    [Header("Controls")]
    public float moveSpeed = 3.5f;
    public float jumpSpeed = 9f;
    [Tooltip("No legs: hops along instead of walking.")]
    public bool hopWalk = true;
    public Sprite idleSprite;
    [Tooltip("Walking frames (legs moving). Leave empty for objects without legs.")]
    public Sprite[] walkFrames;
    public float walkFps = 9f;
    public Sprite eyesSprite;

    [Header("Behaviour")]
    [Tooltip("Hangs in place (kinematic) until it falls, e.g. chandelier, mirror, pictures.")]
    public bool pinnedUntilPossessed = false;
    public bool breakable = false;
    [Tooltip("Impact speed needed to smash it (thrown or dropped things smash on any real impact).")]
    public float breakSpeed = 8f;
    public int shardCount = 10;
    public string breakSfx = "glass_break";

    [Header("Scare from impacts")]
    public float impactMinSpeed = 4.5f;
    public float impactScare = 2.2f;
    public float smashScare = 30f;

    static readonly Color PossessTint = new Color(0.75f, 0.9f, 1f, 1f);
    static readonly Color DustColor = new Color(0.82f, 0.78f, 0.72f, 0.85f);

    Rigidbody2D rb;
    Collider2D col;
    SpriteRenderer sr;
    SpriteRenderer eyes;
    Transform visual;
    Color baseColor = Color.white;

    bool possessed;
    bool busyColor;
    bool toppling;
    bool slamPending;
    bool breakOnImpact;
    bool lastGrounded;

    float nextSpecial;
    float lastTouched = -99f;
    float phase;
    float facing = 1f;
    float squash;
    float hopReadyTime;
    float chargeUntil;
    float nextDust;
    float slamTime;
    float slamMult = 1f;
    float redEyesUntil;
    float spinRemaining;
    float spinAngle;
    float wobble;

    public bool IsPossessed { get { return possessed; } }

    public string SpecialLabel
    {
        get
        {
            switch (special)
            {
                case HauntKind.Stomp: return "TUMBUK";
                case HauntKind.Charge: return "SERUDUK";
                case HauntKind.Pounce: return "TERKAM";
                case HauntKind.Topple: return "RUNTUH";
                case HauntKind.Giggle: return "KEKEH";
                case HauntKind.Flash: return "KILAT";
                case HauntKind.Gong: return "GONG";
                case HauntKind.Throw: return "BALING";
                case HauntKind.Drop: return "JATUH";
                default: return "KUASA";
            }
        }
    }

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        col = GetComponent<Collider2D>();

        Transform v = transform.Find("Visual");
        sr = v != null ? v.GetComponent<SpriteRenderer>() : GetComponentInChildren<SpriteRenderer>();
        visual = (sr != null && sr.transform != transform) ? sr.transform : null; // never squash the physics root
        if (sr != null)
        {
            baseColor = sr.color;
            if (idleSprite == null) idleSprite = sr.sprite;
        }

        phase = Random.value * 6.28f;
        if (pinnedUntilPossessed) rb.bodyType = RigidbodyType2D.Kinematic;
    }

    bool IsPinned()
    {
        return pinnedUntilPossessed && rb.bodyType == RigidbodyType2D.Kinematic;
    }

    void MakeDynamic()
    {
        if (rb.bodyType != RigidbodyType2D.Dynamic) rb.bodyType = RigidbodyType2D.Dynamic;
    }

    public void BeginPossess()
    {
        possessed = true;
        lastTouched = Time.time;
        if (!IsPinned())
        {
            rb.freezeRotation = true;
            rb.rotation = 0f;
        }
        ShowEyes(true);
        RestoreColor();
        Sfx.Play("moan", 0.6f, Random.Range(0.9f, 1.1f));
    }

    public void EndPossession()
    {
        possessed = false;
        lastTouched = Time.time;
        if (!toppling) rb.freezeRotation = false;
        ShowEyes(false);
        RestoreColor();
    }

    void ShowEyes(bool on)
    {
        if (on && eyes == null && eyesSprite != null)
        {
            GameObject go = new GameObject("Eyes");
            go.transform.SetParent(transform, false);
            eyes = go.AddComponent<SpriteRenderer>();
            eyes.sprite = eyesSprite;
            eyes.sortingOrder = (sr != null ? sr.sortingOrder : 3) + 1;
        }
        if (eyes != null) eyes.enabled = on;
    }

    void UpdateEyes()
    {
        if (eyes == null || col == null) return;
        Bounds b = col.bounds;
        eyes.transform.position = new Vector3(b.center.x, b.min.y + b.size.y * 0.62f, 0f);
        eyes.transform.rotation = Quaternion.identity;
        eyes.transform.localScale = Vector3.one * Mathf.Clamp(b.size.x / 1.4f, 0.8f, 1.8f);
        eyes.color = Time.time < redEyesUntil ? new Color(1f, 0.25f, 0.2f, 1f) : Color.white;
        eyes.enabled = Mathf.Repeat(Time.time + phase, 3.2f) > 0.12f; // blink
    }

    void RestoreColor()
    {
        if (sr != null) sr.color = possessed ? PossessTint : baseColor;
    }

    Vector2 FootPoint()
    {
        if (col == null) return transform.position;
        return new Vector2(col.bounds.center.x, col.bounds.min.y);
    }

    bool IsGrounded()
    {
        if (col == null) return false;
        Bounds b = col.bounds;
        float y = b.min.y + 0.05f;
        float[] xs = { b.center.x, b.min.x + b.size.x * 0.2f, b.max.x - b.size.x * 0.2f };
        foreach (float x in xs)
        {
            RaycastHit2D[] hits = Physics2D.RaycastAll(new Vector2(x, y), Vector2.down, 0.2f);
            foreach (RaycastHit2D hit in hits)
                if (hit.collider != null && hit.collider != col && !hit.collider.isTrigger) return true;
        }
        return false;
    }

    void Update()
    {
        float dt = Time.deltaTime;
        TouchPad pad = TouchPad.Instance;

        if (!possessed || pad == null)
        {
            if (sr != null && !busyColor)
            {
                float g = 0.12f + 0.1f * Mathf.Sin(Time.time * 2f + phase); // soft glow: "you can possess me"
                sr.color = Color.Lerp(baseColor, new Color(0.8f, 0.92f, 1f, baseColor.a), g);
            }
            UpdateVisual(dt, 0f);
            return;
        }

        float h = pad.Horizontal;
        if (Mathf.Abs(h) > 0.1f) facing = Mathf.Sign(h);
        UpdateEyes();

        if (IsPinned())
        {
            if (pad.ActionDown) TrySpecial();
            UpdateVisual(dt, h);
            return;
        }

        lastGrounded = IsGrounded();
        Vector2 v = PhysUtil.GetVelocity(rb);

        if (!toppling)
        {
            if (Time.time < chargeUntil)
            {
                v.x = facing * 13f;
                ChargeHit(dt);
            }
            else
            {
                v.x = Mathf.MoveTowards(v.x, h * moveSpeed, 45f * dt);
            }

            if (pad.JumpDown && lastGrounded)
            {
                v.y = jumpSpeed;
                squash = -0.22f;
                Sfx.Play("hop", 0.5f, Random.Range(0.9f, 1.1f));
            }
            else if (hopWalk && lastGrounded && Mathf.Abs(h) > 0.1f && Time.time >= hopReadyTime)
            {
                v.y = 4.2f;
                hopReadyTime = Time.time + 0.38f;
                squash = -0.12f;
            }
        }

        if (slamPending)
        {
            float since = Time.time - slamTime;
            if (since > 0.12f && v.y < 0f && v.y > -16f) v.y = -16f; // slam down fast after the apex
            if (since > 0.25f && lastGrounded && v.y <= 0.5f)
            {
                slamPending = false;
                Slam();
            }
        }

        PhysUtil.SetVelocity(rb, v);
        if (pad.ActionDown) TrySpecial(); // after the velocity write so the special wins
        UpdateVisual(dt, h);
    }

    void UpdateVisual(float dt, float h)
    {
        if (sr == null) return;

        if (possessed && walkFrames != null && walkFrames.Length > 0 && !IsPinned())
        {
            bool walking = Mathf.Abs(h) > 0.1f && lastGrounded && !toppling;
            sr.sprite = walking ? walkFrames[(int)(Time.time * walkFps) % walkFrames.Length] : idleSprite;
        }
        sr.flipX = facing < 0f;

        squash = Mathf.MoveTowards(squash, 0f, dt * 2.5f);
        if (spinRemaining > 0f)
        {
            float a = Mathf.Min(spinRemaining, 540f * dt);
            spinAngle += a;
            spinRemaining -= a;
            if (spinRemaining <= 0f) spinAngle = 0f;
        }

        float sway = 0f;
        if (IsPinned()) sway = Mathf.Sin(Time.time * (possessed ? 2.5f : 1.5f) + phase) * (possessed ? 5f + 8f * Mathf.Abs(h) : 1.2f);

        if (visual != null)
        {
            visual.localScale = new Vector3(1f + squash, 1f - squash, 1f);
            visual.localRotation = Quaternion.Euler(0f, 0f, wobble + sway + spinAngle);
        }
    }

    // ------------------------------------------------------------ special powers
    void TrySpecial()
    {
        if (Time.time < nextSpecial) return;
        GhostController g = GhostController.Instance;
        if (g == null || !g.TrySpend(specialEnergy)) return;

        nextSpecial = Time.time + specialCooldown;
        lastTouched = Time.time;
        redEyesUntil = Time.time + 0.6f;

        switch (special)
        {
            case HauntKind.Stomp:
                PhysUtil.SetVelocity(rb, new Vector2(PhysUtil.GetVelocity(rb).x, 12f));
                slamPending = true; slamMult = 1f; slamTime = Time.time; squash = -0.3f;
                Sfx.Play("hop", 0.8f, 0.7f);
                break;

            case HauntKind.Pounce:
                PhysUtil.SetVelocity(rb, new Vector2(facing * 7f, 11f));
                slamPending = true; slamMult = 1.4f; slamTime = Time.time; squash = -0.3f;
                Sfx.Play("whoosh", 0.7f, 0.8f);
                break;

            case HauntKind.Charge:
                chargeUntil = Time.time + 0.55f;
                squash = -0.2f;
                Sfx.Play("whoosh", 1f, 1.1f);
                break;

            case HauntKind.Topple:
                StartCoroutine(ToppleRoutine());
                break;

            case HauntKind.Giggle:
                spinRemaining = 360f;
                StartCoroutine(GiggleRoutine());
                Sfx.Play("giggle", 1f, Random.Range(0.95f, 1.1f));
                Noise(ScareKind.Sound, specialScare, specialRadius + 2f);
                break;

            case HauntKind.Flash:
                StartCoroutine(FlickerRoutine());
                Sfx.Play("zap", 1f);
                if (GameManager.Instance != null) GameManager.Instance.FlashScreen(0.8f);
                Fx.Shake(0.2f, 0.08f);
                Noise(ScareKind.Light, specialScare, specialRadius + 3f);
                break;

            case HauntKind.Gong:
                StartCoroutine(ChimeRoutine());
                Sfx.Play("gong", 1f);
                Fx.Ring(transform.position, 10f, new Color(1f, 0.9f, 0.5f, 0.7f), 0.8f);
                Fx.Shake(0.6f, 0.18f);
                Noise(ScareKind.Sound, specialScare, specialRadius + 4f);
                break;

            case HauntKind.Throw:
                rb.freezeRotation = false;
                PhysUtil.SetVelocity(rb, new Vector2(facing * 12f, 6f));
                rb.angularVelocity = -facing * 400f;
                breakOnImpact = true;
                StartCoroutine(RefreezeLater(0.9f));
                Sfx.Play("whoosh", 0.8f, 1.3f);
                Noise(ScareKind.Move, specialScare * 0.5f, specialRadius);
                break;

            case HauntKind.Drop:
                MakeDynamic();
                rb.freezeRotation = false;
                PhysUtil.SetVelocity(rb, new Vector2(0f, -12f)); // slam it down so it really smashes
                rb.angularVelocity = Random.Range(-90f, 90f);
                breakOnImpact = true;
                Sfx.Play("creak", 0.9f);
                Noise(ScareKind.Shake, specialScare * 0.4f, specialRadius);
                break;
        }
    }

    void Slam()
    {
        Vector2 foot = FootPoint();
        Fx.Ring(foot, 5f * slamMult, new Color(1f, 1f, 1f, 0.6f), 0.4f);
        Fx.Burst(foot, 14, DustColor, 5f, 3.5f, 0.8f);
        Fx.Shake(0.35f * slamMult, 0.22f * slamMult);
        Sfx.Play("thud_big", 1f, Random.Range(0.9f, 1.05f));
        Noise(ScareKind.Impact, specialScare * slamMult, specialRadius);
        squash = 0.35f;
    }

    void ChargeHit(float dt)
    {
        if (Time.time >= nextDust)
        {
            nextDust = Time.time + 0.1f;
            Fx.Burst(FootPoint(), 2, DustColor, 2f, 2f, 0.5f);
        }
        if (GameManager.Instance == null) return;

        Vector2 p = transform.position;
        foreach (HumanAI guest in GameManager.Instance.Humans)
        {
            if (guest == null || guest.Current == HumanAI.State.Gone) continue;
            Vector2 gp = guest.transform.position;
            if (Mathf.Abs(gp.y - p.y) > 2f) continue;
            float ahead = (gp.x - p.x) * facing;
            if (ahead < -0.5f || ahead > 2.2f) continue;
            guest.ScareOverTime(ScareKind.Move, 80f, p, dt);
        }
    }

    IEnumerator ToppleRoutine()
    {
        toppling = true;
        rb.freezeRotation = false;
        rb.angularVelocity = -facing * 110f;
        Vector2 v = PhysUtil.GetVelocity(rb);
        v.x += facing * 2.5f;
        PhysUtil.SetVelocity(rb, v);
        Sfx.Play("creak", 1f, 0.8f);
        yield return new WaitForSeconds(0.8f);

        Vector2 p = col != null ? (Vector2)col.bounds.center : (Vector2)transform.position;
        Fx.Shake(0.55f, 0.3f);
        Sfx.Play("crash_big", 1f);
        Fx.Ring(p, 8f, new Color(1f, 0.9f, 0.7f, 0.6f), 0.5f);
        Fx.Burst(p, 18, new Color(0.8f, 0.55f, 0.35f, 1f), 6f, 6f, 1f);
        Noise(ScareKind.Smash, specialScare, specialRadius + 2f);
        yield return new WaitForSeconds(1.4f);

        // stands itself back up (it is haunted, after all)
        float start = rb.rotation;
        float t = 0f;
        while (t < 0.5f)
        {
            t += Time.deltaTime;
            rb.rotation = Mathf.LerpAngle(start, 0f, t / 0.5f);
            yield return null;
        }
        rb.rotation = 0f;
        rb.angularVelocity = 0f;
        rb.freezeRotation = possessed;
        toppling = false;
    }

    IEnumerator GiggleRoutine()
    {
        float t = 0f;
        while (t < 1.1f)
        {
            t += Time.deltaTime;
            wobble = Mathf.Sin(t * 40f) * 14f;
            yield return null;
        }
        wobble = 0f;
    }

    IEnumerator FlickerRoutine()
    {
        busyColor = true;
        for (int i = 0; i < 8; i++)
        {
            if (sr != null) sr.color = (i % 2 == 0) ? new Color(0.25f, 0.25f, 0.3f, 1f) : new Color(1f, 1f, 0.8f, 1f);
            yield return new WaitForSeconds(0.12f);
        }
        busyColor = false;
        RestoreColor();
    }

    IEnumerator ChimeRoutine()
    {
        busyColor = true;
        for (int i = 0; i < 4; i++)
        {
            if (sr != null) sr.color = new Color(1f, 0.95f, 0.5f, 1f);
            yield return new WaitForSeconds(0.15f);
            RestoreColor();
            yield return new WaitForSeconds(0.15f);
        }
        busyColor = false;
        RestoreColor();
    }

    IEnumerator RefreezeLater(float seconds)
    {
        yield return new WaitForSeconds(seconds);
        rb.rotation = 0f;
        rb.angularVelocity = 0f;
        rb.freezeRotation = possessed;
    }

    // ------------------------------------------------------------ impacts and noise
    void OnCollisionEnter2D(Collision2D c)
    {
        float s = c.relativeVelocity.magnitude;
        if (possessed && s > 3f) squash = Mathf.Max(squash, Mathf.Clamp(s / 25f, 0.1f, 0.3f));

        bool wantBreak = breakOnImpact;
        breakOnImpact = false;
        bool active = possessed || wantBreak || Time.time - lastTouched < 4f; // only count objects the ghost touched recently
        if (!active) return;

        if (wantBreak && breakable && s >= 2f)
        {
            Break();
            return;
        }
        if (s < impactMinSpeed) return;

        if (s > 7f) Sfx.Play("thud", Mathf.Clamp01(s / 14f), Random.Range(0.9f, 1.1f));
        Noise(ScareKind.Impact, s * impactScare, 9f);
        if (breakable && s >= breakSpeed) Break();
    }

    void Noise(ScareKind kind, float amount, float radius)
    {
        if (GameManager.Instance == null) return;
        Vector2 p = transform.position;
        foreach (HumanAI guest in GameManager.Instance.Humans)
        {
            if (guest == null || guest.Current == HumanAI.State.Gone) continue;
            Vector2 gp = guest.transform.position;
            float dist = Vector2.Distance(gp, p);
            if (dist > radius) continue;
            float a = amount * Mathf.Lerp(1f, 0.4f, dist / radius);
            if (Mathf.Abs(gp.y - p.y) > 3.5f) a *= 0.5f; // muffled through floors
            guest.ScareEvent(kind, a, p);
        }
    }

    void Break()
    {
        Noise(ScareKind.Smash, smashScare, 11f);
        Sfx.Play(breakSfx, 1f, Random.Range(0.92f, 1.08f));
        Fx.Shake(0.25f + smashScare * 0.004f, 0.08f + smashScare * 0.004f);
        Vector2 p = col != null ? (Vector2)col.bounds.center : (Vector2)transform.position;
        Fx.Burst(p, shardCount, Color.white, 5f, 8f, 1.1f);

        if (possessed && GhostController.Instance != null) GhostController.Instance.ForceRelease();
        Destroy(gameObject);
    }
}
