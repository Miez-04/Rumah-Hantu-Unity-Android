using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public enum GameState { Playing, Won, Lost }

[System.Serializable]
public class LevelConfig
{
    public string title = "Malam";
    public float seconds = 150f;
    public string[] humans = { "biasa", "penakut" }; // penakut | biasa | berani
}

// Night timer, win / lose, spawns the guests, and draws a simple IMGUI HUD (no Canvas needed).
public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }
    public static int LevelIndex = 0;

    [Header("Setup")]
    public GameObject humanPrefab;
    public LevelConfig[] levels = new LevelConfig[]
    {
        new LevelConfig { title = "Malam 1", seconds = 150f, humans = new string[] { "biasa", "penakut" } },
        new LevelConfig { title = "Malam 2", seconds = 150f, humans = new string[] { "biasa", "penakut", "berani" } },
        new LevelConfig { title = "Malam 3", seconds = 160f, humans = new string[] { "penakut", "biasa", "berani", "berani" } },
    };

    public GameState State { get; private set; }
    public List<HumanAI> Humans = new List<HumanAI>();
    public float TimeLeft { get; private set; }
    public int Remaining { get; private set; }
    public int Stars { get; private set; }

    LevelConfig level;
    int registered;
    float flashAlpha;

    void Awake()
    {
        Instance = this;
        State = GameState.Playing;
        Application.targetFrameRate = 60;
        Screen.sleepTimeout = SleepTimeout.NeverSleep;
    }

    void Start()
    {
        if (levels == null || levels.Length == 0)
        {
            Debug.LogError("GameManager: add at least one level.");
            return;
        }
        LevelIndex = Mathf.Clamp(LevelIndex, 0, levels.Length - 1);
        level = levels[LevelIndex];
        TimeLeft = level.seconds;
        SpawnHumans();
    }

    void SpawnHumans()
    {
        if (humanPrefab == null)
        {
            Debug.LogError("GameManager: assign the Human Prefab.");
            return;
        }

        List<WaypointNode> spots = new List<WaypointNode>();
        foreach (WaypointNode n in WaypointNode.All)
            if (n.spawnable && !n.isExit) spots.Add(n);

        if (spots.Count == 0)
        {
            Debug.LogError("GameManager: no spawnable WaypointNodes in the scene.");
            return;
        }

        foreach (string type in level.humans)
        {
            WaypointNode n = spots[Random.Range(0, spots.Count)];
            GameObject go = Instantiate(humanPrefab, n.transform.position, Quaternion.identity);
            HumanAI h = go.GetComponent<HumanAI>();
            if (h != null) h.humanType = type;
        }
    }

    public void Register(HumanAI h)
    {
        if (!Humans.Contains(h))
        {
            Humans.Add(h);
            registered++;
            Remaining++;
        }
    }

    // White screen flash (lamp power). 0..1
    public void FlashScreen(float strength)
    {
        flashAlpha = Mathf.Max(flashAlpha, Mathf.Clamp01(strength));
    }

    public void HumanEvacuated(HumanAI h)
    {
        Remaining = Mathf.Max(0, Remaining - 1);
    }

    void Update()
    {
        flashAlpha = Mathf.MoveTowards(flashAlpha, 0f, Time.deltaTime * 1.8f);
        if (State != GameState.Playing || level == null) return;

        TimeLeft -= Time.deltaTime;
        if (registered > 0 && Remaining <= 0)
        {
            State = GameState.Won;
            float ratio = TimeLeft / Mathf.Max(1f, level.seconds);
            Stars = ratio > 0.5f ? 3 : (ratio > 0.25f ? 2 : 1);
        }
        else if (TimeLeft <= 0f)
        {
            TimeLeft = 0f;
            State = GameState.Lost;
        }
    }

    void Reload()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    void OnGUI()
    {
        float s = Screen.height / 540f;
        GUI.matrix = Matrix4x4.Scale(new Vector3(s, s, 1f));
        float W = Screen.width / s;
        const float H = 540f;
        Texture2D white = Texture2D.whiteTexture;

        if (flashAlpha > 0.01f)
        {
            GUI.color = new Color(1f, 1f, 1f, flashAlpha);
            GUI.DrawTexture(new Rect(0f, 0f, W, H), white);
            GUI.color = Color.white;
        }

        GUIStyle left = new GUIStyle(GUI.skin.label) { fontSize = 22, fontStyle = FontStyle.Bold, alignment = TextAnchor.UpperLeft };
        GUIStyle center = new GUIStyle(left) { alignment = TextAnchor.UpperCenter };
        GUIStyle right = new GUIStyle(left) { alignment = TextAnchor.UpperRight };
        GUIStyle small = new GUIStyle(left) { fontSize = 14 };
        left.normal.textColor = Color.white;
        center.normal.textColor = Color.white;
        right.normal.textColor = Color.white;
        small.normal.textColor = Color.white;

        string title = level != null ? level.title : "";
        int t = Mathf.CeilToInt(TimeLeft);
        string time = (t / 60) + ":" + (t % 60).ToString("00");
        if (TimeLeft < 20f && State == GameState.Playing) center.normal.textColor = new Color(1f, 0.4f, 0.4f);

        GUI.Label(new Rect(12f, 8f, 300f, 34f), title, left);
        GUI.Label(new Rect(W / 2f - 100f, 8f, 200f, 34f), time, center);
        GUI.Label(new Rect(W - 312f, 8f, 300f, 34f), "Tinggal: " + Remaining, right);

        float e = GhostController.Instance != null ? GhostController.Instance.Energy01 : 0f;
        GUI.Label(new Rect(12f, 40f, 240f, 24f), "TENAGA HANTU", small);
        GUI.color = new Color(0f, 0f, 0f, 0.6f);
        GUI.DrawTexture(new Rect(12f, 64f, 224f, 22f), white);
        GUI.color = Color.Lerp(new Color(0.9f, 0.3f, 0.3f), new Color(0.5f, 0.8f, 1f), e);
        GUI.DrawTexture(new Rect(14f, 66f, 220f * e, 18f), white);
        GUI.color = Color.white;

        if (State == GameState.Playing && GhostController.Instance != null && !GhostController.Instance.IsPossessing)
        {
            GUIStyle hint = new GUIStyle(small) { fontSize = 16, alignment = TextAnchor.UpperCenter };
            hint.normal.textColor = new Color(1f, 1f, 1f, 0.85f);
            GUI.Label(new Rect(W / 2f - 380f, H - 30f, 760f, 26f), "Ketuk perabot untuk merasuk dan mengawalnya  |  ketuk ruang kosong untuk terbang", hint);
        }

        if (State == GameState.Playing) return;

        GUI.color = new Color(0f, 0f, 0f, 0.7f);
        GUI.DrawTexture(new Rect(0f, 0f, W, H), white);
        GUI.color = Color.white;

        GUIStyle big = new GUIStyle(center) { fontSize = 56 };
        big.normal.textColor = Color.white;
        GUIStyle mid = new GUIStyle(center) { fontSize = 26 };
        mid.normal.textColor = Color.white;
        GUI.skin.button.fontSize = 24;

        bool won = State == GameState.Won;
        bool lastLevel = levels != null && LevelIndex >= levels.Length - 1;
        GUI.Label(new Rect(0f, 130f, W, 80f), won ? (lastLevel ? "TAMAT. TERIMA KASIH!" : "BERJAYA!") : "MASA TAMAT", big);
        if (won) GUI.Label(new Rect(0f, 215f, W, 40f), "Bintang: " + Stars + " / 3", mid);

        string caption = won ? (lastLevel ? "Main Semula" : "Malam Seterusnya") : "Cuba Lagi";
        if (GUI.Button(new Rect(W / 2f - 130f, 300f, 260f, 60f), caption))
        {
            if (won) LevelIndex = lastLevel ? 0 : LevelIndex + 1;
            Reload();
        }
    }
}
