using UnityEngine;

// On-screen controls shown while the ghost is inside an object. Multi-touch aware (move + jump at the same time),
// and the same actions work from the keyboard in the Editor: A/D or arrows, Space, E, Q.
[DefaultExecutionOrder(-50)]
public class TouchPad : MonoBehaviour
{
    public static TouchPad Instance { get; private set; }

    [System.NonSerialized] public bool Visible;
    [System.NonSerialized] public string ActionLabel = "KUASA";

    public float Horizontal { get; private set; }
    public bool JumpDown { get; private set; }
    public bool ActionDown { get; private set; }
    public bool ExitDown { get; private set; }

    bool prevJump, prevAction, prevExit;
    bool dLeft, dRight, dJump, dAction, dExit; // for drawing
    Rect leftR, rightR, jumpR, actionR, exitR;

    void Awake()
    {
        Instance = this;
    }

    void Layout(float w)
    {
        const float H = 540f;
        leftR = new Rect(20f, H - 140f, 110f, 120f);
        rightR = new Rect(140f, H - 140f, 110f, 120f);
        jumpR = new Rect(w - 300f, H - 130f, 125f, 110f);
        actionR = new Rect(w - 165f, H - 160f, 145f, 140f);
        exitR = new Rect(w - 130f, 56f, 110f, 46f);
    }

    void Update()
    {
        JumpDown = false;
        ActionDown = false;
        ExitDown = false;
        Horizontal = 0f;
        dLeft = dRight = dJump = dAction = dExit = false;

        if (!Visible)
        {
            prevJump = prevAction = prevExit = true; // swallow the press that was held when it appeared
            return;
        }

        bool left = false, right = false, jump = false, action = false, exit = false;

        if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow)) left = true;
        if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow)) right = true;
        if (Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow)) jump = true;
        if (Input.GetKey(KeyCode.E) || Input.GetKey(KeyCode.J)) action = true;
        if (Input.GetKey(KeyCode.Q)) exit = true;

        float s = Screen.height / 540f;
        Layout(Screen.width / s);

        int n = Input.touchCount;
        if (n > 0)
        {
            for (int i = 0; i < n; i++)
            {
                Touch t = Input.GetTouch(i);
                if (t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled) continue;
                Check(t.position, s, ref left, ref right, ref jump, ref action, ref exit);
            }
        }
        else if (Input.GetMouseButton(0))
        {
            Check(Input.mousePosition, s, ref left, ref right, ref jump, ref action, ref exit);
        }

        Horizontal = (right ? 1f : 0f) - (left ? 1f : 0f);
        JumpDown = jump && !prevJump;
        ActionDown = action && !prevAction;
        ExitDown = exit && !prevExit;
        prevJump = jump;
        prevAction = action;
        prevExit = exit;

        dLeft = left; dRight = right; dJump = jump; dAction = action; dExit = exit;
    }

    void Check(Vector2 screenPos, float s, ref bool left, ref bool right, ref bool jump, ref bool action, ref bool exit)
    {
        Vector2 g = new Vector2(screenPos.x / s, (Screen.height - screenPos.y) / s);
        if (leftR.Contains(g)) left = true;
        else if (rightR.Contains(g)) right = true;
        else if (jumpR.Contains(g)) jump = true;
        else if (actionR.Contains(g)) action = true;
        else if (exitR.Contains(g)) exit = true;
    }

    void OnGUI()
    {
        if (!Visible) return;
        float s = Screen.height / 540f;
        GUI.matrix = Matrix4x4.Scale(new Vector3(s, s, 1f));
        Layout(Screen.width / s);

        Draw(leftR, "<", dLeft, 40);
        Draw(rightR, ">", dRight, 40);
        Draw(jumpR, "LOMPAT", dJump, 22);
        Draw(actionR, ActionLabel, dAction, 24);
        Draw(exitR, "KELUAR", dExit, 18);
    }

    void Draw(Rect r, string label, bool down, int size)
    {
        GUI.color = new Color(0f, 0f, 0f, down ? 0.7f : 0.4f);
        GUI.DrawTexture(r, Texture2D.whiteTexture);
        GUI.color = Color.white;
        GUIStyle st = new GUIStyle(GUI.skin.label) { alignment = TextAnchor.MiddleCenter, fontSize = size, fontStyle = FontStyle.Bold, wordWrap = true };
        st.normal.textColor = down ? new Color(1f, 0.95f, 0.5f) : Color.white;
        GUI.Label(r, label, st);
    }
}
