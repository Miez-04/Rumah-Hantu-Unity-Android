using System.Collections.Generic;
using UnityEngine;

// Plays sound effects from Assets/Resources/Sfx/<name>.wav (2D, small round-robin pool so pitches do not clash).
public static class Sfx
{
    static AudioSource[] pool;
    static int next;
    static readonly Dictionary<string, AudioClip> cache = new Dictionary<string, AudioClip>();
    static readonly HashSet<string> warned = new HashSet<string>();

    static void EnsurePool()
    {
        if (pool != null && pool.Length > 0 && pool[0] != null) return;
        GameObject go = new GameObject("Sfx");
        Object.DontDestroyOnLoad(go);
        pool = new AudioSource[8];
        for (int i = 0; i < pool.Length; i++)
        {
            pool[i] = go.AddComponent<AudioSource>();
            pool[i].playOnAwake = false;
            pool[i].spatialBlend = 0f;
        }
    }

    public static void Play(string name, float volume = 1f, float pitch = 1f)
    {
        AudioClip clip;
        if (!cache.TryGetValue(name, out clip) || clip == null)
        {
            clip = Resources.Load<AudioClip>("Sfx/" + name);
            cache[name] = clip;
        }
        if (clip == null)
        {
            if (warned.Add(name)) Debug.LogWarning("Sfx: Assets/Resources/Sfx/" + name + ".wav not found.");
            return;
        }

        EnsurePool();
        AudioSource s = pool[next];
        next = (next + 1) % pool.Length;
        s.pitch = pitch;
        s.PlayOneShot(clip, Mathf.Clamp01(volume));
    }
}
