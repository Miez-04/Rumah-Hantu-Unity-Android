#if UNITY_EDITOR
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

// Menu: Ghost > 2 - Populate Level
// Creates furniture, windows, doors, waypoints, the ghost, the human prefab, the GameManager and sets up the camera.
// Running it again deletes and recreates "Level", "Ghost" and "GameManager".
public static class LevelPopulator
{
    struct PropSpec
    {
        public string name;
        public float x, y, mass;
        public bool breakable, pinned, physics;

        public PropSpec(string name, float x, float y, float mass, bool breakable, bool pinned, bool physics)
        {
            this.name = name;
            this.x = x;
            this.y = y;
            this.mass = mass;
            this.breakable = breakable;
            this.pinned = pinned;
            this.physics = physics;
        }
    }

    static PropSpec Phys(string name, float x, float y, float mass, bool breakable = false, bool pinned = false)
    {
        return new PropSpec(name, x, y, mass, breakable, pinned, true);
    }

    static PropSpec Deco(string name, float x, float y)
    {
        return new PropSpec(name, x, y, 0f, false, false, false);
    }

    static readonly PropSpec[] Props = new PropSpec[]
    {
        // decoration (no physics): windows and doors
        Deco("window", 12.06f, 2.875f), Deco("window", 18.06f, 2.875f),
        Deco("window", 4.06f, 9.875f), Deco("window", 12.06f, 9.875f),
        Deco("window", 4.06f, 16.875f), Deco("window", 19.06f, 16.875f),
        Deco("door_closed", 21.81f, 1f), Deco("door_closed", 21.81f, 15f),
        // ground floor (surface y = 1)
        Phys("grandfather_clock", 1.56f, 1f, 10f),
        Phys("couch", 12.56f, 1f, 8f),
        Phys("doll", 12.375f, 2.31f, 1f),
        Phys("table", 18.06f, 1f, 4f),
        Phys("vase", 18.1f, 2.3f, 0.5f, true),
        Phys("chair", 20.56f, 1f, 2f),
        // middle floor (surface y = 8)
        Phys("bookshelf", 2.06f, 8f, 12f),
        Phys("picture_frame", 5.56f, 11.375f, 0.5f, false, true),
        Phys("picture_frame", 9.56f, 11.375f, 0.5f, false, true),
        Phys("mirror", 12.56f, 8.81f, 2f, true, true),
        Phys("floor_lamp", 14.44f, 8f, 2f, true),
        Phys("grandfather_clock", 21.56f, 8f, 10f),
        // top floor (surface y = 15)
        Phys("chandelier", 10.06f, 18.75f, 3f, true, true),
        Phys("table", 12.06f, 15f, 4f),
        Phys("vase", 12.375f, 16.125f, 0.5f, true),
        Phys("chair", 14.56f, 15f, 2f),
        Phys("candle", 6.22f, 15f, 0.2f),
        Phys("bottle", 7.22f, 15f, 0.3f, true),
        Phys("picture_frame", 6.56f, 18.375f, 0.5f, false, true),
    };

    struct NodeSpec
    {
        public string name;
        public float x, y;
        public bool exit, spawn;

        public NodeSpec(string name, float x, float y, bool exit, bool spawn)
        {
            this.name = name;
            this.x = x;
            this.y = y;
            this.exit = exit;
            this.spawn = spawn;
        }
    }

    static readonly NodeSpec[] Nodes = new NodeSpec[]
    {
        // ground floor (surface y = 1)
        new NodeSpec("G_A_Bot", 3f, 1f, false, false),
        new NodeSpec("G1", 8f, 1f, false, true),
        new NodeSpec("G2", 13f, 1f, false, true),
        new NodeSpec("G3", 17.5f, 1f, false, true),
        new NodeSpec("G_Exit", 21f, 1f, true, false),
        // middle floor (surface y = 8)
        new NodeSpec("M_A_Top", 10f, 8f, false, false),
        new NodeSpec("M1", 14f, 8f, false, true),
        new NodeSpec("M2", 17.5f, 8f, false, true),
        new NodeSpec("M_B_Bot", 21f, 8f, false, false),
        // top floor (surface y = 15)
        new NodeSpec("T_B_Top", 14f, 15f, false, false),
        new NodeSpec("T1", 3f, 15f, false, true),
        new NodeSpec("T2", 7.5f, 15f, false, true),
        new NodeSpec("T3", 11f, 15f, false, true),
    };

    [MenuItem("Ghost/2 - Populate Level (props, waypoints, ghost, camera, manager)")]
    public static void Populate()
    {
        int furnitureLayer = EnsureLayer("Furniture");
        if (furnitureLayer < 0) return;

        DestroyIfExists("Level");
        DestroyIfExists("Ghost");
        DestroyIfExists("GameManager");

        GameObject root = new GameObject("Level");

        // ---- props ----
        Transform propsRoot = new GameObject("Props").transform;
        propsRoot.SetParent(root.transform, false);
        Sprite eyesSprite = LoadPropSprite("eyes");
        foreach (PropSpec p in Props)
        {
            Sprite sp = LoadPropSprite(p.name);
            if (sp == null)
            {
                Debug.LogWarning("LevelPopulator: sprite '" + p.name + "' not found. Put the props PNGs in Assets/Art/Props/.");
                continue;
            }

            GameObject go = new GameObject(p.name);
            go.transform.SetParent(propsRoot, false);
            go.transform.position = new Vector3(p.x, p.y, 0f);

            if (!p.physics)
            {
                SpriteRenderer dsr = go.AddComponent<SpriteRenderer>();
                dsr.sprite = sp;
                dsr.sortingOrder = 1;
                continue;
            }

            go.layer = furnitureLayer;

            // the sprite lives on a child so it can squash, stretch and wobble without touching the physics collider
            GameObject vis = new GameObject("Visual");
            vis.transform.SetParent(go.transform, false);
            SpriteRenderer sr = vis.AddComponent<SpriteRenderer>();
            sr.sprite = sp;
            sr.sortingOrder = 3;

            Rigidbody2D rb = go.AddComponent<Rigidbody2D>();
            rb.mass = p.mass;
            rb.gravityScale = 2f;
            rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
            rb.interpolation = RigidbodyInterpolation2D.Interpolate;

            BoxCollider2D box = go.AddComponent<BoxCollider2D>();
            box.size = sp.bounds.size;
            box.offset = sp.bounds.center;

            Rig rig = RigFor(p.name);
            Possessable po = go.AddComponent<Possessable>();
            po.pinnedUntilPossessed = p.pinned;
            po.breakable = p.breakable || p.pinned;
            po.special = rig.special;
            po.specialEnergy = rig.energy;
            po.moveSpeed = rig.speed;
            po.jumpSpeed = rig.jump;
            po.hopWalk = rig.hop;
            po.breakSpeed = rig.breakSpeed;
            po.shardCount = rig.shards;
            po.breakSfx = rig.breakSfx;
            po.idleSprite = sp;
            po.walkFrames = LoadWalkFrames(p.name);
            po.eyesSprite = eyesSprite;
        }

        // ---- waypoints ----
        Transform wpRoot = new GameObject("Waypoints").transform;
        wpRoot.SetParent(root.transform, false);
        Dictionary<string, WaypointNode> nodes = new Dictionary<string, WaypointNode>();
        foreach (NodeSpec n in Nodes)
        {
            GameObject g = new GameObject(n.name);
            g.transform.SetParent(wpRoot, false);
            g.transform.position = new Vector3(n.x, n.y, 0f);
            WaypointNode wn = g.AddComponent<WaypointNode>();
            wn.isExit = n.exit;
            wn.spawnable = n.spawn;
            nodes[n.name] = wn;
        }
        nodes["G_A_Bot"].extraLinks = new WaypointNode[] { nodes["M_A_Top"] };
        nodes["M_B_Bot"].extraLinks = new WaypointNode[] { nodes["T_B_Top"] };

        // ---- camera ----
        Camera cam = Camera.main;
        if (cam == null)
        {
            GameObject cg = new GameObject("Main Camera");
            cg.tag = "MainCamera";
            cam = cg.AddComponent<Camera>();
            cg.AddComponent<AudioListener>();
        }
        cam.orthographic = true;
        cam.orthographicSize = 6.75f;
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = new Color(0.055f, 0.063f, 0.14f);
        cam.transform.position = new Vector3(12f, 6.75f, -10f);

        // ---- ghost ----
        GameObject ghost = new GameObject("Ghost");
        ghost.transform.position = new Vector3(16f, 4f, 0f);
        GameObject ghostVis = new GameObject("Visual"); // Ditukar kepada ghostVis
        ghostVis.transform.SetParent(ghost.transform, false);
        SpriteRenderer gsr = ghostVis.AddComponent<SpriteRenderer>();
        gsr.sortingOrder = 10;
        ghostVis.AddComponent<SpriteSheetAnimator>();
        GhostController gc = ghost.AddComponent<GhostController>();
        gc.visual = ghostVis.transform; // Dikemaskini di sini
        gc.furnitureMask = 1 << furnitureLayer;
        gc.cam = cam;

        CameraFollow2D follow = cam.GetComponent<CameraFollow2D>();
        if (follow == null) follow = cam.gameObject.AddComponent<CameraFollow2D>();
        follow.target = ghost.transform;
        follow.fixedX = 12f;
        follow.minY = 6.75f;
        follow.maxY = 15.25f;
        follow.orthographicSize = 6.75f;

        // ---- human prefab + game manager ----
        if (!AssetDatabase.IsValidFolder("Assets/Prefabs")) AssetDatabase.CreateFolder("Assets", "Prefabs");
        GameObject human = new GameObject("Human");
        SpriteRenderer hsr = human.AddComponent<SpriteRenderer>();
        hsr.sortingOrder = 5;
        human.AddComponent<SpriteSheetAnimator>();
        human.AddComponent<HumanAI>();
        GameObject prefab = PrefabUtility.SaveAsPrefabAsset(human, "Assets/Prefabs/Human.prefab");
        Object.DestroyImmediate(human);

        GameObject gmGo = new GameObject("GameManager");
        GameManager gm = gmGo.AddComponent<GameManager>();
        gm.humanPrefab = prefab;

        AddSceneToBuildSettings();
        EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
        Debug.Log("LevelPopulator: done. Save the scene (Ctrl+S) and press Play.");
    }

    struct Rig
    {
        public HauntKind special;
        public float energy, speed, jump, breakSpeed;
        public bool hop;
        public int shards;
        public string breakSfx;

        public Rig(HauntKind special, float energy, float speed, float jump, bool hop, float breakSpeed = 8f, int shards = 10, string breakSfx = "glass_break")
        {
            this.special = special;
            this.energy = energy;
            this.speed = speed;
            this.jump = jump;
            this.hop = hop;
            this.breakSpeed = breakSpeed;
            this.shards = shards;
            this.breakSfx = breakSfx;
        }
    }

    static Rig RigFor(string n)
    {
        switch (n)
        {
            case "table": return new Rig(HauntKind.Stomp, 20f, 3.2f, 9f, false);
            case "chair": return new Rig(HauntKind.Charge, 15f, 5f, 9.5f, false);
            case "couch": return new Rig(HauntKind.Pounce, 22f, 2.4f, 8f, false);
            case "doll": return new Rig(HauntKind.Giggle, 14f, 3.6f, 9f, false);
            case "bookshelf": return new Rig(HauntKind.Topple, 25f, 1.6f, 5f, true);
            case "floor_lamp": return new Rig(HauntKind.Flash, 12f, 3.5f, 9f, true, 9f, 8);
            case "grandfather_clock": return new Rig(HauntKind.Gong, 18f, 2f, 6f, true);
            case "vase": return new Rig(HauntKind.Throw, 8f, 3.5f, 7f, true, 8f, 10);
            case "bottle": return new Rig(HauntKind.Throw, 8f, 4f, 7f, true, 8f, 8);
            case "candle": return new Rig(HauntKind.Throw, 6f, 3.5f, 7f, true);
            case "mirror": return new Rig(HauntKind.Drop, 15f, 0f, 0f, false, 8f, 14);
            case "picture_frame": return new Rig(HauntKind.Drop, 12f, 0f, 0f, false, 8f, 6);
            case "chandelier": return new Rig(HauntKind.Drop, 25f, 0f, 0f, false, 8f, 20, "crash_big");
            default: return new Rig(HauntKind.Stomp, 18f, 3.5f, 9f, true);
        }
    }

    static Sprite[] LoadWalkFrames(string n)
    {
        List<Sprite> frames = new List<Sprite>();
        for (int i = 0; i < 4; i++)
        {
            Sprite f = LoadPropSprite(n + "_walk_" + i);
            if (f != null) frames.Add(f);
        }
        return frames.Count == 4 ? frames.ToArray() : null;
    }

    static void DestroyIfExists(string objName)
    {
        GameObject go = GameObject.Find(objName);
        while (go != null)
        {
            Object.DestroyImmediate(go);
            go = GameObject.Find(objName);
        }
    }

    static Sprite LoadPropSprite(string spriteName)
    {
        string[] guids = AssetDatabase.FindAssets(spriteName + " t:Texture2D");
        foreach (string g in guids)
        {
            string path = AssetDatabase.GUIDToAssetPath(g);
            if (Path.GetFileNameWithoutExtension(path) != spriteName) continue;
            EnsurePropImport(path);
            return AssetDatabase.LoadAssetAtPath<Sprite>(path);
        }
        return null;
    }

    // Single sprite, 16 PPU, point filter, no compression, pivot at the bottom centre.
    static void EnsurePropImport(string path)
    {
        TextureImporter ti = AssetImporter.GetAtPath(path) as TextureImporter;
        if (ti == null) return;

        TextureImporterSettings s = new TextureImporterSettings();
        ti.ReadTextureSettings(s);
        bool ok = ti.textureType == TextureImporterType.Sprite
                  && ti.spriteImportMode == SpriteImportMode.Single
                  && Mathf.Approximately(ti.spritePixelsPerUnit, 16f)
                  && ti.filterMode == FilterMode.Point
                  && ti.textureCompression == TextureImporterCompression.Uncompressed
                  && s.spriteAlignment == (int)SpriteAlignment.BottomCenter;
        if (ok) return;

        ti.textureType = TextureImporterType.Sprite;
        ti.spriteImportMode = SpriteImportMode.Single;
        ti.spritePixelsPerUnit = 16f;
        ti.filterMode = FilterMode.Point;
        ti.textureCompression = TextureImporterCompression.Uncompressed;
        ti.ReadTextureSettings(s);
        s.spriteAlignment = (int)SpriteAlignment.BottomCenter;
        ti.SetTextureSettings(s);
        ti.SaveAndReimport();
    }

    static int EnsureLayer(string layerName)
    {
        int existing = LayerMask.NameToLayer(layerName);
        if (existing >= 0) return existing;

        Object[] assets = AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/TagManager.asset");
        if (assets == null || assets.Length == 0)
        {
            Debug.LogError("LevelPopulator: could not open TagManager. Create a layer named '" + layerName + "' in Project Settings > Tags and Layers, then run this menu again.");
            return -1;
        }

        SerializedObject tagManager = new SerializedObject(assets[0]);
        SerializedProperty layers = tagManager.FindProperty("layers");
        for (int i = 8; i < layers.arraySize; i++)
        {
            SerializedProperty el = layers.GetArrayElementAtIndex(i);
            if (string.IsNullOrEmpty(el.stringValue))
            {
                el.stringValue = layerName;
                tagManager.ApplyModifiedProperties();
                return i;
            }
        }

        Debug.LogError("LevelPopulator: no free layer slot for '" + layerName + "'. Free one up in Tags and Layers.");
        return -1;
    }

    static void AddSceneToBuildSettings()
    {
        Scene scene = SceneManager.GetActiveScene();
        if (string.IsNullOrEmpty(scene.path))
        {
            Debug.LogWarning("LevelPopulator: the scene is not saved yet. Save it (File > Save As) and add it to Build Settings, or the Retry button will not work.");
            return;
        }

        List<EditorBuildSettingsScene> list = new List<EditorBuildSettingsScene>(EditorBuildSettings.scenes);
        foreach (EditorBuildSettingsScene s in list)
            if (s.path == scene.path) return;
        list.Add(new EditorBuildSettingsScene(scene.path, true));
        EditorBuildSettings.scenes = list.ToArray();
    }
}
#endif
