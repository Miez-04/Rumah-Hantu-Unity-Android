#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Tilemaps;

// Menu: Ghost > 1 - Build Mansion Tilemaps
// Builds the 3-floor mansion from mansion_tileset.png (must be sliced 16x16 first).
// 1 tile = 1 unit. Building: x 0..24, y 0..22. Floor surfaces: y=1 (ground), y=8 (middle), y=15 (top).
public static class MansionBuilder
{
    const string TilesetName = "mansion_tileset";
    const string TileFolder = "Assets/Art/TileAssets";

    [MenuItem("Ghost/1 - Build Mansion Tilemaps")]
    public static void Build()
    {
        Tile[] t = LoadTiles();
        if (t == null) return;

        GameObject gridGo = GameObject.Find("MansionGrid");
        if (gridGo == null)
        {
            gridGo = new GameObject("MansionGrid");
            gridGo.AddComponent<Grid>();
        }
        // the props and waypoints are placed from (0,0), so the grid must sit exactly at the origin
        gridGo.transform.position = Vector3.zero;
        gridGo.transform.rotation = Quaternion.identity;
        gridGo.transform.localScale = Vector3.one;

        Tilemap walls = GetLayer(gridGo.transform, "Walls", 0);
        Tilemap decor = GetLayer(gridGo.transform, "Decor", 1);
        Tilemap solids = GetLayer(gridGo.transform, "Solids", 2);
        walls.ClearAllTiles();
        decor.ClearAllTiles();
        solids.ClearAllTiles();

        // ---- Walls (background) ----
        Fill(walls, t[0], 1, 18, 22, 20); // wallpaper
        Fill(walls, t[0], 1, 11, 22, 13);
        Fill(walls, t[0], 1, 4, 22, 6);
        Fill(walls, t[2], 1, 17, 22, 17); // chair rail
        Fill(walls, t[2], 1, 10, 22, 10);
        Fill(walls, t[2], 1, 3, 22, 3);
        Fill(walls, t[3], 1, 14, 22, 16); // wainscot (also behind the floor slab row)
        Fill(walls, t[3], 1, 7, 22, 9);
        Fill(walls, t[3], 1, 1, 22, 2);
        int[,] damaged = { { 5, 19 }, { 19, 19 }, { 16, 12 }, { 3, 12 }, { 9, 5 }, { 20, 5 } };
        for (int i = 0; i < damaged.GetLength(0); i++)
            walls.SetTile(new Vector3Int(damaged[i, 0], damaged[i, 1], 0), t[1]);

        // ---- Solids (collide) ----
        Fill(solids, t[7], 0, 0, 0, 21);   // brick, left wall
        Fill(solids, t[7], 23, 0, 23, 21); // brick, right wall
        Fill(solids, t[6], 1, 21, 22, 21); // ceiling beam
        int[] slabRows = { 0, 7, 14 };
        foreach (int y in slabRows)
            for (int x = 1; x <= 22; x++)
                solids.SetTile(new Vector3Int(x, y, 0), t[x % 2 == 0 ? 4 : 5]);

        // holes above the stairs
        solids.SetTile(new Vector3Int(7, 7, 0), null);
        solids.SetTile(new Vector3Int(8, 7, 0), null);
        solids.SetTile(new Vector3Int(15, 14, 0), null);
        solids.SetTile(new Vector3Int(16, 14, 0), null);

        // stairs A (ground -> middle, rising to the right, left side) and B (middle -> top, rising to the left, right side)
        for (int i = 0; i < 7; i++)
        {
            solids.SetTile(new Vector3Int(3 + i, 1 + i, 0), t[8]);
            solids.SetTile(new Vector3Int(20 - i, 8 + i, 0), t[9]);
        }

        // ---- Decor (overlays) ----
        int[] topRows = { 20, 13, 6 };
        foreach (int y in topRows)
        {
            for (int x = 1; x <= 22; x++) decor.SetTile(new Vector3Int(x, y, 0), t[15]);
            decor.SetTile(new Vector3Int(1, y, 0), t[13]);
            decor.SetTile(new Vector3Int(22, y, 0), t[14]);
        }

        // dark space under the stairs (semi-transparent so people walking there stay visible)
        Tile dark = GetDarkTile();
        if (dark != null)
        {
            for (int i = 1; i < 7; i++)
            {
                for (int yy = 1; yy <= i; yy++) decor.SetTile(new Vector3Int(3 + i, yy, 0), dark);
                for (int yy = 8; yy <= 7 + i; yy++) decor.SetTile(new Vector3Int(20 - i, yy, 0), dark);
            }
        }

        // ---- Colliders on Solids ----
        if (solids.GetComponent<TilemapCollider2D>() == null) solids.gameObject.AddComponent<TilemapCollider2D>();
        CompositeCollider2D comp = solids.GetComponent<CompositeCollider2D>();
        if (comp == null) comp = solids.gameObject.AddComponent<CompositeCollider2D>();
        comp.geometryType = CompositeCollider2D.GeometryType.Polygons;
        solids.GetComponent<TilemapCollider2D>().usedByComposite = true;
        Rigidbody2D rb = solids.GetComponent<Rigidbody2D>();
        if (rb != null) rb.bodyType = RigidbodyType2D.Static;

        EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
        Selection.activeGameObject = gridGo;
        Debug.Log("MansionBuilder: done. Next: Ghost > 2 - Populate Level.");
    }

    static Tile GetDarkTile()
    {
        const string path = "Assets/Art/dark_tile.png";
        if (!AssetDatabase.IsValidFolder("Assets/Art")) AssetDatabase.CreateFolder("Assets", "Art");
        if (!AssetDatabase.IsValidFolder(TileFolder)) AssetDatabase.CreateFolder("Assets/Art", "TileAssets");

        if (!File.Exists(path))
        {
            Texture2D tex = new Texture2D(16, 16, TextureFormat.RGBA32, false);
            Color32 c = new Color32(22, 16, 28, 170);
            Color32[] px = new Color32[256];
            for (int i = 0; i < px.Length; i++) px[i] = c;
            tex.SetPixels32(px);
            File.WriteAllBytes(path, tex.EncodeToPNG());
            Object.DestroyImmediate(tex);
            AssetDatabase.ImportAsset(path);
        }

        TextureImporter ti = AssetImporter.GetAtPath(path) as TextureImporter;
        if (ti != null && (ti.textureType != TextureImporterType.Sprite || !Mathf.Approximately(ti.spritePixelsPerUnit, 16f)))
        {
            ti.textureType = TextureImporterType.Sprite;
            ti.spriteImportMode = SpriteImportMode.Single;
            ti.spritePixelsPerUnit = 16f;
            ti.filterMode = FilterMode.Point;
            ti.textureCompression = TextureImporterCompression.Uncompressed;
            ti.SaveAndReimport();
        }

        Sprite sp = AssetDatabase.LoadAssetAtPath<Sprite>(path);
        if (sp == null) return null;

        string assetPath = TileFolder + "/tile_dark.asset";
        Tile tile = AssetDatabase.LoadAssetAtPath<Tile>(assetPath);
        if (tile == null)
        {
            tile = ScriptableObject.CreateInstance<Tile>();
            AssetDatabase.CreateAsset(tile, assetPath);
        }
        tile.sprite = sp;
        tile.colliderType = Tile.ColliderType.None;
        EditorUtility.SetDirty(tile);
        return tile;
    }

    static void Fill(Tilemap m, TileBase tile, int x0, int y0, int x1, int y1)
    {
        for (int x = x0; x <= x1; x++)
            for (int y = y0; y <= y1; y++)
                m.SetTile(new Vector3Int(x, y, 0), tile);
    }

    static Tilemap GetLayer(Transform parent, string layerName, int order)
    {
        Transform c = parent.Find(layerName);
        GameObject go;
        if (c == null)
        {
            go = new GameObject(layerName);
            go.transform.SetParent(parent, false);
        }
        else
        {
            go = c.gameObject;
        }

        go.transform.localPosition = Vector3.zero;
        go.transform.localRotation = Quaternion.identity;
        go.transform.localScale = Vector3.one;

        Tilemap tm = go.GetComponent<Tilemap>();
        if (tm == null) tm = go.AddComponent<Tilemap>();
        TilemapRenderer tr = go.GetComponent<TilemapRenderer>();
        if (tr == null) tr = go.AddComponent<TilemapRenderer>();
        tr.sortingOrder = order;
        return tm;
    }

    // Creates Tile assets from the sliced tileset. The index is worked out from where each sprite sits
    // (8 columns x 2 rows, row 0 at the top), so it does not depend on how Unity numbered the slices.
    static Tile[] LoadTiles()
    {
        string texPath = null;
        string[] guids = AssetDatabase.FindAssets(TilesetName + " t:Texture2D");
        foreach (string g in guids)
        {
            string p = AssetDatabase.GUIDToAssetPath(g);
            if (Path.GetFileNameWithoutExtension(p) == TilesetName)
            {
                texPath = p;
                break;
            }
        }
        if (texPath == null)
        {
            Debug.LogError("MansionBuilder: mansion_tileset.png not found. Put it in Assets/Art/Tiles/.");
            return null;
        }

        if (!AssetDatabase.IsValidFolder("Assets/Art")) AssetDatabase.CreateFolder("Assets", "Art");
        if (!AssetDatabase.IsValidFolder(TileFolder)) AssetDatabase.CreateFolder("Assets/Art", "TileAssets");

        Tile[] tiles = new Tile[16];
        Object[] all = AssetDatabase.LoadAllAssetsAtPath(texPath);
        foreach (Object o in all)
        {
            Sprite sp = o as Sprite;
            if (sp == null) continue;
            if (Mathf.RoundToInt(sp.rect.width) != 16 || Mathf.RoundToInt(sp.rect.height) != 16)
            {
                Debug.LogError("MansionBuilder: mansion_tileset.png is not sliced into 16x16 sprites. Use Sprite Editor > Slice > Grid By Cell Size 16 x 16.");
                return null;
            }

            int col = Mathf.RoundToInt(sp.rect.x / 16f);
            int rowFromTop = Mathf.RoundToInt((sp.texture.height - sp.rect.yMax) / 16f);
            int idx = rowFromTop * 8 + col;
            if (idx < 0 || idx > 15) continue;

            string assetPath = TileFolder + "/tile_" + idx + ".asset";
            Tile tile = AssetDatabase.LoadAssetAtPath<Tile>(assetPath);
            if (tile == null)
            {
                tile = ScriptableObject.CreateInstance<Tile>();
                AssetDatabase.CreateAsset(tile, assetPath);
            }
            tile.sprite = sp;
            tile.colliderType = Tile.ColliderType.Sprite;
            EditorUtility.SetDirty(tile);
            tiles[idx] = tile;
        }
        AssetDatabase.SaveAssets();

        for (int i = 0; i < 16; i++)
        {
            if (tiles[i] == null)
            {
                Debug.LogError("MansionBuilder: tile " + i + " is missing. Check the tileset is sliced 16 x 16 (16 sprites).");
                return null;
            }
        }
        return tiles;
    }
}
#endif
