using UnityEngine;

public enum ScareKind { Move = 0, Impact = 1, Smash = 2, Panic = 3, Light = 4, Sound = 5, Shake = 6 }

// One party guest. Wanders between waypoints, builds up fear when the ghost scares them,
// becomes habituated ("kebal") to repeated scares of the same kind, and runs to an exit when afraid enough.
[RequireComponent(typeof(SpriteRenderer))]
[RequireComponent(typeof(SpriteSheetAnimator))]
public class HumanAI : MonoBehaviour
{
    public enum State { Idle, Walk, Frozen, Flee, Gone }

    [Header("Type: penakut | biasa | berani")]
    public string humanType = "biasa";
    [Tooltip("When ticked, the stats below are set from the type. Untick to edit them by hand.")]
    public bool useTypeDefaults = true;

    [Header("Stats")]
    public float walkSpeed = 1.5f;
    public float runSpeed = 4.2f;
    public float fearGain = 1f;
    public float calmPerSecond = 3f;

    [Header("Fear")]
    [Range(0f, 100f)] public float fear;
    public float fleeThreshold = 100f;
    [Tooltip("How much each scare of a kind weakens the next one of that kind.")]
    public float habitPerEvent = 0.25f;
    public float habitPerSecond = 0.05f;

    public State Current { get; private set; }

    SpriteRenderer sr;
    SpriteSheetAnimator anim;
    SpriteRenderer barBg;
    SpriteRenderer barFill;
    SpriteRenderer bubble;

    WaypointNode node;
    System.Collections.Generic.List<WaypointNode> path;
    int pathIndex;
    float idleTimer;
    float freezeTimer;
    bool pendingFlee;
    float lastScare = -99f;
    readonly float[] habit = new float[8];

    void Start()
    {
        sr = GetComponent<SpriteRenderer>();
        anim = GetComponent<SpriteSheetAnimator>();
        if (useTypeDefaults) ApplyType();

        if (anim.Load("Sprites/human_" + humanType))
        {
            anim.Define("idle", 0, 2, 2f);
            anim.Define("walk", 2, 4, 8f);
            anim.Define("scared", 6, 1, 1f);
            anim.Define("run", 7, 4, 12f);
            anim.Play("idle");
        }

        BuildBars();

        node = WaypointNode.Nearest(transform.position);
        if (node != null) transform.position = node.Pos;
        else Debug.LogError("HumanAI: no WaypointNode in the scene. Run Ghost > 2 - Populate Level.");

        idleTimer = Random.Range(0.5f, 2f);
        if (GameManager.Instance != null) GameManager.Instance.Register(this);
    }

    void ApplyType()
    {
        switch (humanType)
        {
            case "penakut": fearGain = 1.4f; calmPerSecond = 1.5f; walkSpeed = 1.2f; runSpeed = 4.8f; break;
            case "berani":  fearGain = 0.6f; calmPerSecond = 5f;   walkSpeed = 1.8f; runSpeed = 3.6f; break;
            default:        fearGain = 1.0f; calmPerSecond = 3f;   walkSpeed = 1.5f; runSpeed = 4.2f; break;
        }
    }

    void BuildBars()
    {
        Sprite white = Sprite.Create(Texture2D.whiteTexture, new Rect(0, 0, 4, 4), new Vector2(0f, 0.5f), 4f);
        barBg = MakeBox("FearBg", white, new Color(0f, 0f, 0f, 0.65f), new Vector3(-0.5f, 2.35f, 0f), 20);
        barBg.transform.localScale = new Vector3(1f, 0.16f, 1f);
        barFill = MakeBox("FearFill", white, Color.green, new Vector3(-0.5f, 2.35f, 0f), 21);
        barFill.transform.localScale = new Vector3(0f, 0.1f, 1f);

        GameObject b = new GameObject("Bubble");
        b.transform.SetParent(transform, false);
        b.transform.localPosition = new Vector3(0f, 3.1f, 0f);
        bubble = b.AddComponent<SpriteRenderer>();
        Sprite[] ex = Resources.LoadAll<Sprite>("Sprites/exclaim");
        if (ex != null && ex.Length > 0) bubble.sprite = ex[0];
        bubble.sortingOrder = 22;
        bubble.enabled = false;
    }

    SpriteRenderer MakeBox(string goName, Sprite s, Color c, Vector3 localPos, int order)
    {
        GameObject go = new GameObject(goName);
        go.transform.SetParent(transform, false);
        go.transform.localPosition = localPos;
        SpriteRenderer r = go.AddComponent<SpriteRenderer>();
        r.sprite = s;
        r.color = c;
        r.sortingOrder = order;
        return r;
    }

    void Update()
    {
        if (Current == State.Gone) return;
        float dt = Time.deltaTime;

        if (Current != State.Flee && Time.time - lastScare > 1.5f)
            fear = Mathf.Max(0f, fear - calmPerSecond * dt);

        switch (Current)
        {
            case State.Idle:
                anim.Play("idle");
                idleTimer -= dt;
                if (idleTimer <= 0f) StartWander();
                break;
            case State.Walk:
                Follow(walkSpeed, "walk");
                break;
            case State.Flee:
                Follow(runSpeed, "run");
                break;
            case State.Frozen:
                anim.Play("scared");
                freezeTimer -= dt;
                if (freezeTimer <= 0f)
                {
                    bool flee = pendingFlee;
                    pendingFlee = false;
                    if (flee) BeginFlee();
                    else
                    {
                        Current = State.Idle;
                        idleTimer = Random.Range(0.5f, 1.5f);
                    }
                }
                break;
        }

        UpdateBars();
    }

    void UpdateBars()
    {
        float f = Mathf.Clamp01(fear / 100f);
        barFill.transform.localScale = new Vector3(f, 0.1f, 1f);
        barFill.color = Color.Lerp(new Color(0.3f, 0.9f, 0.3f), new Color(0.95f, 0.2f, 0.2f), f);
        bool show = fear > 0.5f && Current != State.Gone;
        barBg.enabled = show;
        barFill.enabled = show;
        bubble.enabled = fear >= 50f && Current != State.Gone && bubble.sprite != null;
    }

    void StartWander()
    {
        if (node == null || WaypointNode.All.Count < 2) { idleTimer = 1f; return; }
        WaypointNode target = WaypointNode.All[Random.Range(0, WaypointNode.All.Count)];
        if (target == node || target.isExit) { idleTimer = 0.3f; return; }

        path = WaypointNode.FindPath(node, n => n == target);
        pathIndex = 0;
        if (path == null) { idleTimer = 1f; return; }
        Current = State.Walk;
    }

    void Follow(float speed, string clip)
    {
        if (path == null || pathIndex >= path.Count)
        {
            ArriveAtEnd();
            return;
        }

        anim.Play(clip);
        Vector2 target = path[pathIndex].Pos;
        Vector2 pos = transform.position;
        Vector2 d = target - pos;
        float step = speed * Time.deltaTime;

        if (Mathf.Abs(d.x) > 0.02f) sr.flipX = d.x < 0f; // sprites face right

        if (d.magnitude <= step)
        {
            transform.position = target;
            node = path[pathIndex];
            pathIndex++;
            if (pathIndex >= path.Count) ArriveAtEnd();
        }
        else
        {
            transform.position = pos + d.normalized * step;
        }
    }

    void ArriveAtEnd()
    {
        if (Current == State.Flee && node != null && node.isExit)
        {
            Leave();
            return;
        }
        path = null;
        Current = State.Idle;
        idleTimer = Random.Range(1f, 3f);
    }

    void BeginFlee()
    {
        bool wasFleeing = Current == State.Flee;
        pendingFlee = false;
        path = WaypointNode.FindPath(node, n => n.isExit);
        if (path == null)
        {
            Debug.LogWarning("HumanAI: no path to an Exit waypoint. Check WaypointNode links and that one node has 'Is Exit' ticked.");
            Current = State.Idle;
            idleTimer = 2f;
            return;
        }

        pathIndex = 0;
        if (path.Count > 1 &&
            Vector2.Distance(transform.position, path[1].Pos) < Vector2.Distance(path[0].Pos, path[1].Pos))
            pathIndex = 1; // already past the first node

        Current = State.Flee;
        if (!wasFleeing)
        {
            SpreadPanic();
            if (GhostController.Instance != null) GhostController.Instance.RewardForFlee();
            float pitch = humanType == "penakut" ? 1.25f : (humanType == "berani" ? 0.8f : 1f);
            Sfx.Play("scream", 0.7f, pitch);
        }
    }

    void SpreadPanic()
    {
        if (GameManager.Instance == null) return;
        foreach (HumanAI h in GameManager.Instance.Humans)
        {
            if (h == null || h == this || h.Current == State.Gone) continue;
            if (Mathf.Abs(h.transform.position.y - transform.position.y) > 3.5f) continue;
            if (Vector2.Distance(h.transform.position, transform.position) > 6f) continue;
            h.ScareEvent(ScareKind.Panic, 20f, transform.position);
        }
    }

    void Leave()
    {
        Current = State.Gone;
        sr.enabled = false;
        barBg.enabled = false;
        barFill.enabled = false;
        bubble.enabled = false;
        if (GameManager.Instance != null) GameManager.Instance.HumanEvacuated(this);
    }

    void Freeze(float seconds, bool thenFlee)
    {
        Current = State.Frozen;
        freezeTimer = seconds;
        pendingFlee = pendingFlee || thenFlee;
    }

    void FaceTo(Vector2 from)
    {
        if (Mathf.Abs(from.x - transform.position.x) > 0.1f) sr.flipX = from.x < transform.position.x;
    }

    // One-off scare (a crash, a smash, someone screaming).
    public void ScareEvent(ScareKind kind, float amount, Vector2 from)
    {
        if (Current == State.Gone || Current == State.Flee) return;
        int k = (int)kind;
        float effective = amount * fearGain / (1f + habit[k]);
        habit[k] += habitPerEvent;
        fear = Mathf.Min(100f, fear + effective);
        lastScare = Time.time;
        FaceTo(from);

        if (fear >= fleeThreshold) Freeze(0.45f, true);
        else if (effective >= 6f && Current != State.Frozen)
        {
            Freeze(0.5f, false);
            AudioManager.Play("scare", 0.45f, humanType == "penakut" ? 1.15f : (humanType == "berani" ? 0.9f : 1f));
        }
    }

    // Continuous scare (e.g. a chair floating around near them).
    public void ScareOverTime(ScareKind kind, float perSecond, Vector2 from, float dt)
    {
        if (Current == State.Gone || Current == State.Flee) return;
        int k = (int)kind;
        float effective = perSecond * dt * fearGain / (1f + habit[k]);
        habit[k] += habitPerSecond * dt;
        fear = Mathf.Min(100f, fear + effective);
        lastScare = Time.time;

        if (fear >= fleeThreshold) Freeze(0.45f, true);
    }
}
