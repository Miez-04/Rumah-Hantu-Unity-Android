#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.Events;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

/// <summary>
/// Menu: Ghost > 4 - Build Pause Menu
/// Menambah PauseCanvas (butang jeda + panel jeda) dan objek PauseMenu
/// ke scene yang sedang dibuka (patut scene Main).
/// Selamat dijalankan berulang kali: ia menggantikan versi lama sahaja.
/// </summary>
public static class PauseMenuBuilder
{
    static readonly Color DimColor    = new Color(0f, 0f, 0f, 0.72f);
    static readonly Color BoxColor    = new Color(0.09f, 0.08f, 0.17f, 1f);
    static readonly Color ButtonColor = new Color(0.25f, 0.22f, 0.45f, 1f);
    static readonly Color ButtonHover = new Color(0.38f, 0.34f, 0.65f, 1f);
    static readonly Color ButtonPress = new Color(0.15f, 0.13f, 0.30f, 1f);
    static readonly Color TitleColor  = new Color(0.75f, 0.9f, 1f, 1f);
    static readonly Color TextColor   = new Color(0.9f, 0.92f, 1f, 1f);

    // Kedudukan butang jeda dari penjuru kanan atas (HUD "Tinggal" ada di situ).
    // Ubah nilai Y jika bertindih dengan HUD.
    static readonly Vector2 PauseButtonPos = new Vector2(-40f, -150f);

    [MenuItem("Ghost/4 - Build Pause Menu")]
    public static void Build()
    {
        Scene scene = SceneManager.GetActiveScene();
        if (scene.name == "MainMenu")
        {
            EditorUtility.DisplayDialog("Pause Menu",
                "Buka scene Main (scene permainan) dahulu, kemudian jalankan semula menu ini.", "OK");
            return;
        }

        // Buang versi lama jika ada
        DestroyIfExists("PauseCanvas");
        DestroyIfExists("PauseMenu");

        // ---- EventSystem (jika belum ada) ----
        if (!HasEventSystem())
            new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));

        // ---- Canvas ----
        var canvasGo = new GameObject("PauseCanvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        var canvas = canvasGo.GetComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvas.sortingOrder = 100; // di atas HUD
        var scaler = canvasGo.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);
        scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
        scaler.matchWidthOrHeight = 0.5f;

        // ---- Pengawal ----
        var menuGo = new GameObject("PauseMenu");
        var menu = menuGo.AddComponent<PauseMenu>();
        menu.menuScene = "MainMenu";

        // ---- Butang jeda (kanan atas) ----
        var pauseBtn = MakeButton(canvasGo.transform, "BtnPause", "II", 64, new Vector2(130, 130));
        var prt = pauseBtn.GetComponent<RectTransform>();
        prt.anchorMin = prt.anchorMax = prt.pivot = new Vector2(1f, 1f);
        prt.anchoredPosition = PauseButtonPos;

        // ---- Panel jeda ----
        var panel = new GameObject("PausePanel", typeof(RectTransform), typeof(Image));
        panel.transform.SetParent(canvasGo.transform, false);
        var rt = panel.GetComponent<RectTransform>();
        rt.anchorMin = Vector2.zero;
        rt.anchorMax = Vector2.one;
        rt.offsetMin = rt.offsetMax = Vector2.zero;
        panel.GetComponent<Image>().color = DimColor; // juga menghalang ketukan tembus ke game

        var box = new GameObject("Box", typeof(RectTransform), typeof(Image));
        box.transform.SetParent(panel.transform, false);
        var brt = box.GetComponent<RectTransform>();
        brt.anchorMin = brt.anchorMax = new Vector2(0.5f, 0.5f);
        brt.anchoredPosition = Vector2.zero;
        brt.sizeDelta = new Vector2(700, 720);
        box.GetComponent<Image>().color = BoxColor;

        MakeText(box.transform, "Title", "JEDA", 100, TitleColor, new Vector2(0, 270), new Vector2(600, 130), FontStyle.Bold);

        var btnResume  = MakeButton(box.transform, "BtnResume",  "SAMBUNG",     54, new Vector2(560, 110));
        var btnRestart = MakeButton(box.transform, "BtnRestart", "ULANG",       54, new Vector2(560, 110));
        var btnExit    = MakeButton(box.transform, "BtnExit",    "MENU UTAMA",  54, new Vector2(560, 110));
        SetPos(btnResume,  new Vector2(0, 100));
        SetPos(btnRestart, new Vector2(0, -40));
        SetPos(btnExit,    new Vector2(0, -180));

        // ---- Wayar ----
        menu.pausePanel = panel;
        menu.pauseButton = pauseBtn.gameObject;

        UnityEventTools.AddPersistentListener(pauseBtn.onClick, menu.Pause);
        UnityEventTools.AddPersistentListener(btnResume.onClick, menu.Resume);
        UnityEventTools.AddPersistentListener(btnRestart.onClick, menu.Restart);
        UnityEventTools.AddPersistentListener(btnExit.onClick, menu.ExitToMenu);

        panel.SetActive(false);

        EditorSceneManager.MarkSceneDirty(scene);
        if (!string.IsNullOrEmpty(scene.path)) EditorSceneManager.SaveScene(scene);

        // ---- Pastikan MainMenu ada dalam Build Settings ----
        bool hasMenuScene = false;
        foreach (var s in EditorBuildSettings.scenes)
            if (s.path.EndsWith("MainMenu.unity")) hasMenuScene = true;
        if (!hasMenuScene)
            Debug.LogWarning("Scene MainMenu belum ada dalam Build Settings. Jalankan Ghost > 3 - Build Main Menu dahulu, " +
                             "jika tidak butang MENU UTAMA tak akan berfungsi.");

        Debug.Log("Menu jeda siap dalam scene '" + scene.name + "'. Tekan Play dan klik butang II di kanan atas.");
    }

    // ---------- Pembantu ----------
    static void DestroyIfExists(string name)
    {
        var go = GameObject.Find(name);
        while (go != null)
        {
            Object.DestroyImmediate(go);
            go = GameObject.Find(name);
        }
    }

    static bool HasEventSystem()
    {
#if UNITY_2023_1_OR_NEWER
        return Object.FindFirstObjectByType<EventSystem>() != null;
#else
        return Object.FindObjectOfType<EventSystem>() != null;
#endif
    }

    static Font GetFont()
    {
#if UNITY_2022_2_OR_NEWER
        return Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
#else
        return Resources.GetBuiltinResource<Font>("Arial.ttf");
#endif
    }

    static void SetPos(Button b, Vector2 pos)
    {
        b.GetComponent<RectTransform>().anchoredPosition = pos;
    }

    static Text MakeText(Transform parent, string name, string content, int size, Color color,
                         Vector2 pos, Vector2 boxSize, FontStyle style)
    {
        var go = new GameObject(name, typeof(RectTransform), typeof(Text));
        go.transform.SetParent(parent, false);
        var rt = go.GetComponent<RectTransform>();
        rt.anchorMin = rt.anchorMax = new Vector2(0.5f, 0.5f);
        rt.anchoredPosition = pos;
        rt.sizeDelta = boxSize;
        var t = go.GetComponent<Text>();
        t.font = GetFont();
        t.text = content;
        t.fontSize = size;
        t.fontStyle = style;
        t.color = color;
        t.alignment = TextAnchor.MiddleCenter;
        t.raycastTarget = false;
        return t;
    }

    static Button MakeButton(Transform parent, string name, string label, int fontSize, Vector2 size)
    {
        var go = new GameObject(name, typeof(RectTransform), typeof(Image), typeof(Button));
        go.transform.SetParent(parent, false);
        var rt = go.GetComponent<RectTransform>();
        rt.anchorMin = rt.anchorMax = new Vector2(0.5f, 0.5f);
        rt.sizeDelta = size;

        var img = go.GetComponent<Image>();
        img.color = Color.white;

        var btn = go.GetComponent<Button>();
        btn.targetGraphic = img;
        var colors = btn.colors;
        colors.normalColor = ButtonColor;
        colors.highlightedColor = ButtonHover;
        colors.pressedColor = ButtonPress;
        colors.selectedColor = ButtonColor;
        colors.fadeDuration = 0.08f;
        btn.colors = colors;

        var t = MakeText(go.transform, "Label", label, fontSize, TextColor, Vector2.zero, size, FontStyle.Bold);
        var lrt = t.GetComponent<RectTransform>();
        lrt.anchorMin = Vector2.zero;
        lrt.anchorMax = Vector2.one;
        lrt.offsetMin = lrt.offsetMax = Vector2.zero;
        return btn;
    }
}
#endif
