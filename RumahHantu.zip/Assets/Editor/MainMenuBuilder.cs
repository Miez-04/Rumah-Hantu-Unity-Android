#if UNITY_EDITOR
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.Events;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>
/// Menu: Ghost > 3 - Build Main Menu
/// Mencipta scene Assets/Scenes/MainMenu.unity lengkap dengan UI,
/// dan meletakkannya sebagai scene pertama (index 0) dalam Build Settings.
/// </summary>
public static class MainMenuBuilder
{
    const string MenuScenePath = "Assets/Scenes/MainMenu.unity";
    const string GameScenePath = "Assets/Scenes/Main.unity";

    static readonly Color BgColor      = new Color(0.07f, 0.06f, 0.13f, 1f);
    static readonly Color PanelColor   = new Color(0.07f, 0.06f, 0.13f, 0.97f);
    static readonly Color ButtonColor  = new Color(0.25f, 0.22f, 0.45f, 1f);
    static readonly Color ButtonHover  = new Color(0.38f, 0.34f, 0.65f, 1f);
    static readonly Color ButtonPress  = new Color(0.15f, 0.13f, 0.30f, 1f);
    static readonly Color TitleColor   = new Color(0.75f, 0.9f, 1f, 1f);
    static readonly Color TextColor    = new Color(0.9f, 0.92f, 1f, 1f);

    [MenuItem("Ghost/3 - Build Main Menu")]
    public static void Build()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;

        Directory.CreateDirectory("Assets/Scenes");
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        // ---- Kamera ----
        var camGo = new GameObject("Main Camera");
        camGo.tag = "MainCamera";
        var cam = camGo.AddComponent<Camera>();
        cam.orthographic = true;
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = BgColor;
        camGo.AddComponent<AudioListener>();

        // ---- EventSystem ----
        new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));

        // ---- Canvas ----
        var canvasGo = new GameObject("Canvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        var canvas = canvasGo.GetComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        var scaler = canvasGo.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);
        scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
        scaler.matchWidthOrHeight = 0.5f;

        // ---- Pengawal menu ----
        var menuGo = new GameObject("MainMenu");
        var menu = menuGo.AddComponent<MainMenu>();
        menu.gameScene = "Main";

        // ===== Panel utama =====
        var mainPanel = MakeStretchPanel(canvasGo.transform, "MainPanel", new Color(0, 0, 0, 0));

        MakeText(mainPanel.transform, "Title", "HANTU RUMAH", 150, TitleColor,
                 new Vector2(0, 340), new Vector2(1400, 200), FontStyle.Bold, true);
        MakeText(mainPanel.transform, "Subtitle", "Takutkan semua penghuni keluar sebelum fajar", 44, TextColor,
                 new Vector2(0, 220), new Vector2(1400, 80), FontStyle.Italic, false);

        // Hantu terapung
        var ghostGo = new GameObject("GhostImage", typeof(RectTransform), typeof(Image));
        ghostGo.transform.SetParent(mainPanel.transform, false);
        var ghostRt = ghostGo.GetComponent<RectTransform>();
        ghostRt.anchorMin = ghostRt.anchorMax = new Vector2(0.5f, 0.5f);
        ghostRt.anchoredPosition = new Vector2(-620, 20);
        ghostRt.sizeDelta = new Vector2(360, 360);
        var ghostImg = ghostGo.GetComponent<Image>();
        ghostImg.preserveAspect = true;
        ghostImg.raycastTarget = false;
        var preview = Resources.LoadAll<Sprite>("Sprites/ghost");
        if (preview != null && preview.Length > 0) ghostImg.sprite = preview[0];
        menu.ghostImage = ghostImg;

        var btnPlay = MakeButton(mainPanel.transform, "BtnPlay", "MAIN", new Vector2(150, 60));
        var btnHow  = MakeButton(mainPanel.transform, "BtnHowTo", "CARA MAIN", new Vector2(150, -70));
        var btnSet  = MakeButton(mainPanel.transform, "BtnSettings", "TETAPAN", new Vector2(150, -200));
        var btnQuit = MakeButton(mainPanel.transform, "BtnQuit", "KELUAR", new Vector2(150, -330));

        // ===== Panel cara main =====
        var howPanel = MakeStretchPanel(canvasGo.transform, "HowToPanel", PanelColor);
        MakeText(howPanel.transform, "HowTitle", "CARA MAIN", 90, TitleColor,
                 new Vector2(0, 400), new Vector2(1400, 120), FontStyle.Bold, true);
        string how =
            "Kamu ialah hantu. Takutkan semua manusia keluar dari rumah.\n\n" +
            "1.  Ketuk ruang kosong untuk gerakkan hantu.\n" +
            "2.  Sentuh perabot dan seret untuk merasuknya.\n" +
            "3.  Lepaskan jari untuk membaling perabot.\n" +
            "4.  Hentaman dan kaca pecah menakutkan manusia berdekatan.\n" +
            "5.  Bila bar takut penuh, manusia lari ke pintu keluar.\n\n" +
            "Awas: manusia jadi kebal kalau gangguan yang sama diulang-ulang.\n" +
            "Campurkan seretan, hentaman dan kejutan!\n\n" +
            "MENANG: semua manusia keluar sebelum masa tamat.";
        MakeText(howPanel.transform, "HowBody", how, 46, TextColor,
                 new Vector2(0, 40), new Vector2(1500, 700), FontStyle.Normal, false, TextAnchor.UpperLeft);
        var howBack = MakeButton(howPanel.transform, "BtnBack", "KEMBALI", new Vector2(0, -440));

        // ===== Panel tetapan =====
        var setPanel = MakeStretchPanel(canvasGo.transform, "SettingsPanel", PanelColor);
        MakeText(setPanel.transform, "SetTitle", "TETAPAN", 90, TitleColor,
                 new Vector2(0, 340), new Vector2(1400, 120), FontStyle.Bold, true);
        var btnSound = MakeButton(setPanel.transform, "BtnSound", "Bunyi: HIDUP", new Vector2(0, 100));
        var setBack = MakeButton(setPanel.transform, "BtnBack", "KEMBALI", new Vector2(0, -100));

        // ---- Wayar rujukan ----
        menu.mainPanel = mainPanel;
        menu.howToPanel = howPanel;
        menu.settingsPanel = setPanel;
        menu.soundButtonText = btnSound.GetComponentInChildren<Text>();

        UnityEventTools.AddPersistentListener(btnPlay.onClick, menu.Play);
        UnityEventTools.AddPersistentListener(btnHow.onClick, menu.ShowHowTo);
        UnityEventTools.AddPersistentListener(btnSet.onClick, menu.ShowSettings);
        UnityEventTools.AddPersistentListener(btnQuit.onClick, menu.Quit);
        UnityEventTools.AddPersistentListener(howBack.onClick, menu.ShowMain);
        UnityEventTools.AddPersistentListener(setBack.onClick, menu.ShowMain);
        UnityEventTools.AddPersistentListener(btnSound.onClick, menu.ToggleSound);

        howPanel.SetActive(false);
        setPanel.SetActive(false);

        EditorSceneManager.MarkSceneDirty(scene);
        EditorSceneManager.SaveScene(scene, MenuScenePath);

        SetupBuildSettings();

        Debug.Log("Menu utama siap: " + MenuScenePath + ". Tekan Play untuk uji.");
    }

    // ---------- Build Settings ----------
    static void SetupBuildSettings()
    {
        var list = new List<EditorBuildSettingsScene>();
        list.Add(new EditorBuildSettingsScene(MenuScenePath, true));

        bool hasGame = false;
        foreach (var s in EditorBuildSettings.scenes)
        {
            if (s.path == MenuScenePath) continue;
            if (s.path == GameScenePath) hasGame = true;
            list.Add(s);
        }
        if (!hasGame && File.Exists(GameScenePath))
            list.Add(new EditorBuildSettingsScene(GameScenePath, true));

        EditorBuildSettings.scenes = list.ToArray();
    }

    // ---------- Pembantu UI ----------
    static Font GetFont()
    {
#if UNITY_2022_2_OR_NEWER
        return Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
#else
        return Resources.GetBuiltinResource<Font>("Arial.ttf");
#endif
    }

    static GameObject MakeStretchPanel(Transform parent, string name, Color color)
    {
        var go = new GameObject(name, typeof(RectTransform), typeof(Image));
        go.transform.SetParent(parent, false);
        var rt = go.GetComponent<RectTransform>();
        rt.anchorMin = Vector2.zero;
        rt.anchorMax = Vector2.one;
        rt.offsetMin = rt.offsetMax = Vector2.zero;
        var img = go.GetComponent<Image>();
        img.color = color;
        img.raycastTarget = color.a > 0.01f;
        return go;
    }

    static Text MakeText(Transform parent, string name, string content, int size, Color color,
                         Vector2 pos, Vector2 boxSize, FontStyle style, bool shadow,
                         TextAnchor anchor = TextAnchor.MiddleCenter)
    {
        var go = new GameObject(name, typeof(RectTransform), typeof(Text));
        go.transform.SetParent(parent, false);
        var rt = go.GetComponent<RectTransform>();
        rt.anchorMin = rt.anchorMax = new Vector2(0.5f, 0.5f);
        rt.anchoredPosition = pos;
        rt.sizeDelta = boxSize;
        var t = go.GetComponent<Text>();
        t.font = GetFont();
        t.text = content;
        t.fontSize = size;
        t.fontStyle = style;
        t.color = color;
        t.alignment = anchor;
        t.horizontalOverflow = HorizontalWrapMode.Wrap;
        t.verticalOverflow = VerticalWrapMode.Overflow;
        t.raycastTarget = false;
        if (shadow)
        {
            var sh = go.AddComponent<Shadow>();
            sh.effectColor = new Color(0.3f, 0.5f, 1f, 0.6f);
            sh.effectDistance = new Vector2(4, -4);
        }
        return t;
    }

    static Button MakeButton(Transform parent, string name, string label, Vector2 pos)
    {
        var go = new GameObject(name, typeof(RectTransform), typeof(Image), typeof(Button));
        go.transform.SetParent(parent, false);
        var rt = go.GetComponent<RectTransform>();
        rt.anchorMin = rt.anchorMax = new Vector2(0.5f, 0.5f);
        rt.anchoredPosition = pos;
        rt.sizeDelta = new Vector2(560, 110);

        var img = go.GetComponent<Image>();
        img.color = Color.white;

        var btn = go.GetComponent<Button>();
        btn.targetGraphic = img;
        var colors = btn.colors;
        colors.normalColor = ButtonColor;
        colors.highlightedColor = ButtonHover;
        colors.pressedColor = ButtonPress;
        colors.selectedColor = ButtonColor;
        colors.fadeDuration = 0.08f;
        btn.colors = colors;

        MakeText(go.transform, "Label", label, 54, TextColor, Vector2.zero, new Vector2(540, 100),
                 FontStyle.Bold, false);
        // Label mesti ikut saiz butang
        var lrt = go.transform.Find("Label").GetComponent<RectTransform>();
        lrt.anchorMin = Vector2.zero;
        lrt.anchorMax = Vector2.one;
        lrt.offsetMin = lrt.offsetMax = Vector2.zero;
        return btn;
    }
}
#endif
