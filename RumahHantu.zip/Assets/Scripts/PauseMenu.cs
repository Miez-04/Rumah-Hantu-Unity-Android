using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>
/// Menu jeda dalam game. Dipasang automatik oleh Ghost > 4 - Build Pause Menu.
/// Jeda = Time.timeScale 0, bunyi dijeda, dan input hantu dimatikan.
/// </summary>
public class PauseMenu : MonoBehaviour
{
    [Header("Scene")]
    public string menuScene = "MainMenu";

    [Header("UI")]
    public GameObject pausePanel;
    public GameObject pauseButton;

    public bool IsPaused { get; private set; }

    GhostController ghost;
    bool ghostWasEnabled;

    void Start()
    {
        // Pastikan keadaan bersih bila scene dimuat (contoh selepas Ulang)
        Time.timeScale = 1f;
        AudioListener.pause = false;
        IsPaused = false;
        if (pausePanel != null) pausePanel.SetActive(false);
        if (pauseButton != null) pauseButton.SetActive(true);
    }

    void Update()
    {
        // Butang Back Android (Escape pada PC)
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (IsPaused) Resume(); else Pause();
        }
    }

    void OnApplicationPause(bool paused)
    {
        // Auto-jeda bila pemain tukar app atau ada panggilan masuk
        if (paused && !IsPaused) Pause();
    }

    void OnDestroy()
    {
        // Jangan tinggalkan game dalam keadaan beku
        Time.timeScale = 1f;
        AudioListener.pause = false;
    }

    // ---------- Dipanggil oleh butang ----------

    public void Pause()
    {
        if (IsPaused) return;
        IsPaused = true;

        Time.timeScale = 0f;
        AudioListener.pause = true;

        FindGhost();
        if (ghost != null)
        {
            ghostWasEnabled = ghost.enabled;
            ghost.enabled = false;
        }

        if (pausePanel != null) pausePanel.SetActive(true);
        if (pauseButton != null) pauseButton.SetActive(false);
    }

    public void Resume()
    {
        if (!IsPaused) return;
        IsPaused = false;

        Time.timeScale = 1f;
        AudioListener.pause = false;

        if (ghost != null) ghost.enabled = ghostWasEnabled;

        if (pausePanel != null) pausePanel.SetActive(false);
        if (pauseButton != null) pauseButton.SetActive(true);
    }

    public void Restart()
    {
        Time.timeScale = 1f;
        AudioListener.pause = false;
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    public void ExitToMenu()
    {
        Time.timeScale = 1f;
        AudioListener.pause = false;
        SceneManager.LoadScene(menuScene);
    }

    // ---------- Dalaman ----------

    void FindGhost()
    {
        if (ghost != null) return;
#if UNITY_2023_1_OR_NEWER
        ghost = Object.FindFirstObjectByType<GhostController>();
#else
        ghost = Object.FindObjectOfType<GhostController>();
#endif
    }
}
