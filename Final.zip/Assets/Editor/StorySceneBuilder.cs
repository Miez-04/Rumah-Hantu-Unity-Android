using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

public static class StorySceneBuilder
{
    const string ProloguePath = "Assets/Scenes/Prolog.unity";
    const string EpiloguePath = "Assets/Scenes/Epilog.unity";

    [MenuItem("Ghost/3 - Build Prolog and Epilog Scenes")]
    static void Build()
    {
        if (File.Exists(ProloguePath) || File.Exists(EpiloguePath))
        {
            if (!EditorUtility.DisplayDialog("Overwrite story scenes?",
                "Prolog/Epilog already exist. Continuing recreates them.",
                "Overwrite", "Cancel")) return;
        }
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;

        string previous = EditorSceneManager.GetActiveScene().path;
        if (!AssetDatabase.IsValidFolder("Assets/Scenes")) AssetDatabase.CreateFolder("Assets", "Scenes");

        MakeScene(ProloguePath, "prolog", false, true, "");
        MakeScene(EpiloguePath, "epilog", true, false, "MainMenu");

        // Tambah di HUJUNG sahaja supaya susunan sedia ada (HouseSelector, menu) tak terjejas.
        var list = EditorBuildSettings.scenes.ToList();
        foreach (string p in new[] { ProloguePath, EpiloguePath })
            if (!list.Any(s => s.path == p)) list.Add(new EditorBuildSettingsScene(p, true));
        EditorBuildSettings.scenes = list.ToArray();

        if (!string.IsNullOrEmpty(previous)) EditorSceneManager.OpenScene(previous);
        Debug.Log("Prolog dan Epilog siap dan ditambah ke hujung Build Settings. Teks cerita ada dalam Loc.cs.");
    }

    static void MakeScene(string path, string key, bool dawn, bool once, string next)
    {
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        var camGo = new GameObject("Main Camera");
        camGo.tag = "MainCamera";
        var cam = camGo.AddComponent<Camera>();
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = Color.black;
        cam.orthographic = true;
        camGo.AddComponent<AudioListener>();

        var go = new GameObject("StoryScreen");
        var story = go.AddComponent<StoryScreen>();
        story.storyKey = key;
        story.nextScene = next;
        story.showScene = true;
        story.dawn = dawn;
        story.showOnlyOnce = once;
        story.onceKey = StoryFlow.PrologSeenKey;

        EditorSceneManager.SaveScene(scene, path);
    }

    [MenuItem("Ghost/Reset Prolog Seen")]
    static void ResetSeen()
    {
        StoryFlow.ResetPrologSeen();
        Debug.Log("Prolog akan dipaparkan semula pada permainan seterusnya.");
    }
}
