#if UNITY_EDITOR
using UnityEngine;
using UnityEngine.UI;

/// <summary>Pembantu kongsi untuk MainMenuBuilder dan PauseMenuBuilder (membina UI uGUI dengan tema UiKit).</summary>
public static class UiBuilderKit
{
    public static Font GetFont()
    {
#if UNITY_2022_2_OR_NEWER
        return Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
#else
        return Resources.GetBuiltinResource<Font>("Arial.ttf");
#endif
    }

    public static RectTransform Node(Transform parent, string name)
    {
        GameObject go = new GameObject(name, typeof(RectTransform));
        go.transform.SetParent(parent, false);
        RectTransform rt = go.GetComponent<RectTransform>();
        rt.anchorMin = rt.anchorMax = new Vector2(0.5f, 0.5f);
        rt.anchoredPosition = Vector2.zero;
        return rt;
    }

    public static RectTransform StretchNode(Transform parent, string name)
    {
        RectTransform rt = Node(parent, name);
        rt.anchorMin = Vector2.zero;
        rt.anchorMax = Vector2.one;
        rt.offsetMin = rt.offsetMax = Vector2.zero;
        return rt;
    }

    // Gambar bertema di tengah (kedudukan + saiz)
    public static Image Pic(Transform parent, string name, UiSkin.Kind kind, Color color,
                            Vector2 pos, Vector2 size, int radius = 24, int ring = 3)
    {
        RectTransform rt = Node(parent, name);
        rt.anchoredPosition = pos;
        rt.sizeDelta = size;
        return Skin(rt.gameObject, kind, color, radius, ring);
    }

    // Gambar bertema memenuhi induk
    public static Image StretchPic(Transform parent, string name, UiSkin.Kind kind, Color color,
                                   int radius = 24, int ring = 3)
    {
        RectTransform rt = StretchNode(parent, name);
        return Skin(rt.gameObject, kind, color, radius, ring);
    }

    static Image Skin(GameObject go, UiSkin.Kind kind, Color color, int radius, int ring)
    {
        Image img = go.AddComponent<Image>();
        img.color = color;
        img.raycastTarget = false;
        UiSkin skin = go.AddComponent<UiSkin>();
        skin.kind = kind;
        skin.radius = radius;
        skin.ringThickness = ring;
        return img;
    }

    // Latar kecerunan (atas -> bawah) memenuhi induk
    public static Image Gradient(Transform parent, string name, Color top, Color bottom,
                                 Vector2 anchorMin, Vector2 anchorMax)
    {
        RectTransform rt = StretchNode(parent, name);
        rt.anchorMin = anchorMin;
        rt.anchorMax = anchorMax;
        Image img = rt.gameObject.AddComponent<Image>();
        img.color = Color.white;
        img.raycastTarget = false;
        UiSkin skin = rt.gameObject.AddComponent<UiSkin>();
        skin.kind = UiSkin.Kind.Gradient;
        skin.gradientTop = top;
        skin.gradientBottom = bottom;
        return img;
    }

    // Lapisan gelap memenuhi skrin (juga menghalang ketukan tembus)
    public static Image Dim(Transform parent, string name, Color color)
    {
        RectTransform rt = StretchNode(parent, name);
        Image img = rt.gameObject.AddComponent<Image>();
        img.color = color;
        img.raycastTarget = true;
        return img;
    }

    public static Text Label(Transform parent, string name, string content, int size, Color color,
                             Vector2 pos, Vector2 box, FontStyle style = FontStyle.Bold,
                             TextAnchor anchor = TextAnchor.MiddleCenter, bool outline = false)
    {
        RectTransform rt = Node(parent, name);
        rt.anchoredPosition = pos;
        rt.sizeDelta = box;
        return AddText(rt.gameObject, content, size, color, style, anchor, outline);
    }

    static Text AddText(GameObject go, string content, int size, Color color, FontStyle style, TextAnchor anchor, bool outline)
    {
        Text t = go.AddComponent<Text>();
        t.font = GetFont();
        t.text = content;
        t.fontSize = size;
        t.fontStyle = style;
        t.color = color;
        t.alignment = anchor;
        t.horizontalOverflow = HorizontalWrapMode.Wrap;
        t.verticalOverflow = VerticalWrapMode.Overflow;
        t.raycastTarget = false;
        if (outline)
        {
            Outline o = go.AddComponent<Outline>();
            o.effectColor = new Color(0.08f, 0.03f, 0.25f, 0.95f);
            o.effectDistance = new Vector2(5f, -5f);
        }
        else
        {
            Shadow sh = go.AddComponent<Shadow>();
            sh.effectColor = new Color(0f, 0f, 0.05f, 0.5f);
            sh.effectDistance = new Vector2(2f, -2f);
        }
        return t;
    }

    // Kad panel bulat dengan garis tepi (menghalang ketukan tembus)
    public static RectTransform Card(Transform parent, string name, Vector2 size, int radius = 36)
    {
        Image fill = Pic(parent, name, UiSkin.Kind.Round, UiKit.Panel, Vector2.zero, size, radius);
        fill.raycastTarget = true;
        StretchPic(fill.transform, "Edge", UiSkin.Kind.Ring, UiKit.PanelEdge, radius, 3);
        return fill.rectTransform;
    }

    // Pasang LocalizedText pada teks supaya ia bertukar mengikut bahasa. Teks di editor sentiasa Bahasa Melayu (pratonton).
    public static Text L(Text t, string key)
    {
        if (t == null) return null;
        LocalizedText lt = t.gameObject.AddComponent<LocalizedText>();
        lt.key = key;
        t.text = Loc.Get(Loc.Lang.Malay, key);
        return t;
    }

    // Kad "Cara Main" (dikongsi oleh menu utama). withStart = tambah butang MULAKAN TUTORIAL.
    public static void HowToCard(Transform parent, bool withStart, out Button back, out Button start)
    {
        RectTransform card = Card(parent, "Card", new Vector2(1560, 960));
        L(Label(card, "Title", Loc.Get(Loc.Lang.Malay, "howto.title"), 84, UiKit.Ghost, new Vector2(0, 400), new Vector2(1200, 120),
                FontStyle.Bold, TextAnchor.MiddleCenter, true), "howto.title");

        float y = 265f;
        for (int i = 0; i < HowToText.RowCount; i++)
        {
            Image badge = Pic(card, "Badge" + (i + 1), UiSkin.Kind.Round, UiKit.Ghost,
                              new Vector2(-690, y), new Vector2(74, 74), 37);
            Label(badge.transform, "Num", (i + 1).ToString(), 44, UiKit.Dark, Vector2.zero, new Vector2(74, 74));
            string key = "howto." + (i + 1);
            L(Label(card, "Row" + (i + 1), Loc.Get(Loc.Lang.Malay, key), 36, UiKit.TextMain, new Vector2(30, y), new Vector2(1300, 104),
                    FontStyle.Normal, TextAnchor.MiddleLeft), key);
            y -= 108f;
        }
        L(Label(card, "NoteEnergy", Loc.Get(Loc.Lang.Malay, "howto.note.energy"), 33,
                UiKit.Warm, new Vector2(0, -290), new Vector2(1400, 56), FontStyle.Bold), "howto.note.energy");
        L(Label(card, "NoteWin", Loc.Get(Loc.Lang.Malay, "howto.note.win"), 33,
                UiKit.TextDim, new Vector2(0, -340), new Vector2(1400, 56), FontStyle.Normal), "howto.note.win");

        Color secondary = new Color(0.20f, 0.17f, 0.42f, 0.96f);
        if (withStart)
        {
            back = MakeButton(card, "BtnBack", "KEMBALI", new Vector2(-240, -415), new Vector2(380, 84),
                              secondary, UiKit.PanelEdge, UiKit.TextMain, 42);
            start = MakeButton(card, "BtnStartTutorial", "MULAKAN TUTORIAL", new Vector2(240, -415), new Vector2(460, 84),
                               UiKit.Ghost, new Color(1f, 1f, 1f, 0.55f), UiKit.Dark, 38);
            L(start.GetComponentInChildren<Text>(), "pause.tutorial");
        }
        else
        {
            back = MakeButton(card, "BtnBack", "KEMBALI", new Vector2(0, -415), new Vector2(380, 84),
                              secondary, UiKit.PanelEdge, UiKit.TextMain, 42);
            start = null;
        }
        L(back.GetComponentInChildren<Text>(), "pause.back");
    }

    // Butang bulat dengan garis tepi, label dan kesan sentuh
    public static Button MakeButton(Transform parent, string name, string label, Vector2 pos, Vector2 size,
                                    Color fill, Color ringColor, Color textColor, int fontSize, int radius = -1)
    {
        if (radius < 0) radius = Mathf.Min(30, Mathf.RoundToInt(size.y * 0.5f));
        Image img = Pic(parent, name, UiSkin.Kind.Round, Color.white, pos, size, radius);
        img.raycastTarget = true;

        Button btn = img.gameObject.AddComponent<Button>();
        btn.targetGraphic = img;
        ColorBlock c = btn.colors;
        c.normalColor = fill;
        c.highlightedColor = Color.Lerp(fill, Color.white, 0.2f);
        c.pressedColor = Color.Lerp(fill, Color.black, 0.25f);
        c.selectedColor = fill;
        c.disabledColor = new Color(fill.r, fill.g, fill.b, 0.4f);
        c.colorMultiplier = 1f;
        c.fadeDuration = 0.08f;
        btn.colors = c;

        StretchPic(img.transform, "Ring", UiSkin.Kind.Ring, ringColor, radius, 3);

        RectTransform lrt = StretchNode(img.transform, "Label");
        AddText(lrt.gameObject, label, fontSize, textColor, FontStyle.Bold, TextAnchor.MiddleCenter, false);

        img.gameObject.AddComponent<UiButtonFx>();
        return btn;
    }
}
#endif
