#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

/// <summary>
/// Menu: Ghost > Reset Tutorial
/// Tanda "tutorial selesai" disimpan dalam PlayerPrefs dan kekal antara sesi Play dalam Editor,
/// jadi guna ini untuk menguji tutorial semula tanpa membuka menu Tetapan.
/// </summary>
public static class TutorialTools
{
    // Padam pilihan bahasa yang disimpan, supaya permainan bermula dalam English seperti pemain baharu.
    [MenuItem("Ghost/Reset Language (kembali ke English)")]
    public static void ResetLanguage()
    {
        PlayerPrefs.DeleteKey("lang");
        PlayerPrefs.Save();
        Debug.Log("Pilihan bahasa dipadam. Permainan akan bermula dalam English pada Play yang seterusnya.");
    }

    [MenuItem("Ghost/Reset Tutorial")]
    public static void ResetTutorial()
    {
        PlayerPrefs.DeleteKey(Tutorial.DoneKey);
        PlayerPrefs.Save();
        Debug.Log("Tutorial ditetapkan semula. Ia akan muncul pada Malam 1 yang seterusnya.");
    }
}
#endif
