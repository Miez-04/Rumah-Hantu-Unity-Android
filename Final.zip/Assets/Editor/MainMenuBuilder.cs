#if UNITY_EDITOR
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.Events;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>
/// Menu: Ghost > 3 - Build Main Menu
/// Mencipta scene Assets/Scenes/MainMenu.unity dengan UI bertema (langit malam, bulan, wisp cahaya, aura hantu)
/// dan meletakkannya sebagai scene pertama dalam Build Settings. Selamat dijalankan berulang kali.
/// </summary>
public static class MainMenuBuilder
{
    const string MenuScenePath = "Assets/Scenes/MainMenu.unity";
    const string GameScenePath = "Assets/Scenes/Main.unity";

    static readonly Color Secondary = new Color(0.20f, 0.17f, 0.42f, 0.96f);
    static readonly Color Quiet = new Color(0.30f, 0.12f, 0.24f, 0.96f);

    [MenuItem("Ghost/3 - Build Main Menu")]
    public static void Build()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;

        Directory.CreateDirectory("Assets/Scenes");
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        // ---- Kamera ----
        var camGo = new GameObject("Main Camera");
        camGo.tag = "MainCamera";
        var cam = camGo.AddComponent<Camera>();
        cam.orthographic = true;
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = UiKit.Night;
        camGo.AddComponent<AudioListener>();

        new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));

        // ---- Canvas ----
        var canvasGo = new GameObject("Canvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster), typeof(CanvasGroup));
        canvasGo.GetComponent<Canvas>().renderMode = RenderMode.ScreenSpaceOverlay;
        var scaler = canvasGo.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);
        scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
        scaler.matchWidthOrHeight = 0.5f;
        Transform root = canvasGo.transform;

        // ---- Pengawal ----
        var menuGo = new GameObject("MainMenu");
        var menu = menuGo.AddComponent<MainMenu>();
        menu.gameScene = "Main";

        // ===== Latar =====
        UiBuilderKit.Gradient(root, "Sky", new Color(0.03f, 0.03f, 0.09f, 1f), new Color(0.22f, 0.12f, 0.38f, 1f),
                              Vector2.zero, Vector2.one);
        UiBuilderKit.Pic(root, "MoonGlow", UiSkin.Kind.Glow, new Color(0.75f, 0.82f, 1f, 0.5f),
                         new Vector2(640, 330), new Vector2(640, 640));
        UiBuilderKit.Pic(root, "Moon", UiSkin.Kind.Round, new Color(0.96f, 0.97f, 1f, 0.95f),
                         new Vector2(640, 330), new Vector2(150, 150), 75);
        // ===== Siluet rumah hantu + pokok mati =====
        Color sil = new Color(0.035f, 0.02f, 0.09f, 1f);
        var scenery = UiBuilderKit.StretchNode(root, "Scenery");
        float hx = -640f;
        UiBuilderKit.Pic(scenery, "HouseLower", UiSkin.Kind.Round, sil, new Vector2(hx, -520), new Vector2(460, 200), 6);
        UiBuilderKit.Pic(scenery, "HouseUpper", UiSkin.Kind.Round, sil, new Vector2(hx - 20, -355), new Vector2(340, 130), 6);
        UiBuilderKit.Pic(scenery, "HouseRoof", UiSkin.Kind.Triangle, sil, new Vector2(hx - 20, -230), new Vector2(410, 120));
        UiBuilderKit.Pic(scenery, "TowerBody", UiSkin.Kind.Round, sil, new Vector2(hx + 250, -470), new Vector2(90, 300), 6);
        UiBuilderKit.Pic(scenery, "TowerRoof", UiSkin.Kind.Triangle, sil, new Vector2(hx + 250, -275), new Vector2(130, 90));
        UiBuilderKit.Pic(scenery, "Chimney", UiSkin.Kind.Round, sil, new Vector2(hx - 110, -210), new Vector2(34, 90), 4);

        Vector2[] winPos =
        {
            new Vector2(hx - 140, -500), new Vector2(hx + 120, -500),
            new Vector2(hx - 90, -355), new Vector2(hx + 50, -355), new Vector2(hx + 250, -395),
        };
        Vector2[] winSize =
        {
            new Vector2(46, 58), new Vector2(46, 58), new Vector2(40, 52), new Vector2(40, 52), new Vector2(30, 46),
        };
        var windowImgs = new List<Image>();
        var glowImgs = new List<Image>();
        for (int i = 0; i < winPos.Length; i++)
        {
            glowImgs.Add(UiBuilderKit.Pic(scenery, "WinGlow" + (i + 1), UiSkin.Kind.Glow, UiKit.WithAlpha(UiKit.Warm, 0.32f),
                                          winPos[i], winSize[i] * 3.4f));
            windowImgs.Add(UiBuilderKit.Pic(scenery, "Win" + (i + 1), UiSkin.Kind.Round, new Color(1f, 0.82f, 0.45f, 0.95f),
                                            winPos[i], winSize[i], 5));
        }

        float tx = 800f;
        UiBuilderKit.Pic(scenery, "TreeTrunk", UiSkin.Kind.Round, sil, new Vector2(tx, -380), new Vector2(38, 440), 10)
                    .rectTransform.localRotation = Quaternion.Euler(0f, 0f, 2f);
        float[,] branches =
        {
            { tx - 40, -190, 14, 170, 38 }, { tx + 38, -210, 14, 150, -42 },
            { tx - 5, -120, 12, 130, 12 },  { tx + 60, -120, 10, 90, -60 },
        };
        for (int i = 0; i < branches.GetLength(0); i++)
        {
            int rad = Mathf.FloorToInt(branches[i, 2] * 0.5f);
            UiBuilderKit.Pic(scenery, "Branch" + (i + 1), UiSkin.Kind.Round, sil,
                             new Vector2(branches[i, 0], branches[i, 1]), new Vector2(branches[i, 2], branches[i, 3]), rad)
                        .rectTransform.localRotation = Quaternion.Euler(0f, 0f, branches[i, 4]);
        }

        var wispLayer = UiBuilderKit.StretchNode(root, "Wisps");
        UiBuilderKit.Gradient(root, "Fog", new Color(0.10f, 0.05f, 0.22f, 0f), new Color(0.07f, 0.03f, 0.16f, 0.95f),
                              Vector2.zero, new Vector2(1f, 0.34f));

        // ===== Panel utama =====
        var mainPanel = UiBuilderKit.StretchNode(root, "MainPanel");

        UiBuilderKit.Pic(mainPanel, "TitleGlow", UiSkin.Kind.Glow, UiKit.WithAlpha(UiKit.Ghost, 0.22f),
                         new Vector2(0, 330), new Vector2(1500, 420));
        UiBuilderKit.Label(mainPanel, "Title", "HANTU RUMAH", 160, UiKit.Ghost,
                           new Vector2(0, 330), new Vector2(1700, 220), FontStyle.Bold, TextAnchor.MiddleCenter, true);
        UiBuilderKit.Label(mainPanel, "Subtitle", "Takutkan semua penghuni keluar sebelum fajar", 44, UiKit.TextDim,
                           new Vector2(0, 205), new Vector2(1500, 80), FontStyle.Italic);

        // hantu + aura
        var aura = UiBuilderKit.Pic(mainPanel, "GhostAura", UiSkin.Kind.Glow, UiKit.WithAlpha(UiKit.GhostDeep, 0.4f),
                                    new Vector2(-620, 20), new Vector2(620, 620));
        var ghostRt = UiBuilderKit.Node(mainPanel, "GhostImage");
        ghostRt.anchoredPosition = new Vector2(-620, 20);
        ghostRt.sizeDelta = new Vector2(360, 360);
        var ghostImg = ghostRt.gameObject.AddComponent<Image>();
        ghostImg.preserveAspect = true;
        ghostImg.raycastTarget = false;
        var preview = Resources.LoadAll<Sprite>("Sprites/ghost");
        if (preview != null && preview.Length > 0) ghostImg.sprite = preview[0];
        menu.ghostImage = ghostImg;

        var btnPlay = UiBuilderKit.MakeButton(mainPanel, "BtnPlay", "MAIN", new Vector2(150, 70), new Vector2(580, 124),
                                              UiKit.Ghost, new Color(1f, 1f, 1f, 0.55f), UiKit.Dark, 62);
        var btnHow = UiBuilderKit.MakeButton(mainPanel, "BtnHowTo", "CARA MAIN", new Vector2(150, -65), new Vector2(580, 98),
                                             Secondary, UiKit.PanelEdge, UiKit.TextMain, 46);
        var btnSet = UiBuilderKit.MakeButton(mainPanel, "BtnSettings", "TETAPAN", new Vector2(150, -180), new Vector2(580, 98),
                                             Secondary, UiKit.PanelEdge, UiKit.TextMain, 46);
        var btnQuit = UiBuilderKit.MakeButton(mainPanel, "BtnQuit", "KELUAR", new Vector2(150, -295), new Vector2(580, 98),
                                              Quiet, UiKit.WithAlpha(UiKit.Danger, 0.7f), UiKit.TextMain, 46);

        // ===== Panel cara main =====
        var howPanel = UiBuilderKit.StretchNode(root, "HowToPanel");
        UiBuilderKit.Dim(howPanel, "Dim", new Color(0f, 0f, 0.04f, 0.6f));
        Button howBack, howStartUnused;
        UiBuilderKit.HowToCard(howPanel, false, out howBack, out howStartUnused);

        // ===== Panel tetapan =====
        var setPanel = UiBuilderKit.StretchNode(root, "SettingsPanel");
        UiBuilderKit.Dim(setPanel, "Dim", new Color(0f, 0f, 0.04f, 0.6f));
        var setCard = UiBuilderKit.Card(setPanel, "Card", new Vector2(900, 700));
        UiBuilderKit.Label(setCard, "Title", "TETAPAN", 84, UiKit.Ghost, new Vector2(0, 255), new Vector2(800, 120),
                           FontStyle.Bold, TextAnchor.MiddleCenter, true);
        var btnSound = UiBuilderKit.MakeButton(setCard, "BtnSound", "Bunyi: HIDUP", new Vector2(0, 105), new Vector2(680, 100),
                                               Secondary, UiKit.PanelEdge, UiKit.TextMain, 46);
        var btnTut = UiBuilderKit.MakeButton(setCard, "BtnTutorial", "Ulang Tutorial", new Vector2(0, -125), new Vector2(680, 100),
                                             Secondary, UiKit.PanelEdge, UiKit.TextMain, 42);
        var btnLang = UiBuilderKit.MakeButton(setCard, "BtnLanguage", "Bahasa: Melayu", new Vector2(0, -10), new Vector2(680, 100),
                                              Secondary, UiKit.PanelEdge, UiKit.TextMain, 42);
        var setBack = UiBuilderKit.MakeButton(setCard, "BtnBack", "KEMBALI", new Vector2(0, -250), new Vector2(380, 90),
                                              Secondary, UiKit.PanelEdge, UiKit.TextMain, 42);

        // ---- Suasana ----
        var ambGo = new GameObject("MenuAmbience");
        var amb = ambGo.AddComponent<MenuAmbience>();
        amb.wispLayer = wispLayer;
        amb.pulseGlow = aura;
        amb.fadeIn = canvasGo.GetComponent<CanvasGroup>();
        amb.windows = windowImgs.ToArray();
        amb.windowGlows = glowImgs.ToArray();

        // ---- Terjemahan: teks tetap bertukar mengikut bahasa (butang Bunyi dan Tutorial diurus oleh MainMenu) ----
        Localize(root, "MainPanel/Title", "menu.title");
        Localize(root, "MainPanel/Subtitle", "menu.subtitle");
        Localize(root, "MainPanel/BtnPlay", "menu.play");
        Localize(root, "MainPanel/BtnHowTo", "menu.howto");
        Localize(root, "MainPanel/BtnSettings", "menu.settings");
        Localize(root, "MainPanel/BtnQuit", "menu.quit");
        Localize(root, "SettingsPanel/Card/Title", "set.title");
        Localize(root, "SettingsPanel/Card/BtnLanguage", "set.lang");
        Localize(root, "SettingsPanel/Card/BtnBack", "menu.back");

        // ---- Wayar ----
        menu.mainPanel = mainPanel.gameObject;
        menu.howToPanel = howPanel.gameObject;
        menu.settingsPanel = setPanel.gameObject;
        menu.soundButtonText = btnSound.GetComponentInChildren<Text>();
        menu.tutorialButtonText = btnTut.GetComponentInChildren<Text>();

        UnityEventTools.AddPersistentListener(btnPlay.onClick, menu.Play);
        UnityEventTools.AddPersistentListener(btnHow.onClick, menu.ShowHowTo);
        UnityEventTools.AddPersistentListener(btnSet.onClick, menu.ShowSettings);
        UnityEventTools.AddPersistentListener(btnQuit.onClick, menu.Quit);
        UnityEventTools.AddPersistentListener(howBack.onClick, menu.ShowMain);
        UnityEventTools.AddPersistentListener(setBack.onClick, menu.ShowMain);
        UnityEventTools.AddPersistentListener(btnSound.onClick, menu.ToggleSound);
        UnityEventTools.AddPersistentListener(btnTut.onClick, menu.ResetTutorial);
        UnityEventTools.AddPersistentListener(btnLang.onClick, menu.ToggleLanguage);

        howPanel.gameObject.SetActive(false);
        setPanel.gameObject.SetActive(false);

        EditorSceneManager.MarkSceneDirty(scene);
        EditorSceneManager.SaveScene(scene, MenuScenePath);
        SetupBuildSettings();

        Debug.Log("Menu utama siap: " + MenuScenePath + ". Tekan Play untuk uji. " +
                  "(Dalam Scene view, bentuk bulat hanya muncul semasa Play.)");
    }

    static void Localize(Transform root, string path, string key)
    {
        Transform t = root.Find(path);
        if (t == null) { Debug.LogWarning("MainMenuBuilder: tak jumpa " + path + " untuk terjemahan."); return; }
        Text text = t.GetComponent<Text>();
        if (text == null) text = t.GetComponentInChildren<Text>();
        UiBuilderKit.L(text, key);
    }

    static void SetupBuildSettings()
    {
        var list = new List<EditorBuildSettingsScene>();
        list.Add(new EditorBuildSettingsScene(MenuScenePath, true));

        bool hasGame = false;
        foreach (var s in EditorBuildSettings.scenes)
        {
            if (s.path == MenuScenePath) continue;
            if (s.path == GameScenePath) hasGame = true;
            list.Add(s);
        }
        if (!hasGame && File.Exists(GameScenePath))
            list.Add(new EditorBuildSettingsScene(GameScenePath, true));

        EditorBuildSettings.scenes = list.ToArray();
    }
}
#endif
