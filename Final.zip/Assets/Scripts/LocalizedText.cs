using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Letak pada objek yang ada Text (uGUI). Teksnya diambil daripada Loc dengan kunci, dan dikemas kini
/// secara automatik bila bahasa bertukar. Dipasang oleh alat pembina menu.
/// </summary>
[RequireComponent(typeof(Text))]
public class LocalizedText : MonoBehaviour
{
    public string key;

    Text label;

    void OnEnable()
    {
        Apply();
        Loc.Changed += Apply;
    }

    void OnDisable()
    {
        Loc.Changed -= Apply;
    }

    public void Apply()
    {
        if (label == null) label = GetComponent<Text>();
        if (label != null && !string.IsNullOrEmpty(key)) label.text = Loc.T(key);
    }
}
