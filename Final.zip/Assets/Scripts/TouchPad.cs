using UnityEngine;

// Kawalan atas skrin:
//  - Joystick terapung di sebelah kiri (sentuh di mana-mana dalam zon kiri, kemudian seret). Analog.
//      * Mod TERBANG (hantu bebas): joystick dua hala (atas / bawah / kiri / kanan) menggerakkan hantu.
//      * Mod MERASUK (dalam perabot): joystick kiri / kanan menggerakkan perabot.
//  - LOMPAT, KUASA dan KELUAR di sebelah kanan (hanya semasa merasuk).
// Ketukan pantas dalam zon joystick dianggap ketukan biasa (untuk merasuk perabot), bukan seretan.
// Berbilang sentuhan: joystick dan butang boleh ditekan serentak.
// Papan kekunci dalam Editor: WASD / anak panah, Space, E, Q.
[DefaultExecutionOrder(-50)]
public class TouchPad : MonoBehaviour
{
    public static TouchPad Instance { get; private set; }

    [System.NonSerialized] public bool Visible;        // paparkan kawalan (joystick, dan butang jika merasuk)
    [System.NonSerialized] public bool FlightMode = true; // true = hantu bebas, false = sedang merasuk
    [System.NonSerialized] public string ActionLabel = ""; // kosong = "KUASA" / "POWER" mengikut bahasa
    [System.NonSerialized] public bool ActionAffordable = true; // tenaga cukup untuk kuasa khas?

    public float Horizontal { get; private set; } // -1 .. 1 (analog)
    public Vector2 MoveAxis { get; private set; } // arah terbang 2D, panjang maksimum 1
    public bool JumpDown { get; private set; }
    public bool ActionDown { get; private set; }
    public bool ExitDown { get; private set; }

    // ketukan pantas dalam zon joystick (diambil oleh GhostController)
    [System.NonSerialized] public bool TapPending;
    [System.NonSerialized] public Vector2 TapScreenPos;

    // -1 = tiada, -2 = tetikus, selain itu = fingerId sentuhan yang memegang joystick
    public int JoystickFinger { get { return joyFinger; } }

    const float JoyRadius = 60f;      // jarak maksimum knob (unit GUI)
    const float JoyDeadZone = 0.18f;  // abaikan getaran kecil
    const float TapMaxTime = 0.25f;
    const float TapMaxDrag = 0.3f;
    const int MouseId = -2;

    bool prevJump, prevAction, prevExit;
    bool dJump, dAction, dExit; // untuk lukisan
    Rect jumpR, actionR, exitR, joyZone;
    Vector2 joyHome;
    int joyFinger = -1;
    Vector2 joyCenter;
    Vector2 joyAxis;
    float joyStartTime;
    float joyMaxMag;
    Vector2 joyStartScreen;

    void Awake()
    {
        Instance = this;
    }

    void Layout(float w)
    {
        const float H = 540f;
        jumpR = new Rect(w - 300f, H - 130f, 125f, 110f);
        actionR = new Rect(w - 165f, H - 160f, 145f, 140f);
        exitR = new Rect(w - 130f, 56f, 110f, 46f);
        joyZone = new Rect(0f, 190f, 340f, H - 190f);
        joyHome = new Vector2(125f, H - 105f);
    }

    static Vector2 ToGui(Vector2 screenPos, float s)
    {
        return new Vector2(screenPos.x / s, (Screen.height - screenPos.y) / s);
    }

    void Update()
    {
        JumpDown = false;
        ActionDown = false;
        ExitDown = false;
        Horizontal = 0f;
        MoveAxis = Vector2.zero;
        dJump = dAction = dExit = false;

        if (!Visible)
        {
            prevJump = prevAction = prevExit = true; // abaikan tekanan yang masih dipegang bila muncul semula
            joyFinger = -1;
            joyAxis = Vector2.zero;
            TapPending = false;
            return;
        }

        bool flight = FlightMode;
        bool jump = false, action = false, exit = false;

        Vector2 key = Vector2.zero;
        if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow)) key.x += 1f;
        if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow)) key.x -= 1f;
        if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow)) key.y += 1f;
        if (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow)) key.y -= 1f;
        if (!flight)
        {
            if (Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow)) jump = true;
            if (Input.GetKey(KeyCode.E) || Input.GetKey(KeyCode.J)) action = true;
            if (Input.GetKey(KeyCode.Q)) exit = true;
        }

        float s = Screen.height / 540f;
        Layout(Screen.width / s);

        bool joyAlive = false;
        int n = Input.touchCount;
        if (n > 0)
        {
            for (int i = 0; i < n; i++)
            {
                Touch t = Input.GetTouch(i);
                bool ended = t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled;
                Vector2 g = ToGui(t.position, s);

                if (t.fingerId == joyFinger)
                {
                    if (!ended) { UpdateJoy(g); joyAlive = true; }
                    continue;
                }
                if (ended) continue;

                if (joyFinger == -1 && t.phase == TouchPhase.Began && joyZone.Contains(g))
                {
                    BeginJoy(t.fingerId, g, t.position);
                    joyAlive = true;
                    continue;
                }
                if (!flight) CheckButtons(g, ref jump, ref action, ref exit);
            }
        }
        else if (Input.GetMouseButton(0))
        {
            Vector2 g = ToGui(Input.mousePosition, s);
            if (joyFinger == MouseId)
            {
                UpdateJoy(g);
                joyAlive = true;
            }
            else if (joyFinger == -1 && Input.GetMouseButtonDown(0) && joyZone.Contains(g))
            {
                BeginJoy(MouseId, g, Input.mousePosition);
                joyAlive = true;
            }
            else if (!flight)
            {
                CheckButtons(g, ref jump, ref action, ref exit);
            }
        }

        if (!joyAlive)
        {
            // jari baru dilepaskan: ketukan pantas tanpa seretan = ketukan biasa
            if (joyFinger != -1 && flight && Time.unscaledTime - joyStartTime < TapMaxTime && joyMaxMag < TapMaxDrag)
            {
                TapPending = true;
                TapScreenPos = joyStartScreen;
            }
            joyFinger = -1;
            joyAxis = Vector2.zero;
        }

        // paksi joystick selepas zon mati
        Vector2 ja = Vector2.zero;
        float mag = joyAxis.magnitude;
        if (mag > JoyDeadZone) ja = joyAxis / mag * Mathf.InverseLerp(JoyDeadZone, 1f, mag);

        if (flight)
        {
            MoveAxis = Vector2.ClampMagnitude(ja + key, 1f);
            Horizontal = MoveAxis.x;
        }
        else
        {
            float h = key.x;
            float ax = joyAxis.x;
            float a = Mathf.Abs(ax);
            if (a > JoyDeadZone) h += Mathf.Sign(ax) * Mathf.InverseLerp(JoyDeadZone, 1f, a);
            Horizontal = Mathf.Clamp(h, -1f, 1f);
        }

        JumpDown = jump && !prevJump;
        ActionDown = action && !prevAction;
        ExitDown = exit && !prevExit;
        prevJump = jump;
        prevAction = action;
        prevExit = exit;

        dJump = jump; dAction = action; dExit = exit;
    }

    void BeginJoy(int id, Vector2 g, Vector2 screenPos)
    {
        joyFinger = id;
        joyStartTime = Time.unscaledTime;
        joyStartScreen = screenPos;
        joyMaxMag = 0f;
        joyCenter = new Vector2(Mathf.Clamp(g.x, 95f, 245f), Mathf.Clamp(g.y, 250f, 470f));
        UpdateJoy(g);
    }

    void UpdateJoy(Vector2 g)
    {
        // skrin y ke bawah, jadi balikkan supaya "atas" = positif
        Vector2 d = g - joyCenter;
        joyAxis = Vector2.ClampMagnitude(new Vector2(d.x, -d.y) / JoyRadius, 1f);
        joyMaxMag = Mathf.Max(joyMaxMag, joyAxis.magnitude);
    }

    void CheckButtons(Vector2 g, ref bool jump, ref bool action, ref bool exit)
    {
        if (jumpR.Contains(g)) jump = true;
        else if (actionR.Contains(g)) action = true;
        else if (exitR.Contains(g)) exit = true;
    }

    void OnGUI()
    {
        if (!Visible) return;
        float s = Screen.height / 540f;
        GUI.matrix = Matrix4x4.Scale(new Vector3(s, s, 1f));
        Layout(Screen.width / s);

        DrawJoystick();
        if (!FlightMode)
        {
            Draw(jumpR, Loc.T("ctl.jump"), dJump, 22, UiKit.Ghost, 26, true);
            Draw(actionR, string.IsNullOrEmpty(ActionLabel) ? Loc.T("ctl.power") : ActionLabel, dAction, 25, UiKit.Warm, 60, ActionAffordable);
            Draw(exitR, Loc.T("ctl.exit"), dExit, 17, UiKit.Danger, 23, true);
        }
    }

    void DrawJoystick()
    {
        bool active = joyFinger != -1;
        Vector2 c = active ? joyCenter : joyHome;
        float baseR = JoyRadius + 8f;

        Color prev = GUI.color;
        GUI.color = new Color(1f, 1f, 1f, active ? 1f : 0.6f);

        UiKit.Glow(new Rect(c.x - baseR * 1.5f, c.y - baseR * 1.5f, baseR * 3f, baseR * 3f),
                   UiKit.WithAlpha(UiKit.Ghost, active ? 0.22f : 0.1f));
        Rect b = new Rect(c.x - baseR, c.y - baseR, baseR * 2f, baseR * 2f);
        UiKit.Round(b, new Color(0.06f, 0.05f, 0.15f, 0.5f), Mathf.RoundToInt(baseR));
        UiKit.Ring(b, UiKit.WithAlpha(UiKit.Ghost, 0.7f), Mathf.RoundToInt(baseR), 2);

        Color hint = UiKit.WithAlpha(UiKit.TextDim, 0.8f);
        UiKit.Text(new Rect(b.x + 4f, c.y - 16f, 34f, 32f), "<", 26, hint, TextAnchor.MiddleCenter, false);
        UiKit.Text(new Rect(b.xMax - 38f, c.y - 16f, 34f, 32f), ">", 26, hint, TextAnchor.MiddleCenter, false);
        if (FlightMode)
        {
            UiKit.Text(new Rect(c.x - 17f, b.y + 6f, 34f, 28f), "^", 24, hint, TextAnchor.MiddleCenter, false);
            UiKit.Text(new Rect(c.x - 17f, b.yMax - 32f, 34f, 28f), "v", 22, hint, TextAnchor.MiddleCenter, false);
        }

        // paksi y positif = atas, tetapi skrin y ke bawah
        Vector2 k = c + new Vector2(joyAxis.x, -joyAxis.y) * JoyRadius;
        const float kr = 27f;
        Rect knob = new Rect(k.x - kr, k.y - kr, kr * 2f, kr * 2f);
        UiKit.Round(knob, UiKit.WithAlpha(UiKit.Ghost, active ? 0.95f : 0.55f), Mathf.RoundToInt(kr));
        UiKit.Ring(knob, new Color(1f, 1f, 1f, 0.55f), Mathf.RoundToInt(kr), 2);

        GUI.color = prev;
    }

    void Draw(Rect r, string label, bool down, int size, Color accent, int radius, bool enabledLook)
    {
        if (!enabledLook) accent = new Color(0.55f, 0.55f, 0.65f, 1f); // tenaga tak cukup: kelabu

        Rect d = r;
        if (down) d.y += 2f;

        Color fill = down ? Color.Lerp(new Color(0.10f, 0.09f, 0.24f, 0.88f), accent, 0.4f)
                          : new Color(0.06f, 0.05f, 0.15f, enabledLook ? 0.58f : 0.45f);
        UiKit.Round(d, fill, radius);
        UiKit.Ring(d, UiKit.WithAlpha(accent, down ? 1f : (enabledLook ? 0.75f : 0.45f)), radius, 2);

        Color text = down ? Color.white : (enabledLook ? UiKit.TextMain : new Color(0.7f, 0.7f, 0.8f, 0.7f));
        string[] parts = label.Split('\n');
        if (parts.Length > 1)
        {
            // baris atas = nama kuasa, baris bawah = kos tenaga
            UiKit.Text(new Rect(d.x, d.y + d.height * 0.14f, d.width, d.height * 0.5f), parts[0], size, text);
            UiKit.Text(new Rect(d.x, d.y + d.height * 0.58f, d.width, d.height * 0.28f), parts[1], Mathf.RoundToInt(size * 0.8f),
                       enabledLook ? UiKit.Warm : UiKit.Danger);
        }
        else
        {
            UiKit.Text(d, label, size, text);
        }
    }
}
