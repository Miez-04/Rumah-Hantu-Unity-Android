/// <summary>Teks "Cara Main" yang dikongsi oleh menu utama dan menu jeda. Teks sebenar berada dalam Loc.cs.</summary>
public static class HowToText
{
    public const int RowCount = 5;

    public static string[] Rows
    {
        get
        {
            string[] r = new string[RowCount];
            for (int i = 0; i < RowCount; i++) r[i] = Loc.T("howto." + (i + 1));
            return r;
        }
    }

    public static string NoteEnergy { get { return Loc.T("howto.note.energy"); } }
    public static string NoteWin { get { return Loc.T("howto.note.win"); } }
}
