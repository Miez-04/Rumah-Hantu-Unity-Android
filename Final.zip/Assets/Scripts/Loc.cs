using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Sistem bahasa Hantu Rumah: Bahasa Melayu dan English.
///
/// Semua teks yang dilihat pemain diambil daripada jadual di bawah dengan kunci, contohnya Loc.T("hud.guests").
/// Untuk menambah atau mengubah teks, ubah baris Add("kunci", "Melayu", "English") dalam Build().
/// Senarai ayat rawak disimpan dalam satu baris dipisahkan "|" dan diambil dengan Loc.Pick / Loc.Arr.
/// Hanya dua bahasa. Bahasa asal pada kali pertama permainan dibuka ialah English, TANPA mengikut bahasa peranti.
/// Bila pemain memilih bahasa, pilihan itu disimpan dalam PlayerPrefs dan diingati. Loc.Changed dicetus bila bahasa
/// bertukar (LocalizedText mendengarnya).
/// Kunci yang tiada akan dipaparkan sebagai kunci itu sendiri (supaya mudah dilihat) dan satu amaran dilog.
/// </summary>
public static class Loc
{
    public enum Lang { Malay = 0, English = 1 }

    const string PrefKey = "lang";

    static Dictionary<string, string[]> table;
    static HashSet<string> warned = new HashSet<string>();
    static Lang current = Lang.English;
    static bool loaded;

    public static event System.Action Changed;

    public static Lang Current
    {
        get { Load(); return current; }
    }

    static void Load()
    {
        if (loaded) return;
        loaded = true;
        // Tiada pilihan disimpan = kali pertama dibuka = English. Hanya pilihan Melayu yang pernah disimpan (0) menghasilkan Melayu.
        int v = PlayerPrefs.GetInt(PrefKey, (int)Lang.English);
        current = v == (int)Lang.Malay ? Lang.Malay : Lang.English;
    }

    public static void Set(Lang l)
    {
        Load();
        bool differs = l != current;
        current = l;
        PlayerPrefs.SetInt(PrefKey, (int)l); // simpan walaupun sama, supaya pilihan eksplisit diingati
        PlayerPrefs.Save();
        if (differs && Changed != null) Changed();
    }

    public static void Toggle()
    {
        Set(Current == Lang.Malay ? Lang.English : Lang.Malay);
    }

    // ---------- akses teks ----------
    public static bool Has(string key)
    {
        Ensure();
        return table.ContainsKey(key);
    }

    public static string Get(Lang lang, string key)
    {
        Ensure();
        string[] v;
        if (!table.TryGetValue(key, out v))
        {
            if (warned.Add(key)) Debug.LogWarning("[Loc] kunci teks tiada: " + key);
            return key;
        }
        return v[(int)lang];
    }

    public static string T(string key)
    {
        return Get(Current, key);
    }

    public static string T(string key, params object[] args)
    {
        return string.Format(Get(Current, key), args);
    }

    public static string[] Arr(string key)
    {
        return Get(Current, key).Split('|');
    }

    public static string Pick(string key)
    {
        string[] a = Arr(key);
        return a[Random.Range(0, a.Length)];
    }

    public static IEnumerable<string> Keys
    {
        get { Ensure(); return table.Keys; }
    }

    // Nama rumah mengikut nama scene (cth. "klasik" atau "klasik_M"). Jika tak dikenali, guna fallback.
    public static string HouseName(string sceneName, string fallback)
    {
        if (string.IsNullOrEmpty(sceneName)) return fallback;
        bool mirrored = sceneName.EndsWith("_M");
        string id = mirrored ? sceneName.Substring(0, sceneName.Length - 2) : sceneName;
        string key = "house." + id;
        if (!Has(key)) return fallback;
        return mirrored ? T(key) + " " + T("house.mirror") : T(key);
    }

    // ---------- jadual ----------
    static void Ensure()
    {
        if (table != null) return;
        table = new Dictionary<string, string[]>();
        Build();
    }

    static void Add(string key, string ms, string en)
    {
        table[key] = new string[] { ms, en };
    }

    static void Build()
    {
        // ===== HUD =====
        Add("hud.night", "MALAM {0}", "NIGHT {0}");
        Add("hud.guests", "TINGGAL", "LEFT");
        Add("hud.energy", "TENAGA HANTU", "GHOST ENERGY");
        Add("hud.refill", "mengisi +", "refilling +");
        Add("hud.noenergy", "TENAGA TIDAK CUKUP", "NOT ENOUGH ENERGY");
        Add("hud.hint", "Joystick untuk terbang  |  ketuk perabot untuk merasuk", "Joystick to fly  |  tap furniture to possess");

        // ===== skrin akhir =====
        Add("end.head.last", "TAMAT!", "THE END!");
        Add("end.head.win", "BERJAYA!", "SUCCESS!");
        Add("end.head.lose", "MASA TAMAT", "TIME'S UP");
        Add("end.sub.last", "Malam yang panjang sudah berakhir", "The long night is over");
        Add("end.sub.win", "Semua tetamu lari ketakutan", "Every guest fled in terror");
        Add("end.sub.lose", "Masih ada tetamu di dalam rumah", "Guests are still inside the house");
        Add("end.btn.restart", "Teruskan", "Continue");
        Add("end.btn.next", "Malam Seterusnya", "Next Night");
        Add("end.btn.retry", "Cuba Lagi", "Try Again");

        // ===== kawalan =====
        Add("ctl.jump", "LOMPAT", "JUMP");
        Add("ctl.exit", "KELUAR", "EXIT");
        Add("ctl.power", "KUASA", "POWER");

        // ===== nama kuasa perabot =====
        Add("power.Stomp", "TUMBUK", "STOMP");
        Add("power.Charge", "SERUDUK", "CHARGE");
        Add("power.Pounce", "TERKAM", "POUNCE");
        Add("power.Topple", "RUNTUH", "TOPPLE");
        Add("power.Giggle", "KEKEH", "GIGGLE");
        Add("power.Flash", "KILAT", "FLASH");
        Add("power.Gong", "GONG", "GONG");
        Add("power.Throw", "BALING", "THROW");
        Add("power.Drop", "JATUH", "DROP");

        // ===== menu jeda =====
        Add("pause.title", "JEDA", "PAUSED");
        Add("pause.resume", "SAMBUNG", "RESUME");
        Add("pause.howto", "CARA MAIN", "HOW TO PLAY");
        Add("pause.restart", "ULANG", "RESTART");
        Add("pause.menu", "MENU UTAMA", "MAIN MENU");
        Add("pause.back", "KEMBALI", "BACK");
        Add("pause.tutorial", "MULAKAN TUTORIAL", "START TUTORIAL");

        // ===== cara main =====
        Add("howto.title", "CARA MAIN", "HOW TO PLAY");
        Add("howto.1", "Guna joystick di kiri bawah untuk terbangkan hantu ke mana-mana.", "Use the joystick at the bottom left to fly the ghost anywhere.");
        Add("howto.2", "Ketuk perabot untuk merasuk dan mengawalnya.", "Tap furniture to possess and control it.");
        Add("howto.3", "Joystick untuk gerak, LOMPAT untuk melompat, dan KUASA khas perabot itu. KELUAR untuk keluar.", "Joystick to move, JUMP to jump, and POWER for the furniture's special ability. EXIT to leave it.");
        Add("howto.4", "Hentaman dan kaca pecah menakutkan tetamu berdekatan.", "Crashes and breaking glass scare nearby guests.");
        Add("howto.5", "Tetamu jadi kebal kalau gangguan sama diulang. Campurkan cara!", "Guests get used to the same scare. Mix it up!");
        Add("howto.note.energy", "Tenaga pulih perlahan bila tak guna kuasa, dan bertambah bila tetamu lari.", "Energy refills slowly when you rest, and grows when a guest flees.");
        Add("howto.note.win", "MENANG: semua tetamu keluar sebelum masa tamat.", "WIN: every guest leaves before time runs out.");

        // ===== tutorial =====
        Add("tut.1", "Gerakkan joystick di kiri bawah untuk terbangkan hantu.", "Move the joystick at the bottom left to fly the ghost.");
        Add("tut.2", "Ketuk perabot yang bercahaya untuk merasuknya.", "Tap the glowing furniture to possess it.");
        Add("tut.3", "Gerakkan perabot dengan joystick di kiri, tekan LOMPAT, dan hempas dekat tetamu sampai bar takut mereka naik.", "Move the furniture with the left joystick, press JUMP, and slam it near a guest until their fear bar rises.");
        Add("tut.4", "Tekan butang KUASA (kuning) untuk guna kuasa khas. Tenaga pulih perlahan bila kamu berhenti menggunakannya.", "Press the POWER button (yellow) to use the special ability. Energy refills slowly when you stop using it.");
        Add("tut.5", "Teruskan menakutkan sehingga seorang tetamu lari ke pintu keluar. Campurkan cara supaya mereka tak kebal!", "Keep scaring until a guest runs for the exit. Mix your tricks so they don't get used to them!");
        Add("tut.again", "Ketuk perabot yang bercahaya untuk merasuk semula.", "Tap the glowing furniture to possess it again.");
        Add("tut.done", "TAHNIAH! Kamu sudah tahu asasnya. Selamat menakutkan!", "WELL DONE! You know the basics now. Happy haunting!");
        Add("tut.skip", "LANGKAU", "SKIP");
        Add("tut.tap", "KETUK", "TAP");

        // ===== menu utama dan tetapan =====
        Add("menu.title", "HANTU RUMAH", "HAUNTED HOUSE");
        Add("menu.subtitle", "Takutkan semua penghuni keluar sebelum fajar", "Scare every guest out before dawn");
        Add("menu.play", "MAIN", "PLAY");
        Add("menu.howto", "CARA MAIN", "HOW TO PLAY");
        Add("menu.settings", "TETAPAN", "SETTINGS");
        Add("menu.quit", "KELUAR", "QUIT");
        Add("menu.back", "KEMBALI", "BACK");
        Add("set.title", "TETAPAN", "SETTINGS");
        Add("set.sound.on", "Bunyi: HIDUP", "Sound: ON");
        Add("set.sound.off", "Bunyi: MATI", "Sound: OFF");
        Add("set.lang", "Bahasa: Melayu", "Language: English");
        Add("set.tutorial.pending", "Tutorial: AKAN DIPAPARKAN", "Tutorial: WILL SHOW");
        Add("set.tutorial.replay", "Ulang Tutorial", "Replay Tutorial");

        // ===== nama rumah =====
        Add("house.klasik", "Banglo Klasik", "Classic Bungalow");
        Add("house.kampung", "Rumah Kampung", "Village House");
        Add("house.menara", "Menara Empat Tingkat", "Four-Storey Tower");
        Add("house.padat", "Banglo Padat", "Compact Bungalow");
        Add("house.mirror", "(Cermin)", "(Mirrored)");

        // ===== perbualan dua orang (baris selang-seli) =====
        Add("convo.1", "Rumah ni cantik, tapi sejuk sangat.|Betul. Bulu roma aku meremang.|Mungkin sebab dah malam.",
                       "This house is lovely, but it's so cold.|You're right. I've got goosebumps.|Maybe it's just the night air.");
        Add("convo.2", "Kamu rasa rumah ni berhantu?|Merepek. Itu cerita orang tua.|Harap-harap macam tu la.",
                       "Do you think this house is haunted?|Nonsense. That's just an old wives' tale.|I hope you're right.");
        Add("convo.3", "Pesta tadi seronok kan?|Seronok. Tapi lampu tu asyik berkelip.|Aku pun perasan.",
                       "That party was fun, wasn't it?|It was. But those lights keep flickering.|I noticed that too.");
        Add("convo.4", "Mana tuan rumah pergi?|Entah. Dari tadi tak nampak.|Pelik juga.",
                       "Where did the host go?|No idea. Haven't seen them all night.|That's odd.");
        Add("convo.5", "Aku dengar bunyi kaki tadi.|Itu kita punya la.|Hmm, mungkin.",
                       "I heard footsteps earlier.|That was just us.|Hmm, maybe.");
        Add("convo.6", "Dah lewat ni. Nak balik?|Sekejap lagi. Aku nak habiskan minum.|Jangan lama sangat.",
                       "It's getting late. Shall we go?|In a bit. Let me finish my drink.|Don't take too long.");
        Add("convo.7", "Cuba tengok lukisan tu.|Macam mata dia ikut kita pula.|Jangan cakap macam tu!",
                       "Look at that painting.|It feels like its eyes follow us.|Don't say that!");
        Add("convo.8", "Sofa ni empuk gila.|Jangan duduk lama, nanti tertidur.|Tak apa, kamu kejutkan aku.",
                       "This sofa is so comfy.|Don't sit too long, you'll fall asleep.|Then wake me up, okay?");
        Add("convo.9", "Kamu pernah masuk rumah ni dulu?|Sekali, masa kecil.|Ada apa-apa yang pelik?|Tak ingat. Tapi aku rasa tak selesa.",
                       "Have you been in this house before?|Once, when I was little.|Anything strange?|I don't remember. But I don't feel comfortable.");
        Add("convo.10", "Aku lapar la.|Tadi kan ada kuih.|Dah habis dimakan kamu!",
                        "I'm hungry.|There were snacks earlier.|You ate them all!");

        // ===== gumaman, reaksi dan arahan =====
        Add("talk.nervous", "Aku tak sedap hati...|Jom keluar cepat?|Rumah ni... pelik.|Siapa buka tingkap tadi?|Aku rasa ada orang tengok kita.",
                            "I don't like this...|Can we leave soon?|This house is... weird.|Who opened that window?|I feel like someone's watching us.");
        Add("talk.neutral", "Hmm, sunyi pula.|Mana yang lain?|Cantik rumah ni.|Dah pukul berapa ni?|Hawa dia sejuk sikit.",
                            "Hmm, it's quiet.|Where is everyone?|Nice house.|What time is it?|It's a bit chilly in here.");
        Add("talk.brave", "Hantu? Merepek.|Aku tak percaya semua tu.|Tak ada apa-apa pun.|Rumah lama memang berderit.",
                          "Ghosts? Nonsense.|I don't believe any of it.|There's nothing here.|Old houses just creak.");
        Add("talk.heard", "Eh? Bunyi apa tu?|Kamu dengar tak?|Dari mana bunyi tu?|Ada orang kat sana ke?|Apa tu tadi?",
                          "Huh? What was that?|Did you hear that?|Where did that come from?|Is somebody over there?|What was that?");
        Add("talk.go", "Aku periksa kejap.|Jap, aku tengok.|Aku pergi tengok.",
                       "I'll go check.|Hold on, let me look.|I'll take a look.");
        Add("talk.bravego", "Biar aku periksa.|Aku tak takut. Aku pergi.|Mesti tikus.",
                            "Let me check.|I'm not scared. I'll go.|Must be a rat.");
        Add("talk.dismiss", "Tak ada apa-apa...|Mungkin tikus.|Angin kot.|Pelik...",
                            "Nothing here...|Probably a rat.|Just the wind.|Strange...");
        Add("talk.bravedismiss", "Tak ada apa pun. Penakut betul.|Aku dah cakap, tak ada apa-apa.",
                                 "Nothing at all. What cowards.|Told you, there's nothing.");
        Add("talk.company", "Jom... jangan tinggalkan aku.|Aku ikut kamu.|Aku nak dekat dengan orang lain.",
                            "Come on... don't leave me.|I'm coming with you.|I want to be near other people.");
        Add("talk.alone", "A-aku tunggu sini je...|Aku tak nak pergi sana.|Aku tak berani...",
                          "I-I'll just wait here...|I don't want to go over there.|I'm too scared...");
        Add("talk.noway", "Entah dari mana tu...|Jauh bunyi tu.|Hmm...",
                          "No idea where that came from...|That sounded far away.|Hmm...");
        Add("talk.calm", "Tenang... mungkin angin je.|Jangan risau, tak ada apa-apa.|Tarik nafas. Okay?",
                         "Calm down... it's probably just the wind.|Don't worry, it's nothing.|Take a breath. Okay?");
        Add("talk.flee", "Lari!!!|HANTU!!|Tolong!!|Aku nak keluar!",
                         "RUN!!!|GHOST!!|Help!!|Get me out!");

        Add("react.Impact", "Bunyi apa tu?!", "What was that?!");
        Add("react.Smash", "Ada benda pecah!", "Something broke!");
        Add("react.Sound", "Siapa ketawa tu?!", "Who's laughing?!");
        Add("react.Light", "Lampu tu berkelip!", "The light is flickering!");
        Add("react.Shake", "Rumah bergegar!", "The house is shaking!");
        Add("react.Panic", "Dia lari! Kenapa?!", "They're running! Why?!");
        Add("react.Move", "Perabot tu bergerak!", "The furniture moved!");

        // ===== cerita: prolog dan epilog =====
        // Halaman dipisahkan dengan "|". Baris baru dalam satu halaman guna \n. Bilangan halaman MESTI sama dalam kedua-dua bahasa.
        Add("story.prolog.title", "PROLOG", "PROLOGUE");
        Add("story.epilog.title", "EPILOG", "EPILOGUE");
        Add("story.tap", "Ketuk untuk teruskan", "Tap to continue");
        Add("story.skip", "Langkau >>", "Skip >>");
        Add("story.prolog.pages",
            "Rumah ini pernah penuh dengan tawa.\nMakan malam yang panjang. Lampu yang tak pernah padam.|Kemudian keluarga itu pergi.\nTinggal kamu, sendirian, menunggu di sebalik dinding.|Bertahun-tahun kamu menjaga setiap bilik, setiap perabot, setiap kenangan.|Malam ini, orang asing datang.\nMereka mahu merobohkan rumah ini.|Rumah ini bukan milik mereka.\n\nBuat mereka takut. Buat mereka pergi.",
            "This house was once full of laughter.\nLong dinners. Lights that never went out.|Then the family left.\nOnly you remained, alone, waiting behind the walls.|For years you watched over every room, every piece of furniture, every memory.|Tonight, strangers arrive.\nThey want to tear this house down.|This house isn't theirs.\n\nScare them. Make them leave.");
        Add("story.epilog.pages",
            "Pintu terakhir tertutup.\nLangkah-langkah yang berlari itu hilang di hujung jalan.|Rumah kembali sunyi.\nTiada lagi orang asing. Tiada lagi jentolak.|Menjelang subuh, kamu duduk di tingkap tingkat atas dan melihat matahari naik.|Mereka akan bercerita tentang rumah ini.\nTentang lampu yang jatuh, pasu yang pecah, dan bayang-bayang di tangga.|Rumah ini selamat.\nUntuk malam ini.\n\nTAMAT|Terima kasih kerana bermain.",
            "The last door closes.\nThe running footsteps fade down the road.|The house is quiet again.\nNo more strangers. No more bulldozers.|Near dawn, you sit at the top-floor window and watch the sun rise.|They'll tell stories about this house.\nAbout falling lamps, shattered vases, and shadows on the stairs.|The house is safe.\nFor tonight.\n\nTHE END|Thanks for playing.");
    }
}
