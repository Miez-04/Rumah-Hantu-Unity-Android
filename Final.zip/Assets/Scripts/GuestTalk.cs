using UnityEngine;

/// <summary>
/// Ayat-ayat tetamu. Teks sebenar (Melayu dan English) berada dalam Loc.cs: ubah atau tambah ayat di sana.
/// Kelas ini hanya memilih ayat yang sesuai dengan jenis tetamu dan keadaan.
/// </summary>
public static class GuestTalk
{
    const int ConvoCount = 10;

    // Perbualan dua orang: baris selang-seli, mula dengan orang pertama.
    public static string[] Convo()
    {
        return Loc.Arr("convo." + (Random.Range(0, ConvoCount) + 1));
    }

    // Gumaman bersendirian.
    public static string Mutter(string type)
    {
        if (type == "penakut") return Loc.Pick("talk.nervous");
        if (type == "berani") return Loc.Pick("talk.brave");
        return Loc.Pick("talk.neutral");
    }

    public static string Heard() { return Loc.Pick("talk.heard"); }
    public static string Go(string type) { return Loc.Pick(type == "berani" ? "talk.bravego" : "talk.go"); }
    public static string Dismiss(string type) { return Loc.Pick(type == "berani" ? "talk.bravedismiss" : "talk.dismiss"); }
    public static string Company() { return Loc.Pick("talk.company"); }
    public static string Alone() { return Loc.Pick("talk.alone"); }
    public static string NoWay() { return Loc.Pick("talk.noway"); }
    public static string Calm() { return Loc.Pick("talk.calm"); }
    public static string Flee() { return Loc.Pick("talk.flee"); }

    // Reaksi apabila ditakutkan.
    public static string React(ScareKind kind)
    {
        switch (kind)
        {
            case ScareKind.Impact: return Loc.T("react.Impact");
            case ScareKind.Smash: return Loc.T("react.Smash");
            case ScareKind.Sound: return Loc.T("react.Sound");
            case ScareKind.Light: return Loc.T("react.Light");
            case ScareKind.Shake: return Loc.T("react.Shake");
            case ScareKind.Panic: return Loc.T("react.Panic");
            default: return Loc.T("react.Move");
        }
    }
}
