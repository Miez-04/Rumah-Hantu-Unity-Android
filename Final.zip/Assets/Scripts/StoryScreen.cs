using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

/// <summary>
/// Skrin cerita (prolog / epilog) dengan latar bergerak yang dilukis melalui kod.
/// Ketuk untuk teruskan. Ketuk penjuru kanan atas untuk langkau.
/// </summary>
public class StoryScreen : MonoBehaviour
{
    [Tooltip("Kunci Loc: prolog atau epilog. Teks ada dalam Loc.cs (story.<kunci>.pages dan story.<kunci>.title)")]
    public string storyKey = "prolog";

    [Tooltip("Kosong = terus ke permainan (HouseSelector.LoadNext)")]
    public string nextScene = "";

    [Tooltip("Scene sandaran untuk HouseSelector (sama seperti MainMenu.gameScene)")]
    public string gameScene = "Main";

    [Header("Latar")]
    public bool showScene = true;
    [Tooltip("Hidupkan untuk epilog: subuh, tingkap padam, tiada kelawar")]
    public bool dawn = false;

    [Header("Teks")]
    public float charsPerSecond = 35f;
    public float fadeTime = 0.6f;
    public Color textColor = new Color(0.9f, 0.93f, 1f);

    [Header("Tunjuk sekali sahaja (prolog)")]
    public bool showOnlyOnce = false;
    public string onceKey = StoryFlow.PrologSeenKey;

    class Blink { public Image img; public float speed, phase, min; }
    class Cloud { public RectTransform rt; public float speed, x0, y; }
    class Bat { public Image img; public float speed, x0, y, amp, phase; }

    readonly List<Blink> blinks = new List<Blink>();
    readonly List<Cloud> clouds = new List<Cloud>();
    readonly List<Bat> bats = new List<Bat>();
    Sprite[] batFrames;
    RectTransform ghost;
    Vector2 ghostBase;
    bool sceneReady;

    Text body, hint, skip, titleText;
    CanvasGroup group;
    bool tapped, skipAll;

    void Start()
    {
        Time.timeScale = 1f; // GameManager / PauseMenu mungkin tinggalkan 0

        if (showOnlyOnce && PlayerPrefs.GetInt(onceKey, 0) == 1)
        {
            GoNext();
            return;
        }
        BuildUI();
        StartCoroutine(Run());
    }

    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            Vector2 p = Input.mousePosition;
            if (p.x > Screen.width * 0.78f && p.y > Screen.height * 0.85f) skipAll = true;
            else tapped = true;
        }
        if (sceneReady) Animate();
    }

    void GoNext()
    {
        if (!string.IsNullOrEmpty(nextScene)) SceneManager.LoadScene(nextScene);
        else HouseSelector.LoadNext(gameScene); // rumah rawak, sama seperti MainMenu.Play()
    }

    IEnumerator Run()
    {
        yield return Fade(0f, 1f);

        for (int pi = 0; ; pi++)
        {
            string[] all = Loc.Arr("story." + storyKey + ".pages"); // ikut bahasa semasa
            if (pi >= all.Length || skipAll) break;
            string page = all[pi];
            body.text = "";
            hint.enabled = false;
            tapped = false;

            float t = 0f;
            int n = page.Length;
            while (!skipAll && !tapped && (int)t < n)
            {
                t += Time.unscaledDeltaTime * charsPerSecond;
                body.text = page.Substring(0, Mathf.Min(n, (int)t));
                yield return null;
            }
            body.text = page;
            tapped = false;

            hint.enabled = true;
            while (!skipAll && !tapped) yield return null;
        }

        if (showOnlyOnce) { PlayerPrefs.SetInt(onceKey, 1); PlayerPrefs.Save(); }
        yield return Fade(1f, 0f);
        GoNext();
    }

    IEnumerator Fade(float from, float to)
    {
        float t = 0f;
        while (t < fadeTime)
        {
            t += Time.unscaledDeltaTime;
            group.alpha = Mathf.Lerp(from, to, t / fadeTime);
            yield return null;
        }
        group.alpha = to;
    }

    // ------------------------------------------------------------ animasi
    void Animate()
    {
        float t = Time.unscaledTime;

        foreach (Blink b in blinks)
        {
            float n = Mathf.PerlinNoise(t * b.speed, b.phase);
            float a = Mathf.Lerp(b.min, 1f, Mathf.Clamp01((n - 0.3f) * 4f));
            Color col = b.img.color; col.a = a; b.img.color = col;
        }
        foreach (Cloud cl in clouds)
        {
            float x = Mathf.Repeat(cl.x0 + t * cl.speed, 2400f) - 450f;
            cl.rt.anchoredPosition = new Vector2(x, cl.y);
        }
        foreach (Bat b in bats)
        {
            float x = 2050f - Mathf.Repeat(b.x0 + t * b.speed, 2500f);
            float y = b.y + Mathf.Sin(t * 2f + b.phase) * b.amp;
            b.img.rectTransform.anchoredPosition = new Vector2(x, y);
            b.img.sprite = batFrames[((int)(t * 7f + b.phase)) % 2];
        }
        if (ghost != null)
            ghost.anchoredPosition = ghostBase + new Vector2(Mathf.Sin(t * 0.7f) * 25f, Mathf.Sin(t * 1.6f) * 14f);
    }

    // ------------------------------------------------------------ UI
    void BuildUI()
    {
        var canvasGo = new GameObject("StoryCanvas");
        var canvas = canvasGo.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        var scaler = canvasGo.AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);
        scaler.matchWidthOrHeight = 0.5f;
        group = canvasGo.AddComponent<CanvasGroup>();
        group.alpha = 0f;

        Color sky = showScene ? (dawn ? H("#3b3a72") : H("#0f1226")) : Color.black;
        var bg = new GameObject("BG").AddComponent<Image>();
        bg.transform.SetParent(canvasGo.transform, false);
        bg.color = sky;
        bg.raycastTarget = false;
        bg.rectTransform.anchorMin = Vector2.zero; bg.rectTransform.anchorMax = Vector2.one;
        bg.rectTransform.offsetMin = bg.rectTransform.offsetMax = Vector2.zero;

        if (showScene) BuildScene(canvasGo.transform, sky);

        Font f = null;
        try { f = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf"); } catch { }
        if (f == null) f = Font.CreateDynamicFontFromOSFont("Arial", 40);

        if (showScene)
        {
            var band = new GameObject("Band").AddComponent<Image>();
            band.transform.SetParent(canvasGo.transform, false);
            band.color = new Color(0.02f, 0.02f, 0.06f, 0.78f);
            band.raycastTarget = false;
            band.rectTransform.anchorMin = Vector2.zero; band.rectTransform.anchorMax = new Vector2(1f, 0.23f);
            band.rectTransform.offsetMin = band.rectTransform.offsetMax = Vector2.zero;
        }

        titleText = MakeText(canvasGo.transform, f, Loc.T("story." + storyKey + ".title"), 36, TextAnchor.UpperCenter,
            new Vector2(0.1f, 0.9f), new Vector2(0.9f, 0.98f));
        titleText.color = new Color(textColor.r, textColor.g, textColor.b, 0.55f);

        body = showScene
            ? MakeText(canvasGo.transform, f, "", 40, TextAnchor.MiddleCenter, new Vector2(0.08f, 0.05f), new Vector2(0.92f, 0.23f))
            : MakeText(canvasGo.transform, f, "", 54, TextAnchor.MiddleCenter, new Vector2(0.1f, 0.2f), new Vector2(0.9f, 0.8f));

        hint = showScene
            ? MakeText(canvasGo.transform, f, Loc.T("story.tap"), 26, TextAnchor.LowerCenter, new Vector2(0.1f, 0f), new Vector2(0.9f, 0.05f))
            : MakeText(canvasGo.transform, f, Loc.T("story.tap"), 34, TextAnchor.LowerCenter, new Vector2(0.1f, 0.04f), new Vector2(0.9f, 0.14f));
        hint.color = new Color(textColor.r, textColor.g, textColor.b, 0.5f);
        hint.enabled = false;

        skip = MakeText(canvasGo.transform, f, Loc.T("story.skip"), 32, TextAnchor.UpperRight,
            new Vector2(0.7f, 0.9f), new Vector2(0.98f, 0.98f));
        skip.color = new Color(textColor.r, textColor.g, textColor.b, 0.5f);
    }

    void BuildScene(Transform canvas, Color sky)
    {
        var go = new GameObject("Scene", typeof(RectTransform));
        var root = go.GetComponent<RectTransform>();
        root.SetParent(canvas, false);
        root.anchorMin = root.anchorMax = root.pivot = new Vector2(0.5f, 0.5f);
        root.sizeDelta = new Vector2(1920f, 1080f);
        root.anchoredPosition = Vector2.zero;

        Sprite circle = CircleSprite(48);
        Color body_ = dawn ? H("#24203f") : H("#1c1830");
        Color roof = dawn ? H("#1a1733") : H("#14112a");
        Color dark = H("#0d0b1c");
        Color cloudCol = dawn ? H("#5a5590") : H("#232748");

        if (dawn)
        {
            Image sun = R(root, 1380f, 140f, 260f, 260f, H("#ffb36b"));
            sun.sprite = circle;
        }
        else
        {
            Image moon = R(root, 230f, 780f, 150f, 150f, H("#f1ead0")); moon.sprite = circle;
            Image cut = R(root, 266f, 798f, 130f, 130f, sky); cut.sprite = circle;

            var rnd = new System.Random(7);
            for (int i = 0; i < 28; i++)
            {
                float s = rnd.Next(0, 3) == 0 ? 8f : 5f;
                Image st = R(root, rnd.Next(40, 1880), rnd.Next(520, 1060), s, s, Color.white);
                blinks.Add(new Blink { img = st, speed = 0.4f + (float)rnd.NextDouble() * 0.6f, phase = (float)rnd.NextDouble() * 50f, min = 0.25f });
            }
        }

        float[] cy = { 880f, 770f, 960f };
        float[] cw = { 300f, 380f, 240f };
        float[] cs = { 22f, 14f, 30f };
        for (int i = 0; i < 3; i++)
        {
            Image c = R(root, 0f, cy[i], cw[i], 36f, cloudCol);
            clouds.Add(new Cloud { rt = c.rectTransform, speed = cs[i], x0 = i * 800f, y = cy[i] });
        }

        if (!dawn)
        {
            batFrames = new[] { BatSprite(true), BatSprite(false) };
            for (int i = 0; i < 3; i++)
            {
                Image b = R(root, 0f, 0f, 72f, 32f, Color.white);
                b.sprite = batFrames[0];
                bats.Add(new Bat { img = b, speed = 150f + i * 40f, x0 = i * 900f, y = 700f + i * 90f, amp = 30f, phase = i * 1.7f });
            }
        }

        // pokok mati
        Color tree = dawn ? H("#15132a") : dark;
        R(root, 300f, 240f, 36f, 300f, tree);
        R(root, 230f, 420f, 110f, 20f, tree);
        R(root, 300f, 480f, 130f, 20f, tree);
        R(root, 340f, 540f, 60f, 18f, tree);

        // bumbung berundak
        for (int i = 0; i < 5; i++) R(root, 520f + i * 70f, 640f + i * 40f, 880f - 140f * i, 40f, roof);
        R(root, 1180f, 700f, 50f, 110f, body_);

        // badan rumah
        R(root, 560f, 240f, 800f, 400f, body_);
        R(root, 880f, 700f, 160f, 140f, body_);
        for (int i = 0; i < 4; i++) R(root, 850f + i * 25f, 840f + i * 30f, 220f - 50f * i, 30f, roof);

        // tingkap
        Color amber = H("#f5c56a");
        Color offWin = H("#2b2548");
        Window(root, 620f, 470f, 100f, 110f, amber, body_, !dawn, 1.2f, 3f);
        Window(root, 1200f, 470f, 100f, 110f, amber, body_, !dawn, 1.0f, 9f);
        Window(root, 910f, 470f, 100f, 110f, amber, body_, !dawn, 0.8f, 17f);
        Window(root, 620f, 300f, 100f, 90f, offWin, body_, false, 0f, 0f);
        Window(root, 1200f, 300f, 100f, 90f, amber, body_, !dawn, 1.4f, 23f);
        Window(root, 930f, 730f, 60f, 80f, amber, body_, !dawn, 1.1f, 31f);

        // pintu
        R(root, 900f, 240f, 120f, 190f, dark);
        R(root, 910f, 430f, 100f, 20f, dark);

        // tanah (besar supaya menutup semua nisbah skrin)
        R(root, -1500f, -1500f, 4920f, 1740f, dawn ? H("#15142a") : H("#0a0a16"));

        // hantu
        ghostBase = new Vector2(1470f, 560f);
        Sprite gs = GhostSprite();
        Image g = R(root, ghostBase.x, ghostBase.y, gs.rect.width * 12f, gs.rect.height * 12f, Color.white);
        g.sprite = gs;
        ghost = g.rectTransform;

        sceneReady = true;
    }

    void Window(RectTransform root, float x, float y, float w, float h, Color c, Color bar, bool blink, float speed, float phase)
    {
        Image win = R(root, x, y, w, h, c);
        if (blink) blinks.Add(new Blink { img = win, speed = speed, phase = phase, min = 0.3f });
        R(root, x + w / 2f - 4f, y, 8f, h, bar);
        R(root, x, y + h / 2f - 4f, w, 8f, bar);
    }

    Image R(Transform parent, float x, float y, float w, float h, Color c)
    {
        var img = new GameObject("r").AddComponent<Image>();
        img.raycastTarget = false;
        img.color = c;
        var rt = img.rectTransform;
        rt.SetParent(parent, false);
        rt.anchorMin = rt.anchorMax = rt.pivot = Vector2.zero;
        rt.anchoredPosition = new Vector2(x, y);
        rt.sizeDelta = new Vector2(w, h);
        return img;
    }

    Text MakeText(Transform parent, Font f, string s, int size, TextAnchor anchor, Vector2 min, Vector2 max)
    {
        var t = new GameObject("Text").AddComponent<Text>();
        t.transform.SetParent(parent, false);
        t.font = f;
        t.text = s;
        t.fontSize = size;
        t.alignment = anchor;
        t.color = textColor;
        t.lineSpacing = 1.2f;
        t.horizontalOverflow = HorizontalWrapMode.Wrap;
        t.verticalOverflow = VerticalWrapMode.Overflow;
        t.raycastTarget = false;
        var rt = t.rectTransform;
        rt.anchorMin = min; rt.anchorMax = max;
        rt.offsetMin = rt.offsetMax = Vector2.zero;
        return t;
    }

    // ------------------------------------------------------------ sprite pixel dari kod
    static Color H(string hex) { Color c; ColorUtility.TryParseHtmlString(hex, out c); return c; }

    static Sprite Pixels(string[] rowsTopDown, Dictionary<char, Color> pal)
    {
        int h = rowsTopDown.Length, w = rowsTopDown[0].Length;
        var tex = new Texture2D(w, h, TextureFormat.RGBA32, false);
        tex.filterMode = FilterMode.Point;
        tex.wrapMode = TextureWrapMode.Clamp;
        var px = new Color32[w * h];
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
            {
                Color c;
                px[y * w + x] = pal.TryGetValue(rowsTopDown[h - 1 - y][x], out c) ? (Color32)c : new Color32(0, 0, 0, 0);
            }
        tex.SetPixels32(px);
        tex.Apply();
        return Sprite.Create(tex, new Rect(0, 0, w, h), new Vector2(0.5f, 0.5f), 1f);
    }

    static Sprite GhostSprite()
    {
        var pal = new Dictionary<char, Color> { { '#', H("#cfe4ff") }, { 'e', H("#0f1226") }, { 'o', H("#7f9fd0") } };
        return Pixels(new[]
        {
            "...######...",
            ".##########.",
            "############",
            "##ee####ee##",
            "##ee####ee##",
            "############",
            "#####oo#####",
            "############",
            "############",
            "############",
            "####.##.####",
            "###..##..###"
        }, pal);
    }

    static Sprite BatSprite(bool up)
    {
        var pal = new Dictionary<char, Color> { { '#', H("#3a3260") } };
        return Pixels(up
            ? new[] { "#.......#", "##.#.#.##", ".#######.", "...###..." }
            : new[] { "..#####..", ".#######.", "##.###.##", "#...#...#" }, pal);
    }

    static Sprite CircleSprite(int d)
    {
        var tex = new Texture2D(d, d, TextureFormat.RGBA32, false);
        tex.filterMode = FilterMode.Point;
        tex.wrapMode = TextureWrapMode.Clamp;
        var px = new Color32[d * d];
        float r = d / 2f;
        for (int y = 0; y < d; y++)
            for (int x = 0; x < d; x++)
            {
                float dx = x + 0.5f - r, dy = y + 0.5f - r;
                px[y * d + x] = dx * dx + dy * dy <= r * r ? new Color32(255, 255, 255, 255) : new Color32(0, 0, 0, 0);
            }
        tex.SetPixels32(px);
        tex.Apply();
        return Sprite.Create(tex, new Rect(0, 0, d, d), new Vector2(0.5f, 0.5f), 1f);
    }
}
