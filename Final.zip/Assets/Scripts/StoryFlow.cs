using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>
/// Pintu masuk cerita.
///  - Butang Main di menu    -> StoryFlow.StartGame(gameScene)
///  - Menang level terakhir  -> StoryFlow.ShowEpilog()  (sudah ada dalam tampalan GameManager)
/// </summary>
public static class StoryFlow
{
    public const string PrologScene = "Prolog";
    public const string EpilogScene = "Epilog";
    public const string PrologSeenKey = "story_prolog_seen";

    public static void StartGame(string gameScene)
    {
        Time.timeScale = 1f;
        GameManager.LevelIndex = 0;
        if (PlayerPrefs.GetInt(PrologSeenKey, 0) == 1) HouseSelector.LoadNext(gameScene);
        else SceneManager.LoadScene(PrologScene);
    }

    public static void ShowEpilog()
    {
        Time.timeScale = 1f;
        GameManager.LevelIndex = 0;
        SceneManager.LoadScene(EpilogScene);
    }

    public static void ResetPrologSeen()
    {
        PlayerPrefs.DeleteKey(PrologSeenKey);
    }
}
