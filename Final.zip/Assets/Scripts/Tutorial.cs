using UnityEngine;

/// <summary>
/// Tutorial level pertama. Ditambah sendiri oleh GameManager pada Malam 1 selagi belum selesai atau dilangkau.
/// Langkah maju bila pemain benar-benar melakukan tindakan itu (bukan ikut masa), dan perabot terdekat
/// diserlahkan dengan cincin berdenyut. Boleh ditetapkan semula dari Menu > Tetapan > Ulang Tutorial.
/// </summary>
public class Tutorial : MonoBehaviour
{
    public const string DoneKey = "tutorial_done";

    // Kawasan butang LANGKAU (unit GUI) supaya GhostController tak anggap ketukan itu sebagai arahan terbang.
    static Rect skipRect;
    static float skipScale = 1f;
    static bool skipActive;

    public static bool Blocks(Vector2 screenPos)
    {
        if (!skipActive) return false;
        Vector2 g = new Vector2(screenPos.x / skipScale, (Screen.height - screenPos.y) / skipScale);
        Rect r = new Rect(skipRect.x - 8f, skipRect.y - 8f, skipRect.width + 16f, skipRect.height + 16f);
        return r.Contains(g);
    }

    const int StepCount = 5; // teks langkah: kunci "tut.1" hingga "tut.5" dalam Loc.cs

    int step;
    float stepStart;
    float doneAt = -1f;
    Vector2 startPos;
    Possessable[] props;

    // Mulakan (atau mulakan semula) tutorial pada objek tuan rumah, contohnya dari menu jeda.
    public static void Begin(GameObject host)
    {
        Tutorial t = host.GetComponent<Tutorial>();
        if (t == null) host.AddComponent<Tutorial>();
        else t.Restart();
    }

    void Start()
    {
        Restart();
    }

    void Restart()
    {
        step = 0;
        stepStart = Time.time;
        doneAt = -1f;
        if (GhostController.Instance != null) startPos = GhostController.Instance.transform.position;
#if UNITY_2023_1_OR_NEWER
        props = Object.FindObjectsByType<Possessable>(FindObjectsSortMode.None);
#else
        props = Object.FindObjectsOfType<Possessable>();
#endif
    }

    void Update()
    {
        if (doneAt >= 0f)
        {
            if (Time.time - doneAt > 3f) Destroy(this);
            return;
        }

        GameManager gm = GameManager.Instance;
        GhostController gc = GhostController.Instance;
        if (gm == null || gc == null || gm.State != GameState.Playing || Time.timeScale <= 0f) return;

        bool ok = false;
        switch (step)
        {
            case 0: ok = Vector2.Distance(gc.transform.position, startPos) > 2f; break;
            case 1: ok = gc.IsPossessing; break;
            case 2: ok = AnyFear(15f); break;
            case 3: ok = gc.Energy < gc.maxEnergy - 1f; break;
            case 4: ok = AnyFled(); break;
        }
        if (!ok) return;

        step++;
        stepStart = Time.time;
        AudioManager.Play("click", 0.8f, 1.4f, 0f);
        if (step >= StepCount)
        {
            PlayerPrefs.SetInt(DoneKey, 1);
            PlayerPrefs.Save();
            doneAt = Time.time;
        }
    }

    bool AnyFear(float amount)
    {
        foreach (HumanAI h in GameManager.Instance.Humans)
            if (h != null && h.fear >= amount) return true;
        return false;
    }

    bool AnyFled()
    {
        foreach (HumanAI h in GameManager.Instance.Humans)
            if (h != null && (h.Current == HumanAI.State.Flee || h.Current == HumanAI.State.Gone)) return true;
        return false;
    }

    void Skip()
    {
        PlayerPrefs.SetInt(DoneKey, 1);
        PlayerPrefs.Save();
        Destroy(this);
    }

    void OnDestroy()
    {
        skipActive = false;
    }

    void OnGUI()
    {
        skipActive = false;
        if (Time.timeScale <= 0f) return;
        GameManager gm = GameManager.Instance;
        GhostController gc = GhostController.Instance;
        if (gm == null || gm.State != GameState.Playing) return;

        float s = Screen.height / 540f;
        GUI.matrix = Matrix4x4.Scale(new Vector3(s, s, 1f));
        float W = Screen.width / s;

        bool finished = doneAt >= 0f;
        float appear = Mathf.Clamp01((Time.time - (finished ? doneAt : stepStart)) / 0.3f);

        string text;
        Color accent = UiKit.Warm;
        bool needPossess = !finished && gc != null && !gc.IsPossessing && step >= 1 && step <= 3;
        if (finished)
        {
            text = Loc.T("tut.done");
            accent = UiKit.Ghost;
        }
        else if (needPossess && step > 1) text = Loc.T("tut.again");
        else text = Loc.T("tut." + (step + 1));

        if (needPossess) DrawHighlight(s, gc);

        Color prev = GUI.color;
        GUI.color = new Color(1f, 1f, 1f, appear);

        Rect card = new Rect(W / 2f - 270f, 66f - (1f - appear) * 12f, 540f, 76f);
        UiKit.Round(card, UiKit.Panel, 18);
        UiKit.Ring(card, UiKit.WithAlpha(accent, 0.9f), 18, 2);

        if (!finished)
        {
            for (int i = 0; i < StepCount; i++)
                UiKit.Round(new Rect(card.x + 16f + i * 13f, card.y + 10f, 8f, 8f),
                            i <= step ? accent : new Color(0.4f, 0.4f, 0.6f, 0.6f), 4);
        }

        UiKit.Text(new Rect(card.x + 16f, card.y + 20f, card.width - 32f, card.height - 26f), text, 16,
                   UiKit.TextMain, TextAnchor.MiddleLeft, true, FontStyle.Bold, true);

        if (!finished)
        {
            Rect skip = new Rect(card.xMax - 82f, card.y + 5f, 72f, 20f);
            skipRect = skip;
            skipScale = s;
            skipActive = true;
            UiKit.Text(skip, Loc.T("tut.skip"), 11, UiKit.TextDim, TextAnchor.MiddleRight, false);
            if (GUI.Button(skip, GUIContent.none, GUIStyle.none)) Skip();
        }

        GUI.color = prev;
    }

    void DrawHighlight(float s, GhostController gc)
    {
        Possessable best = null;
        float bestD = float.MaxValue;
        Vector2 gp = gc.transform.position;
        foreach (Possessable p in props)
        {
            if (p == null || !p.gameObject.activeInHierarchy) continue;
            float d = ((Vector2)p.transform.position - gp).sqrMagnitude;
            if (d < bestD) { bestD = d; best = p; }
        }
        if (best == null) return;

        Camera cam = Camera.main;
        if (cam == null) return;
        Collider2D col = best.GetComponentInChildren<Collider2D>();
        Vector3 world = col != null ? (Vector3)col.bounds.center : best.transform.position;
        Vector3 sp = cam.WorldToScreenPoint(world);
        if (sp.z < 0f) return;

        Vector2 g = new Vector2(sp.x / s, (Screen.height - sp.y) / s);
        float pulse = 0.5f + 0.5f * Mathf.Sin(Time.time * 5f);
        float r = 34f + 8f * pulse;

        UiKit.Glow(new Rect(g.x - r * 1.7f, g.y - r * 1.7f, r * 3.4f, r * 3.4f), UiKit.WithAlpha(UiKit.Warm, 0.3f + 0.2f * pulse));
        UiKit.Ring(new Rect(g.x - r, g.y - r, r * 2f, r * 2f), UiKit.WithAlpha(UiKit.Warm, 0.9f), Mathf.RoundToInt(r), 3);

        Rect tag = new Rect(g.x - 38f, g.y - r - 30f, 76f, 22f);
        UiKit.Round(tag, UiKit.WithAlpha(UiKit.Warm, 0.95f), 11);
        UiKit.Text(tag, Loc.T("tut.tap"), 13, UiKit.Dark, TextAnchor.MiddleCenter, false);
    }
}
