using UnityEngine;

/// <summary>
/// Pintu bunyi: apabila sesuatu yang kuat berlaku (hentaman, kaca pecah, kuasa khas, jeritan), semua tetamu yang
/// cukup dekat "mendengar"nya dan boleh memutuskan untuk menyiasat. Dipanggil oleh Possessable.Noise() dan HumanAI.
///
/// Jarak dengar = jejari bunyi x HearMultiplier. Jarak menegak dikira lebih jauh (tingkat lain lebih sunyi).
/// </summary>
public static class NoiseHub
{
    public static float HearMultiplier = 1.6f;

    public static void Emit(Vector2 pos, ScareKind kind, float radius)
    {
        GameManager gm = GameManager.Instance;
        if (gm == null) return;

        float hear = radius * HearMultiplier;
        for (int i = 0; i < gm.Humans.Count; i++)
        {
            HumanAI h = gm.Humans[i];
            if (h != null) h.HearNoise(pos, kind, hear);
        }
    }
}
