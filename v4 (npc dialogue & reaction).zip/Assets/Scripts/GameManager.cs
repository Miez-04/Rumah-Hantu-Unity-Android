using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public enum GameState { Playing, Won, Lost }

[System.Serializable]
public class LevelConfig
{
    public string title = "Malam";
    public float seconds = 150f;
    public float energy = 0f; // 0 = automatik ikut bilangan tetamu
    public string[] humans = { "biasa", "penakut" }; // penakut | biasa | berani
}

// Night timer, win / lose, spawns the guests, and draws a simple IMGUI HUD (no Canvas needed).
public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }
    public static int LevelIndex = 0;

    [Header("Setup")]
    public GameObject humanPrefab;
    public LevelConfig[] levels = new LevelConfig[]
    {
        new LevelConfig { title = "Malam 1", seconds = 150f, humans = new string[] { "biasa", "penakut" } },
        new LevelConfig { title = "Malam 2", seconds = 150f, humans = new string[] { "biasa", "penakut", "berani" } },
        new LevelConfig { title = "Malam 3", seconds = 160f, humans = new string[] { "penakut", "biasa", "berani", "berani" } },
    };

    public GameState State { get; private set; }
    public List<HumanAI> Humans = new List<HumanAI>();
    public float TimeLeft { get; private set; }
    public int Remaining { get; private set; }
    public int Stars { get; private set; }

    LevelConfig level;
    int registered;
    float flashAlpha;
    int lastTick = -1;
    float endTime;
    int starsShown;
    string houseTitle = "";

    void Awake()
    {
        Instance = this;
        State = GameState.Playing;

        // Menu jeda sentiasa ada, walaupun scene tak dibina dengan alat editor.
#if UNITY_2023_1_OR_NEWER
        if (Object.FindFirstObjectByType<PauseMenu>() == null)
#else
        if (Object.FindObjectOfType<PauseMenu>() == null)
#endif
            new GameObject("PauseMenu").AddComponent<PauseMenu>();
        Application.targetFrameRate = 60;
        Screen.sleepTimeout = SleepTimeout.NeverSleep;
    }

    void Start()
    {
        if (levels == null || levels.Length == 0)
        {
            Debug.LogError("GameManager: add at least one level.");
            return;
        }
        LevelIndex = Mathf.Clamp(LevelIndex, 0, levels.Length - 1);
        level = levels[LevelIndex];
        TimeLeft = level.seconds;
        HouseInfo house = HouseInfo.Current;
        houseTitle = house != null ? house.title : "";
        if (GhostController.Instance != null)
            GhostController.Instance.SetupForGuests(level.humans != null ? level.humans.Length : 1, level.energy);
        AudioManager.Music("game");
        bool tutorialDone = PlayerPrefs.GetInt(Tutorial.DoneKey, 0) == 1;
        if (LevelIndex == 0 && !tutorialDone)
        {
            if (GetComponent<Tutorial>() == null) gameObject.AddComponent<Tutorial>();
        }
        else
        {
            Debug.Log("[Tutorial] tidak dipaparkan: " + (LevelIndex != 0
                ? "bukan Malam 1."
                : "sudah selesai atau dilangkau. Set semula di Tetapan > Ulang Tutorial, atau menu Ghost > Reset Tutorial."));
        }
        SpawnHumans();
    }

    void SpawnHumans()
    {
        if (humanPrefab == null)
        {
            Debug.LogError("GameManager: assign the Human Prefab.");
            return;
        }

        List<WaypointNode> spots = new List<WaypointNode>();
        foreach (WaypointNode n in WaypointNode.All)
            if (n.spawnable && !n.isExit) spots.Add(n);

        if (spots.Count == 0)
        {
            Debug.LogError("GameManager: no spawnable WaypointNodes in the scene.");
            return;
        }

        foreach (string type in level.humans)
        {
            WaypointNode n = spots[Random.Range(0, spots.Count)];
            GameObject go = Instantiate(humanPrefab, n.transform.position, Quaternion.identity);
            HumanAI h = go.GetComponent<HumanAI>();
            if (h != null) h.humanType = type;
        }
    }

    public void Register(HumanAI h)
    {
        if (!Humans.Contains(h))
        {
            Humans.Add(h);
            registered++;
            Remaining++;
        }
    }

    // White screen flash (lamp power). 0..1
    public void FlashScreen(float strength)
    {
        flashAlpha = Mathf.Max(flashAlpha, Mathf.Clamp01(strength));
    }

    public void HumanEvacuated(HumanAI h)
    {
        Remaining = Mathf.Max(0, Remaining - 1);
        AudioManager.Play("door", 0.7f);
    }

    void Update()
    {
        flashAlpha = Mathf.MoveTowards(flashAlpha, 0f, Time.deltaTime * 1.8f);
        if (State != GameState.Playing || level == null) return;

        TimeLeft -= Time.deltaTime;
        if (registered > 0 && Remaining <= 0)
        {
            State = GameState.Won;
            float ratio = TimeLeft / Mathf.Max(1f, level.seconds);
            Stars = ratio > 0.5f ? 3 : (ratio > 0.25f ? 2 : 1);
            AudioManager.Music(null);
            AudioManager.Play("win");
            endTime = Time.time;
            starsShown = 0;
        }
        else if (TimeLeft <= 0f)
        {
            TimeLeft = 0f;
            State = GameState.Lost;
            AudioManager.Music(null);
            AudioManager.Play("lose");
            endTime = Time.time;
        }
        else if (TimeLeft <= 10f)
        {
            int sec = Mathf.CeilToInt(TimeLeft);
            if (sec != lastTick)
            {
                lastTick = sec;
                AudioManager.Play("tick", 0.6f, 1f, 0f);
            }
        }
    }

    void Reload()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    void OnGUI()
    {
        if (Time.timeScale <= 0f) return; // jeda: sembunyikan HUD di belakang panel jeda

        float s = Screen.height / 540f;
        GUI.matrix = Matrix4x4.Scale(new Vector3(s, s, 1f));
        float W = Screen.width / s;
        const float H = 540f;

        if (flashAlpha > 0.01f)
        {
            GUI.color = new Color(1f, 1f, 1f, flashAlpha);
            GUI.DrawTexture(new Rect(0f, 0f, W, H), Texture2D.whiteTexture);
            GUI.color = Color.white;
        }

        DrawHud(W, H);
        if (State != GameState.Playing) DrawEndScreen(W, H);
    }

    // ------------------------------------------------------------ HUD
    void DrawHud(float W, float H)
    {
        GhostController gc = GhostController.Instance;
        bool playing = State == GameState.Playing;

        // --- lencana malam (kiri atas)
        string title = level != null ? level.title.ToUpper() : "";
        Rect chip = new Rect(12f, 10f, 132f, 34f);
        UiKit.Round(chip, UiKit.HudPanel, 17);
        UiKit.Ring(chip, UiKit.PanelEdge, 17, 2);
        UiKit.Text(chip, title, 17, UiKit.Ghost);
        if (houseTitle.Length > 0)
            UiKit.Text(new Rect(chip.xMax + 10f, chip.y, 240f, chip.height), houseTitle, 14, UiKit.TextDim,
                       TextAnchor.MiddleLeft, true, FontStyle.Italic);

        // --- pemasa (tengah) + jalur baki masa
        int t = Mathf.CeilToInt(TimeLeft);
        string time = (t / 60) + ":" + (t % 60).ToString("00");
        bool urgent = playing && TimeLeft < 20f;
        float pulse = urgent ? 0.5f + 0.5f * Mathf.Sin(Time.time * 8f) : 0f;
        Rect timeR = new Rect(W / 2f - 62f, 8f, 124f, 40f);
        UiKit.Round(timeR, UiKit.HudPanel, 20);
        UiKit.Ring(timeR, urgent ? Color.Lerp(UiKit.PanelEdge, UiKit.Danger, 0.4f + 0.6f * pulse) : UiKit.PanelEdge, 20, 2);
        UiKit.Text(timeR, time, 27, urgent ? Color.Lerp(UiKit.TextMain, UiKit.Danger, 0.5f + 0.5f * pulse) : UiKit.TextMain);

        float ratio = level != null ? Mathf.Clamp01(TimeLeft / Mathf.Max(1f, level.seconds)) : 0f;
        Rect track = new Rect(W / 2f - 50f, 52f, 100f, 5f);
        UiKit.Round(track, new Color(0f, 0f, 0.05f, 0.5f), 3);
        if (ratio > 0.01f)
            UiKit.Round(new Rect(track.x, track.y, Mathf.Max(5f, track.width * ratio), track.height),
                        Color.Lerp(UiKit.Danger, UiKit.Ghost, Mathf.Clamp01(ratio * 1.6f)), 3);

        // --- tetamu tinggal (kanan atas)
        Rect guests = new Rect(W - 12f - 150f, 10f, 150f, 34f);
        UiKit.Round(guests, UiKit.HudPanel, 17);
        UiKit.Ring(guests, UiKit.PanelEdge, 17, 2);
        UiKit.Text(new Rect(guests.x + 14f, guests.y, 90f, guests.height), "TINGGAL", 13, UiKit.TextDim, TextAnchor.MiddleLeft);
        UiKit.Text(new Rect(guests.x, guests.y, guests.width - 16f, guests.height), Remaining.ToString(), 24, UiKit.Warm, TextAnchor.MiddleRight);

        // --- bar tenaga (kiri, bawah lencana)
        float e = gc != null ? gc.Energy01 : 0f;
        bool denied = gc != null && Time.time - gc.LastDeniedTime < 1.2f;
        bool low = playing && e < 0.25f;

        UiKit.Text(new Rect(16f, 50f, 200f, 16f), "TENAGA HANTU", 12, UiKit.TextDim, TextAnchor.MiddleLeft, true);
        if (gc != null && gc.IsRefilling)
            UiKit.Text(new Rect(112f, 50f, 138f, 16f), "mengisi +", 12, UiKit.Ghost, TextAnchor.MiddleRight, true);
        Rect bar = new Rect(12f, 68f, 240f, 26f);
        UiKit.Round(bar, new Color(0.03f, 0.02f, 0.09f, 0.82f), 13);

        float fw = (bar.width - 6f) * e;
        if (fw > 1f)
        {
            Rect fill = new Rect(bar.x + 3f, bar.y + 3f, Mathf.Max(fw, 8f), bar.height - 6f);
            Color fc = e > 0.5f ? Color.Lerp(UiKit.GhostDeep, UiKit.Ghost, (e - 0.5f) * 2f)
                                : Color.Lerp(UiKit.Danger, UiKit.GhostDeep, e * 2f);
            UiKit.Round(fill, fc, 10);
            UiKit.Round(new Rect(fill.x + 3f, fill.y + 2f, Mathf.Max(2f, fill.width - 6f), (fill.height - 4f) * 0.42f),
                        new Color(1f, 1f, 1f, 0.28f), 5); // kilauan
        }

        Color ringCol = UiKit.PanelEdge;
        if (denied || low)
        {
            float p = 0.5f + 0.5f * Mathf.Sin(Time.time * (denied ? 24f : 6f));
            ringCol = Color.Lerp(UiKit.PanelEdge, UiKit.Danger, denied ? 0.5f + 0.5f * p : 0.3f + 0.7f * p);
        }
        UiKit.Ring(bar, ringCol, 13, denied ? 3 : 2);

        if (gc != null)
            UiKit.Text(bar, Mathf.CeilToInt(gc.Energy) + " / " + Mathf.RoundToInt(gc.maxEnergy), 15, UiKit.TextMain);

        if (denied)
        {
            Rect warn = new Rect(12f, 100f, 200f, 24f);
            UiKit.Round(warn, UiKit.WithAlpha(UiKit.Danger, 0.9f), 12);
            UiKit.Text(warn, "TENAGA TIDAK CUKUP", 14, Color.white);
        }

        // --- petunjuk bawah (bila tak merasuk)
        if (playing && gc != null && !gc.IsPossessing)
        {
            Rect hint = new Rect(W / 2f - 330f, H - 36f, 660f, 26f);
            UiKit.Round(hint, new Color(0.04f, 0.03f, 0.1f, 0.55f), 13);
            UiKit.Text(hint, "Joystick untuk terbang  |  ketuk perabot untuk merasuk", 14, UiKit.TextMain,
                       TextAnchor.MiddleCenter, false, FontStyle.Normal);
        }
    }

    // ------------------------------------------------------------ Skrin BERJAYA / MASA TAMAT
    void DrawEndScreen(float W, float H)
    {
        float age = Time.time - endTime;
        float appear = Mathf.Clamp01(age / 0.35f);
        float ease = 1f - (1f - appear) * (1f - appear) * (1f - appear);

        GUI.color = new Color(0f, 0f, 0.04f, 0.72f * appear);
        GUI.DrawTexture(new Rect(0f, 0f, W, H), Texture2D.whiteTexture);
        GUI.color = new Color(1f, 1f, 1f, ease); // semua di bawah ini pudar masuk

        bool won = State == GameState.Won;
        bool lastLevel = levels != null && LevelIndex >= levels.Length - 1;
        Color accent = won ? UiKit.Ghost : UiKit.Danger;

        float pw = 480f;
        float ph = won ? 340f : 270f;
        Rect panel = new Rect(W / 2f - pw / 2f, H / 2f - ph / 2f + (1f - ease) * 36f, pw, ph);

        UiKit.Glow(new Rect(panel.x - 70f, panel.y - 70f, panel.width + 140f, panel.height + 140f), UiKit.WithAlpha(accent, 0.2f));
        UiKit.Round(panel, UiKit.Panel, 30);
        UiKit.Ring(panel, UiKit.WithAlpha(accent, 0.85f), 30, 3);

        string head = won ? (lastLevel ? "TAMAT!" : "BERJAYA!") : "MASA TAMAT";
        string sub = won ? (lastLevel ? "Terima kasih kerana bermain" : "Semua tetamu lari ketakutan")
                         : "Masih ada tetamu di dalam rumah";
        UiKit.Text(new Rect(panel.x, panel.y + 22f, panel.width, 64f), head, 50, accent);
        UiKit.Text(new Rect(panel.x, panel.y + 84f, panel.width, 26f), sub, 17, UiKit.TextDim,
                   TextAnchor.MiddleCenter, false, FontStyle.Normal);

        if (won)
        {
            for (int i = 0; i < 3; i++)
            {
                bool earned = i < Stars;
                float st = age - 0.5f - i * 0.3f;
                Vector2 c = new Vector2(W / 2f + (i - 1) * 84f, panel.y + 150f);
                if (earned && st >= 0f)
                {
                    if (i >= starsShown)
                    {
                        starsShown = i + 1;
                        AudioManager.Play("click", 0.7f, 1.1f + 0.25f * i, 0f);
                    }
                    float sz = 62f * (1f + 0.55f * (1f - Mathf.Clamp01(st / 0.35f)));
                    UiKit.Glow(new Rect(c.x - sz, c.y - sz, sz * 2f, sz * 2f), UiKit.WithAlpha(UiKit.Warm, 0.35f));
                    UiKit.Star(new Rect(c.x - sz / 2f, c.y - sz / 2f, sz, sz), UiKit.Warm);
                }
                else
                {
                    float sz = 54f;
                    UiKit.Star(new Rect(c.x - sz / 2f, c.y - sz / 2f, sz, sz), new Color(0.3f, 0.3f, 0.45f, 0.55f));
                }
            }
        }

        // --- butang (dilukis sendiri; GUI.Button tanpa gaya hanya untuk kesan sentuh)
        string caption = won ? (lastLevel ? "Main Semula" : "Malam Seterusnya") : "Cuba Lagi";
        Rect btn = new Rect(W / 2f - 130f, panel.yMax - 76f, 260f, 54f);
        bool pressed = Input.GetMouseButton(0) && btn.Contains(Event.current.mousePosition);
        Rect vis = btn;
        if (pressed) vis.y += 3f;
        UiKit.Round(vis, pressed ? Color.Lerp(accent, Color.black, 0.25f) : accent, 27);
        UiKit.Ring(vis, new Color(1f, 1f, 1f, 0.4f), 27, 2);
        UiKit.Text(vis, caption.ToUpper(), 22, UiKit.Dark, TextAnchor.MiddleCenter, false);

        if (GUI.Button(btn, GUIContent.none, GUIStyle.none) && age > 0.4f)
        {
            AudioManager.Play("click", 0.7f);
            if (won)
            {
                LevelIndex = lastLevel ? 0 : LevelIndex + 1;
                HouseSelector.LoadNext(null); // rumah rawak seterusnya (muat semula scene ini jika tiada rumah dibina)
            }
            else
            {
                Reload(); // Cuba Lagi: rumah yang sama
            }
        }

        GUI.color = Color.white;
    }
}
