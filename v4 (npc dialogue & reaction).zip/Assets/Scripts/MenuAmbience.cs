using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Suasana menu utama: wisp cahaya yang naik perlahan, denyut aura hantu dan fade masuk.
/// Dipasang oleh Ghost > 3 - Build Main Menu.
/// </summary>
public class MenuAmbience : MonoBehaviour
{
    public RectTransform wispLayer;
    public int wisps = 16;
    public Image pulseGlow;
    public CanvasGroup fadeIn;
    public Image[] windows;      // tingkap rumah yang berkelip
    public Image[] windowGlows;  // cahaya di belakang tingkap
    public float fadeTime = 0.7f;

    class Wisp
    {
        public RectTransform rt;
        public Image img;
        public float x, y, speed, sway, swaySpeed, phase, baseAlpha;
    }

    Wisp[] list;
    Vector2 area = new Vector2(1920f, 1080f);
    float age;

    void Start()
    {
        if (fadeIn != null) fadeIn.alpha = 0f;
        if (wispLayer == null) return;

        Canvas.ForceUpdateCanvases();
        if (wispLayer.rect.width > 10f && wispLayer.rect.height > 10f)
            area = new Vector2(wispLayer.rect.width, wispLayer.rect.height);

        Sprite glow = UiKit.GlowSprite();
        list = new Wisp[Mathf.Max(0, wisps)];
        for (int i = 0; i < list.Length; i++)
        {
            GameObject go = new GameObject("Wisp", typeof(RectTransform), typeof(Image));
            go.transform.SetParent(wispLayer, false);

            Wisp w = new Wisp();
            w.rt = go.GetComponent<RectTransform>();
            w.img = go.GetComponent<Image>();
            w.img.sprite = glow;
            w.img.raycastTarget = false;

            float size = Random.Range(50f, 150f);
            w.rt.anchorMin = w.rt.anchorMax = Vector2.zero;
            w.rt.sizeDelta = new Vector2(size, size);

            w.x = Random.Range(0f, area.x);
            w.y = Random.Range(0f, area.y);
            w.speed = Random.Range(14f, 48f);
            w.sway = Random.Range(15f, 45f);
            w.swaySpeed = Random.Range(0.3f, 0.9f);
            w.phase = Random.Range(0f, 6.28f);
            w.baseAlpha = Random.Range(0.07f, 0.2f);
            w.img.color = UiKit.WithAlpha(Color.Lerp(UiKit.Ghost, Color.white, Random.value * 0.4f), w.baseAlpha);
            list[i] = w;
        }
    }

    void Update()
    {
        float dt = Time.unscaledDeltaTime;
        age += dt;

        if (fadeIn != null && fadeIn.alpha < 1f)
            fadeIn.alpha = Mathf.Min(1f, age / Mathf.Max(0.01f, fadeTime));

        if (pulseGlow != null)
        {
            float p = 0.5f + 0.5f * Mathf.Sin(age * 1.6f);
            Color c = pulseGlow.color;
            c.a = Mathf.Lerp(0.28f, 0.5f, p);
            pulseGlow.color = c;
            pulseGlow.rectTransform.localScale = Vector3.one * Mathf.Lerp(0.95f, 1.08f, p);
        }

        if (windows != null)
        {
            for (int i = 0; i < windows.Length; i++)
            {
                if (windows[i] == null) continue;
                float n = Mathf.PerlinNoise(age * (1.2f + i * 0.25f), i * 13.7f);
                float f = Mathf.Lerp(0.35f, 1f, Mathf.SmoothStep(0f, 1f, Mathf.InverseLerp(0.25f, 0.75f, n)));
                Color wc = windows[i].color;
                wc.a = 0.95f * f;
                windows[i].color = wc;
                if (windowGlows != null && i < windowGlows.Length && windowGlows[i] != null)
                {
                    Color gc = windowGlows[i].color;
                    gc.a = 0.32f * f;
                    windowGlows[i].color = gc;
                }
            }
        }

        if (list == null) return;
        for (int i = 0; i < list.Length; i++)
        {
            Wisp w = list[i];
            w.y += w.speed * dt;
            if (w.y > area.y + 120f)
            {
                w.y = -120f;
                w.x = Random.Range(0f, area.x);
            }
            float sx = w.x + Mathf.Sin(age * w.swaySpeed + w.phase) * w.sway;
            w.rt.anchoredPosition = new Vector2(sx, w.y);

            Color c = w.img.color;
            c.a = w.baseAlpha * (0.6f + 0.4f * Mathf.Sin(age * 1.3f + w.phase));
            w.img.color = c;
        }
    }
}
