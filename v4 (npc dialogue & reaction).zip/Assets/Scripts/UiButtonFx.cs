using UnityEngine;
using UnityEngine.EventSystems;

/// <summary>
/// Butang uGUI membesar sedikit bila disentuh atau dilalui tetikus, dan mengecut bila ditekan.
/// Guna masa tak terskala, jadi berfungsi juga semasa game dijeda.
/// </summary>
public class UiButtonFx : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, IPointerDownHandler, IPointerUpHandler
{
    public float hoverScale = 1.05f;
    public float pressScale = 0.94f;

    bool hover;
    bool down;
    float current = 1f;

    void OnEnable()
    {
        hover = false;
        down = false;
        current = 1f;
        transform.localScale = Vector3.one;
    }

    void Update()
    {
        float target = down ? pressScale : (hover ? hoverScale : 1f);
        current = Mathf.Lerp(current, target, 1f - Mathf.Exp(-18f * Time.unscaledDeltaTime));
        transform.localScale = new Vector3(current, current, 1f);
    }

    public void OnPointerEnter(PointerEventData e) { hover = true; }
    public void OnPointerExit(PointerEventData e)  { hover = false; down = false; }
    public void OnPointerDown(PointerEventData e)  { down = true; }
    public void OnPointerUp(PointerEventData e)    { down = false; }
}
