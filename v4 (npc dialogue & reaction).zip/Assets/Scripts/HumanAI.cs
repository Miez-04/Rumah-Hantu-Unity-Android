using UnityEngine;

public enum ScareKind { Move = 0, Impact = 1, Smash = 2, Panic = 3, Light = 4, Sound = 5, Shake = 6 }

// One party guest. Wanders between waypoints, builds up fear when the ghost scares them,
// becomes habituated ("kebal") to repeated scares of the same kind, and runs to an exit when afraid enough.
[RequireComponent(typeof(SpriteRenderer))]
[RequireComponent(typeof(SpriteSheetAnimator))]
public class HumanAI : MonoBehaviour
{
    public enum State { Idle, Walk, Frozen, Flee, Gone, Alert, Investigate, Search, Chat }

    [Header("Type: penakut | biasa | berani")]
    public string humanType = "biasa";
    [Tooltip("When ticked, the stats below are set from the type. Untick to edit them by hand.")]
    public bool useTypeDefaults = true;

    [Header("Stats")]
    public float walkSpeed = 1.5f;
    public float runSpeed = 4.2f;
    public float fearGain = 1f;
    public float calmPerSecond = 3f;

    [Header("Fear")]
    [Range(0f, 100f)] public float fear;
    public float fleeThreshold = 100f;
    [Tooltip("How much each scare of a kind weakens the next one of that kind.")]
    public float habitPerEvent = 0.25f;
    public float habitPerSecond = 0.05f;

    public State Current { get; private set; }

    SpriteRenderer sr;
    SpriteSheetAnimator anim;
    SpriteRenderer barBg;
    SpriteRenderer barFill;
    SpriteRenderer bubble;

    WaypointNode node;
    System.Collections.Generic.List<WaypointNode> path;
    int pathIndex;
    float idleTimer;
    float freezeTimer;
    bool pendingFlee;
    float lastScare = -99f;
    readonly float[] habit = new float[8];

    // ---- kehidupan: mendengar bunyi, menyiasat, berbual ----
    class Convo
    {
        public HumanAI a, b;
        public string[] lines;
        public int idx;
        public float next;
    }

    float stateTimer;
    float lookTimer;
    Vector2 noisePos;
    bool seekFriend;                       // sedang berjalan mencari kawan (penakut), bukan menyiasat
    bool wantsCompany;                     // sedang berjalan ke arah kawan untuk berbual
    float nextInvestigateOk;
    float nextChatOk;
    float nextMutter;
    float nextCalm;
    float nextLine;
    Convo convo;
    HumanAI chatPartner;
    readonly float[] curiosity = new float[8]; // makin biasa sesuatu bunyi, makin kurang menarik

    void Start()
    {
        sr = GetComponent<SpriteRenderer>();
        anim = GetComponent<SpriteSheetAnimator>();
        if (useTypeDefaults) ApplyType();

        if (anim.Load("Sprites/human_" + humanType))
        {
            anim.Define("idle", 0, 2, 2f);
            anim.Define("walk", 2, 4, 8f);
            anim.Define("scared", 6, 1, 1f);
            anim.Define("run", 7, 4, 12f);
            anim.Play("idle");
        }

        BuildBars();

        node = WaypointNode.Nearest(transform.position);
        if (node != null) transform.position = node.Pos;
        else Debug.LogError("HumanAI: no WaypointNode in the scene. Run Ghost > 2 - Populate Level.");

        idleTimer = Random.Range(0.5f, 2f);
        nextMutter = Time.time + Random.Range(5f, 12f);
        nextChatOk = Time.time + Random.Range(3f, 7f);
        if (GameManager.Instance != null) GameManager.Instance.Register(this);
    }

    void ApplyType()
    {
        switch (humanType)
        {
            case "penakut": fearGain = 1.4f; calmPerSecond = 1.5f; walkSpeed = 1.2f; runSpeed = 4.8f; break;
            case "berani":  fearGain = 0.6f; calmPerSecond = 5f;   walkSpeed = 1.8f; runSpeed = 3.6f; break;
            default:        fearGain = 1.0f; calmPerSecond = 3f;   walkSpeed = 1.5f; runSpeed = 4.2f; break;
        }
    }

    void BuildBars()
    {
        Sprite white = Sprite.Create(Texture2D.whiteTexture, new Rect(0, 0, 4, 4), new Vector2(0f, 0.5f), 4f);
        barBg = MakeBox("FearBg", white, new Color(0f, 0f, 0f, 0.65f), new Vector3(-0.5f, 2.35f, 0f), 20);
        barBg.transform.localScale = new Vector3(1f, 0.16f, 1f);
        barFill = MakeBox("FearFill", white, Color.green, new Vector3(-0.5f, 2.35f, 0f), 21);
        barFill.transform.localScale = new Vector3(0f, 0.1f, 1f);

        GameObject b = new GameObject("Bubble");
        b.transform.SetParent(transform, false);
        b.transform.localPosition = new Vector3(0f, 3.1f, 0f);
        bubble = b.AddComponent<SpriteRenderer>();
        Sprite[] ex = Resources.LoadAll<Sprite>("Sprites/exclaim");
        if (ex != null && ex.Length > 0) bubble.sprite = ex[0];
        bubble.sortingOrder = 22;
        bubble.enabled = false;
    }

    SpriteRenderer MakeBox(string goName, Sprite s, Color c, Vector3 localPos, int order)
    {
        GameObject go = new GameObject(goName);
        go.transform.SetParent(transform, false);
        go.transform.localPosition = localPos;
        SpriteRenderer r = go.AddComponent<SpriteRenderer>();
        r.sprite = s;
        r.color = c;
        r.sortingOrder = order;
        return r;
    }

    void Update()
    {
        if (Current == State.Gone) return;
        float dt = Time.deltaTime;

        if (Current != State.Flee && Time.time - lastScare > 1.5f)
            fear = Mathf.Max(0f, fear - calmPerSecond * dt);

        switch (Current)
        {
            case State.Idle:
                anim.Play("idle");
                idleTimer -= dt;
                if (idleTimer <= 0f)
                {
                    if (!TryStartChat(false)) StartWander();
                }
                break;
            case State.Walk:
                Follow(walkSpeed, "walk");
                break;
            case State.Flee:
                Follow(runSpeed, "run");
                break;
            case State.Frozen:
                anim.Play("scared");
                freezeTimer -= dt;
                if (freezeTimer <= 0f)
                {
                    bool flee = pendingFlee;
                    pendingFlee = false;
                    if (flee) BeginFlee();
                    else
                    {
                        Current = State.Idle;
                        idleTimer = Random.Range(0.5f, 1.5f);
                    }
                }
                break;
            case State.Alert:
                anim.Play(humanType == "penakut" ? "scared" : "idle");
                FaceTo(noisePos);
                stateTimer -= dt;
                if (stateTimer <= 0f) DecideInvestigate();
                break;
            case State.Investigate:
                Follow(walkSpeed * 1.3f, "walk");
                break;
            case State.Search:
                anim.Play("idle");
                stateTimer -= dt;
                lookTimer -= dt;
                if (lookTimer <= 0f)
                {
                    sr.flipX = !sr.flipX; // menoleh kiri dan kanan
                    lookTimer = Random.Range(0.7f, 1.2f);
                }
                if (stateTimer <= 0f) FinishSearch();
                break;
            case State.Chat:
                anim.Play("idle");
                if (convo == null)
                {
                    Current = State.Idle;
                    idleTimer = 1f;
                }
                else if (convo.a == this)
                {
                    DriveConvo();
                }
                break;
        }

        LifeTick(dt);
        UpdateBars();
    }

    void UpdateBars()
    {
        float f = Mathf.Clamp01(fear / 100f);
        barFill.transform.localScale = new Vector3(f, 0.1f, 1f);
        barFill.color = Color.Lerp(new Color(0.3f, 0.9f, 0.3f), new Color(0.95f, 0.2f, 0.2f), f);
        bool show = fear > 0.5f && Current != State.Gone;
        barBg.enabled = show;
        barFill.enabled = show;
        bubble.enabled = fear >= 50f && Current != State.Gone && bubble.sprite != null;
    }

    void StartWander()
    {
        if (node == null || WaypointNode.All.Count < 2) { idleTimer = 1f; return; }
        WaypointNode target = WaypointNode.All[Random.Range(0, WaypointNode.All.Count)];
        wantsCompany = false;
        if (Random.value < 0.7f && Time.time >= nextChatOk)
        {
            // kadangkala berjalan ke arah kawan untuk berbual
            HumanAI buddy = NearestGuest(14f, 0, 0f);
            if (buddy != null && buddy.node != null && buddy.node != node
                && Mathf.Abs(buddy.transform.position.x - transform.position.x) > 3f)
            {
                target = buddy.node;
                wantsCompany = true;
            }
        }
        if (target == node || target.isExit) { wantsCompany = false; idleTimer = 0.3f; return; }

        path = WaypointNode.FindPath(node, n => n == target);
        pathIndex = 0;
        if (path == null) { wantsCompany = false; idleTimer = 1f; return; }
        Current = State.Walk;
    }

    void Follow(float speed, string clip)
    {
        if (path == null || pathIndex >= path.Count)
        {
            ArriveAtEnd();
            return;
        }

        anim.Play(clip);
        Vector2 target = path[pathIndex].Pos;
        Vector2 pos = transform.position;
        Vector2 d = target - pos;
        float step = speed * Time.deltaTime;

        if (Mathf.Abs(d.x) > 0.02f) sr.flipX = d.x < 0f; // sprites face right

        if (d.magnitude <= step)
        {
            transform.position = target;
            node = path[pathIndex];
            pathIndex++;
            if (pathIndex >= path.Count) ArriveAtEnd();
        }
        else
        {
            transform.position = pos + d.normalized * step;
        }
    }

    void ArriveAtEnd()
    {
        if (Current == State.Flee && node != null && node.isExit)
        {
            Leave();
            return;
        }
        path = null;

        if (Current == State.Investigate)
        {
            if (seekFriend)
            {
                seekFriend = false;
                if (!TryStartChat(true)) GoIdle(Random.Range(1f, 2f));
            }
            else
            {
                BeginSearch();
            }
            return;
        }

        bool social = wantsCompany;
        wantsCompany = false;
        if (Current == State.Walk && social && TryStartChat(false)) return;

        Current = State.Idle;
        idleTimer = Random.Range(1f, 3f);
    }

    void BeginFlee()
    {
        EndChat();
        bool wasFleeing = Current == State.Flee;
        pendingFlee = false;
        path = WaypointNode.FindPath(node, n => n.isExit);
        if (path == null)
        {
            Debug.LogWarning("HumanAI: no path to an Exit waypoint. Check WaypointNode links and that one node has 'Is Exit' ticked.");
            Current = State.Idle;
            idleTimer = 2f;
            return;
        }

        pathIndex = 0;
        if (path.Count > 1 &&
            Vector2.Distance(transform.position, path[1].Pos) < Vector2.Distance(path[0].Pos, path[1].Pos))
            pathIndex = 1; // already past the first node

        Current = State.Flee;
        if (!wasFleeing)
        {
            SpreadPanic();
            if (GhostController.Instance != null) GhostController.Instance.RewardForFlee();
            float pitch = humanType == "penakut" ? 1.25f : (humanType == "berani" ? 0.8f : 1f);
            Sfx.Play("scream", 0.7f, pitch);
            Say(GuestTalk.Flee(), 2.2f, true);
            NoiseHub.Emit(transform.position, ScareKind.Panic, 7f); // jeritan menarik perhatian tetamu yang jauh
        }
    }

    void SpreadPanic()
    {
        if (GameManager.Instance == null) return;
        foreach (HumanAI h in GameManager.Instance.Humans)
        {
            if (h == null || h == this || h.Current == State.Gone) continue;
            if (Mathf.Abs(h.transform.position.y - transform.position.y) > 3.5f) continue;
            if (Vector2.Distance(h.transform.position, transform.position) > 6f) continue;
            h.ScareEvent(ScareKind.Panic, 20f, transform.position);
        }
    }

    void Leave()
    {
        Current = State.Gone;
        sr.enabled = false;
        barBg.enabled = false;
        barFill.enabled = false;
        bubble.enabled = false;
        if (GameManager.Instance != null) GameManager.Instance.HumanEvacuated(this);
    }

    void Freeze(float seconds, bool thenFlee)
    {
        EndChat();
        Current = State.Frozen;
        freezeTimer = seconds;
        pendingFlee = pendingFlee || thenFlee;
    }

    // ============================================================ kehidupan tetamu

    float BaseCuriosity
    {
        get { return humanType == "berani" ? 1f : (humanType == "penakut" ? 0.85f : 0.7f); }
    }

    void Say(string text, float seconds, bool alarm)
    {
        if (Current == State.Gone) return;
        SpeechBubbles.Say(this, text, seconds, alarm);
    }

    void Say(string text, float seconds)
    {
        Say(text, seconds, false);
    }

    void GoIdle(float seconds)
    {
        path = null;
        Current = State.Idle;
        idleTimer = seconds;
    }

    // Dipanggil oleh NoiseHub bila ada bunyi kuat dalam jarak dengar.
    public void HearNoise(Vector2 pos, ScareKind kind, float hearRadius)
    {
        if (Current == State.Gone || Current == State.Flee || Current == State.Frozen) return;
        if (Current == State.Alert || Current == State.Investigate) return;
        if (kind == ScareKind.Move) return; // gerakan berterusan bukan "bunyi"

        Vector2 me = transform.position;
        float dist = Mathf.Abs(me.x - pos.x) + Mathf.Abs(me.y - pos.y) * 1.8f; // tingkat lain lebih sunyi
        if (dist > hearRadius) return;
        if (Time.time < nextInvestigateOk) return;

        int k = (int)kind;
        float interest = Mathf.Min(1f, BaseCuriosity / (1f + curiosity[k]));
        curiosity[k] += 0.4f;

        EndChat();
        FaceTo(pos);
        if (Random.value > interest)
        {
            // dengar, tetapi tak ambil peduli (bunyi yang sama berulang-ulang, atau orangnya tak ingin tahu)
            if (Random.value < 0.5f) Say(GuestTalk.Heard(), 1.8f);
            return;
        }

        noisePos = pos;
        path = null;
        seekFriend = false;
        wantsCompany = false;
        Current = State.Alert;
        stateTimer = Random.Range(0.5f, 0.9f);
        nextInvestigateOk = Time.time + 3.5f;
        Say(GuestTalk.Heard(), 1.9f);
    }

    void DecideInvestigate()
    {
        WaypointNode target;
        if (humanType == "penakut")
        {
            // tak berani pergi sendiri: cari kawan terdekat
            HumanAI friend = NearestGuest(10f, 0, 0f);
            if (friend == null || friend.node == null)
            {
                Say(GuestTalk.Alone(), 2f);
                GoIdle(Random.Range(1.5f, 2.5f));
                return;
            }
            Say(GuestTalk.Company(), 2f);
            seekFriend = true;
            target = friend.node;
        }
        else
        {
            seekFriend = false;
            target = WaypointNode.Nearest(noisePos);
        }

        if (node == null || target == null || target == node)
        {
            if (seekFriend) { seekFriend = false; GoIdle(1f); }
            else BeginSearch();
            return;
        }

        path = WaypointNode.FindPath(node, n => n == target);
        pathIndex = 0;
        if (path == null || PathLength(path) > 26f)
        {
            seekFriend = false;
            path = null;
            Say(GuestTalk.NoWay(), 2f);
            GoIdle(Random.Range(1f, 2f));
            return;
        }

        if (path.Count > 1 &&
            Vector2.Distance(transform.position, path[1].Pos) < Vector2.Distance(path[0].Pos, path[1].Pos))
            pathIndex = 1; // sudah melepasi nod pertama

        if (!seekFriend) Say(GuestTalk.Go(humanType), 2f);
        Current = State.Investigate;
    }

    float PathLength(System.Collections.Generic.List<WaypointNode> p)
    {
        float len = Vector2.Distance(transform.position, p[0].Pos);
        for (int i = 0; i + 1 < p.Count; i++) len += Vector2.Distance(p[i].Pos, p[i + 1].Pos);
        return len;
    }

    void BeginSearch()
    {
        path = null;
        Current = State.Search;
        stateTimer = Random.Range(2.5f, 4f);
        lookTimer = 0.8f;
    }

    void FinishSearch()
    {
        Say(GuestTalk.Dismiss(humanType), 2.2f);
        GoIdle(Random.Range(1f, 2f));
    }

    // Tetamu lain yang berada di tingkat yang sama dan dalam jarak tertentu.
    // mode: 0 = sesiapa, 1 = boleh diajak berbual (Idle atau sedang berjalan, dan cooldown sudah tamat),
    //       2 = sama tetapi abaikan cooldown (penakut yang mencari kawan). minFear: hanya yang cukup takut.
    HumanAI NearestGuest(float radius, int mode, float minFear)
    {
        GameManager gm = GameManager.Instance;
        if (gm == null) return null;

        HumanAI best = null;
        float bestD = float.MaxValue;
        Vector2 me = transform.position;
        for (int i = 0; i < gm.Humans.Count; i++)
        {
            HumanAI h = gm.Humans[i];
            if (h == null || h == this) continue;
            if (h.Current == State.Gone || h.Current == State.Flee) continue;
            if (mode > 0)
            {
                if (h.Current != State.Idle && h.Current != State.Walk) continue;
                if (mode == 1 && Time.time < h.nextChatOk) continue;
            }
            if (h.fear < minFear) continue;

            Vector2 p = h.transform.position;
            if (Mathf.Abs(p.y - me.y) > 1.5f) continue;
            float d = Mathf.Abs(p.x - me.x);
            if (d > radius || d >= bestD) continue;
            bestD = d;
            best = h;
        }
        return best;
    }

    // ---- berbual ----
    // force = penakut yang mencari kawan: abaikan cooldown.
    bool TryStartChat(bool force)
    {
        if (Current != State.Idle && Current != State.Walk && Current != State.Investigate) return false;
        if (!force && Time.time < nextChatOk) return false;
        HumanAI p = NearestGuest(force ? 7f : 6.5f, force ? 2 : 1, 0f);
        if (p == null) return false;

        Convo c = new Convo();
        c.a = this;
        c.b = p;
        c.lines = GuestTalk.Convo();
        c.idx = 0;
        c.next = Time.time + 0.6f;

        convo = c; chatPartner = p;
        p.convo = c; p.chatPartner = this;
        path = null; p.path = null;
        Current = State.Chat; p.Current = State.Chat;
        FaceTo(p.transform.position);
        p.FaceTo(transform.position);
        return true;
    }

    void DriveConvo()
    {
        Convo c = convo;
        if (c == null) return;
        if (c.b == null || c.b.convo != c || c.b.Current != State.Chat) { EndChat(); return; }
        if (Time.time < c.next) return;
        if (c.idx >= c.lines.Length) { EndChat(); return; }

        HumanAI speaker = (c.idx % 2 == 0) ? c.a : c.b;
        speaker.Say(c.lines[c.idx], 2.8f);
        c.idx++;
        c.next = Time.time + 3f;
    }

    void EndChat()
    {
        if (convo == null) return;
        Convo c = convo;
        HumanAI p = chatPartner;
        convo = null;
        chatPartner = null;
        nextChatOk = Time.time + Random.Range(18f, 32f);
        if (Current == State.Chat)
        {
            Current = State.Idle;
            idleTimer = Random.Range(0.8f, 1.8f);
        }

        if (p != null && p.convo == c)
        {
            p.convo = null;
            p.chatPartner = null;
            p.nextChatOk = Time.time + Random.Range(18f, 32f);
            if (p.Current == State.Chat)
            {
                p.Current = State.Idle;
                p.idleTimer = Random.Range(0.8f, 1.8f);
            }
        }
    }

    // Gumaman bersendirian dan si berani yang menenangkan kawan.
    void LifeTick(float dt)
    {
        for (int i = 0; i < curiosity.Length; i++)
            if (curiosity[i] > 0f) curiosity[i] = Mathf.Max(0f, curiosity[i] - 0.06f * dt);

        bool calm = Current == State.Idle || Current == State.Walk;
        if (calm && Time.time >= nextMutter)
        {
            nextMutter = Time.time + Random.Range(10f, 18f);
            Say(GuestTalk.Mutter(humanType), 2.4f);
        }

        if (humanType == "berani" && calm && Time.time >= nextCalm)
        {
            nextCalm = Time.time + 3f;
            HumanAI scared = NearestGuest(4f, 0, 35f);
            if (scared != null && scared.Current != State.Frozen)
            {
                Say(GuestTalk.Calm(), 2.4f);
                scared.fear = Mathf.Max(0f, scared.fear - 8f);
                nextCalm = Time.time + 8f;
            }
        }
    }

    void FaceTo(Vector2 from)
    {
        if (Mathf.Abs(from.x - transform.position.x) > 0.1f) sr.flipX = from.x < transform.position.x;
    }

    // One-off scare (a crash, a smash, someone screaming).
    public void ScareEvent(ScareKind kind, float amount, Vector2 from)
    {
        if (Current == State.Gone || Current == State.Flee) return;
        int k = (int)kind;
        float effective = amount * fearGain / (1f + habit[k]);
        habit[k] += habitPerEvent;
        fear = Mathf.Min(100f, fear + effective);
        lastScare = Time.time;
        FaceTo(from);

        if (effective >= 6f && Time.time >= nextLine)
        {
            nextLine = Time.time + 2.5f;
            Say(GuestTalk.React(kind), 1.9f, true);
        }

        if (fear >= fleeThreshold) Freeze(0.45f, true);
        else if (effective >= 6f && Current != State.Frozen)
        {
            Freeze(0.5f, false);
            AudioManager.Play("scare", 0.45f, humanType == "penakut" ? 1.15f : (humanType == "berani" ? 0.9f : 1f));
        }
    }

    // Continuous scare (e.g. a chair floating around near them).
    public void ScareOverTime(ScareKind kind, float perSecond, Vector2 from, float dt)
    {
        if (Current == State.Gone || Current == State.Flee) return;
        int k = (int)kind;
        float effective = perSecond * dt * fearGain / (1f + habit[k]);
        habit[k] += habitPerSecond * dt;
        fear = Mathf.Min(100f, fear + effective);
        lastScare = Time.time;
        if (Current == State.Chat && effective > 0.3f) EndChat(); // ada benda meluru ke arah mereka

        if (fear >= fleeThreshold) Freeze(0.45f, true);
    }
}
