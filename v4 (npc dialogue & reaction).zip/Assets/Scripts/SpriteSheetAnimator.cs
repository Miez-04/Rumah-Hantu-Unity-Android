using System.Collections.Generic;
using UnityEngine;

// Plays frame ranges from a sliced sprite sheet that lives under a Resources folder.
// No Animator Controller needed. Example: Load("Sprites/human_biasa"); Define("walk", 2, 4, 8f); Play("walk");
[RequireComponent(typeof(SpriteRenderer))]
public class SpriteSheetAnimator : MonoBehaviour
{
    class Clip
    {
        public int start;
        public int count;
        public float fps;
        public bool loop;
    }

    SpriteRenderer sr;
    Sprite[] frames;
    readonly Dictionary<string, Clip> clips = new Dictionary<string, Clip>();
    Clip current;
    string currentName = "";
    float timer;

    void Awake()
    {
        sr = GetComponent<SpriteRenderer>();
    }

    public bool Load(string resourcesPath)
    {
        if (sr == null) sr = GetComponent<SpriteRenderer>();
        Sprite[] all = Resources.LoadAll<Sprite>(resourcesPath);
        if (all == null || all.Length == 0)
        {
            Debug.LogError("SpriteSheetAnimator: no sprites found at Resources/" + resourcesPath +
                           ". Check the folder name and that the PNG is sliced (Sprite Mode = Multiple).");
            return false;
        }
        System.Array.Sort(all, (a, b) => Index(a.name).CompareTo(Index(b.name)));
        frames = all;
        return true;
    }

    static int Index(string n)
    {
        int u = n.LastIndexOf('_');
        int v;
        if (u >= 0 && int.TryParse(n.Substring(u + 1), out v)) return v;
        return 0;
    }

    public void Define(string clipName, int start, int count, float fps, bool loop = true)
    {
        clips[clipName] = new Clip { start = start, count = Mathf.Max(1, count), fps = fps, loop = loop };
    }

    public void Play(string clipName)
    {
        if (clipName == currentName) return;
        Clip c;
        if (frames == null || !clips.TryGetValue(clipName, out c)) return;
        currentName = clipName;
        current = c;
        timer = 0f;
        Apply(0);
    }

    void Update()
    {
        if (current == null || frames == null) return;
        timer += Time.deltaTime * current.fps;
        int i;
        if (current.loop)
        {
            timer = timer % current.count;
            i = (int)timer;
        }
        else
        {
            i = Mathf.Min((int)timer, current.count - 1);
        }
        Apply(i);
    }

    void Apply(int i)
    {
        int idx = Mathf.Clamp(current.start + i, 0, frames.Length - 1);
        sr.sprite = frames[idx];
    }
}
