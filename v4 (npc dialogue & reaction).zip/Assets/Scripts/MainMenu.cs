using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

/// <summary>
/// Menu utama Hantu Rumah. Diletak pada objek MainMenu dalam scene MainMenu.
/// Dipasang automatik oleh Ghost > 3 - Build Main Menu.
/// </summary>
public class MainMenu : MonoBehaviour
{
    [Header("Scene")]
    public string gameScene = "Main";

    [Header("Panel")]
    public GameObject mainPanel;
    public GameObject howToPanel;
    public GameObject settingsPanel;

    [Header("UI")]
    public Text soundButtonText;
    public Image ghostImage;
    public Text tutorialButtonText;

    const string SoundKey = "sound_on";

    RectTransform ghostRect;
    float ghostBaseY;

    void Start()
    {
        Time.timeScale = 1f;

        bool soundOn = PlayerPrefs.GetInt(SoundKey, 1) == 1;
        ApplySound(soundOn);
        RefreshTutorialLabel();

        if (ghostImage != null)
        {
            // Muat sprite hantu dari Resources/Sprites/ghost (frame pertama)
            Sprite[] frames = Resources.LoadAll<Sprite>("Sprites/ghost");
            if (frames != null && frames.Length > 0) ghostImage.sprite = frames[0];
            ghostRect = ghostImage.rectTransform;
            ghostBaseY = ghostRect.anchoredPosition.y;
        }

        ShowMain();
    }

    void Update()
    {
        // Hantu terapung naik turun
        if (ghostRect != null)
        {
            Vector2 p = ghostRect.anchoredPosition;
            p.y = ghostBaseY + Mathf.Sin(Time.unscaledTime * 2f) * 22f;
            ghostRect.anchoredPosition = p;
        }

        // Butang Back pada Android (juga Escape pada PC)
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (mainPanel != null && mainPanel.activeSelf) Quit();
            else ShowMain();
        }
    }

    // ---------- Dipanggil oleh butang ----------

    public void Play()
    {
        GameManager.LevelIndex = 0; // mula dari Malam 1
        HouseSelector.LoadNext(gameScene); // rumah rawak; jika tiada rumah dibina, muat scene "Main"
    }

    public void ShowMain()     { SetPanel(mainPanel); }
    public void ShowHowTo()    { SetPanel(howToPanel); }
    public void ShowSettings() { SetPanel(settingsPanel); }

    public void ToggleSound()
    {
        bool soundOn = PlayerPrefs.GetInt(SoundKey, 1) == 1;
        ApplySound(!soundOn);
    }

    public void ResetTutorial()
    {
        PlayerPrefs.DeleteKey(Tutorial.DoneKey);
        PlayerPrefs.Save();
        RefreshTutorialLabel();
    }

    public void Quit()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }

    // ---------- Dalaman ----------

    void SetPanel(GameObject active)
    {
        if (mainPanel != null)     mainPanel.SetActive(mainPanel == active);
        if (howToPanel != null)    howToPanel.SetActive(howToPanel == active);
        if (settingsPanel != null) settingsPanel.SetActive(settingsPanel == active);
    }

    void RefreshTutorialLabel()
    {
        if (tutorialButtonText == null) return;
        bool pending = PlayerPrefs.GetInt(Tutorial.DoneKey, 0) == 0;
        tutorialButtonText.text = pending ? "Tutorial: AKAN DIPAPARKAN" : "Ulang Tutorial";
    }

    void ApplySound(bool on)
    {
        PlayerPrefs.SetInt(SoundKey, on ? 1 : 0);
        PlayerPrefs.Save();
        AudioListener.volume = on ? 1f : 0f;
        if (soundButtonText != null)
            soundButtonText.text = on ? "Bunyi: HIDUP" : "Bunyi: MATI";
    }
}
