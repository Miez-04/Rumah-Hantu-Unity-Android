using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Gelembung cakap di atas kepala tetamu, dilukis dengan IMGUI (sama seperti HUD) dan diletak dengan Camera.WorldToScreenPoint.
/// Satu gelembung bagi setiap tetamu (yang baharu menggantikan yang lama); paling banyak 5 kelihatan serentak supaya skrin tak sesak.
/// Dicipta sendiri apabila SpeechBubbles.Say dipanggil pertama kali.
/// </summary>
public class SpeechBubbles : MonoBehaviour
{
    class Entry
    {
        public HumanAI who;
        public string text;
        public float born, until;
        public bool alarm;
    }

    const int MaxVisible = 5;
    const float HeadHeight = 3.75f; // di atas bar takut dan tanda seru

    static SpeechBubbles instance;
    readonly List<Entry> entries = new List<Entry>();

    public static void Say(HumanAI who, string text, float seconds, bool alarm)
    {
        if (who == null || string.IsNullOrEmpty(text)) return;
        if (instance == null) instance = new GameObject("SpeechBubbles").AddComponent<SpeechBubbles>();
        instance.Add(who, text, seconds, alarm);
    }

    void Add(HumanAI who, string text, float seconds, bool alarm)
    {
        for (int i = entries.Count - 1; i >= 0; i--)
            if (entries[i].who == who) entries.RemoveAt(i);

        Entry e = new Entry();
        e.who = who;
        e.text = text;
        e.born = Time.time;
        e.until = Time.time + seconds;
        e.alarm = alarm;
        entries.Add(e);
    }

    void OnDestroy()
    {
        if (instance == this) instance = null;
    }

    void OnGUI()
    {
        if (Event.current.type != EventType.Repaint) return;
        Camera cam = Camera.main;
        if (cam == null) return;

        GUI.depth = 5; // di belakang HUD dan menu jeda
        float s = Screen.height / 540f;
        GUI.matrix = Matrix4x4.Scale(new Vector3(s, s, 1f));
        float W = Screen.width / s;

        // buang yang tamat, kemudian lukis yang paling baharu dahulu sehingga had
        for (int i = entries.Count - 1; i >= 0; i--)
        {
            Entry e = entries[i];
            if (e.who == null || e.who.Current == HumanAI.State.Gone || Time.time > e.until) entries.RemoveAt(i);
        }

        int drawn = 0;
        for (int i = entries.Count - 1; i >= 0 && drawn < MaxVisible; i--)
        {
            if (Draw(entries[i], cam, s, W)) drawn++;
        }
    }

    bool Draw(Entry e, Camera cam, float s, float W)
    {
        Vector3 sp = cam.WorldToScreenPoint(e.who.transform.position + new Vector3(0f, HeadHeight, 0f));
        if (sp.z < 0f) return false;
        if (sp.x < -50f || sp.x > Screen.width + 50f || sp.y < -50f || sp.y > Screen.height + 50f) return false;

        Vector2 g = new Vector2(sp.x / s, (Screen.height - sp.y) / s);

        float age = Time.time - e.born;
        float left = e.until - Time.time;
        float a = Mathf.Clamp01(Mathf.Min(age / 0.12f, left / 0.25f));

        const int size = 14;
        Vector2 m = UiKit.Measure(e.text, size, e.alarm ? FontStyle.Bold : FontStyle.Normal);
        float w = m.x + 18f;
        float h = 24f;
        float x = Mathf.Clamp(g.x - w / 2f, 6f, W - w - 6f);
        float y = Mathf.Max(g.y - h - 10f, 64f);
        Rect r = new Rect(x, y, w, h);

        Color prev = GUI.color;
        GUI.color = new Color(1f, 1f, 1f, a);

        Color fill = e.alarm ? new Color(1f, 0.90f, 0.92f, 0.97f) : new Color(0.97f, 0.97f, 1f, 0.96f);
        Color text = e.alarm ? new Color(0.62f, 0.05f, 0.14f, 1f) : new Color(0.09f, 0.09f, 0.20f, 1f);
        UiKit.Round(r, fill, 12);
        // ekor gelembung: dua bulatan kecil menuju kepala
        float cx = Mathf.Clamp(g.x, r.x + 10f, r.xMax - 10f);
        UiKit.Round(new Rect(cx - 4f, r.yMax - 2f, 8f, 8f), fill, 4);
        UiKit.Round(new Rect(cx - 2f, r.yMax + 5f, 5f, 5f), fill, 2);
        UiKit.Text(r, e.text, size, text, TextAnchor.MiddleCenter, false, e.alarm ? FontStyle.Bold : FontStyle.Normal);

        GUI.color = prev;
        return true;
    }
}
