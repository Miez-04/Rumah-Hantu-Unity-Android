using System.Collections.Generic;
using UnityEngine;

// A point humans can walk to. Nodes at the same height (y) within AutoLinkMaxDx of each other
// link automatically. Stairs are linked by hand with "Extra Links" (stair bottom <-> stair top).
public class WaypointNode : MonoBehaviour
{
    public static readonly List<WaypointNode> All = new List<WaypointNode>();
    public static float AutoLinkMaxDx = 7f;
    static bool linksBuilt;

    [Tooltip("Humans that reach an exit node leave the building.")]
    public bool isExit;
    [Tooltip("Humans may start the night here.")]
    public bool spawnable = true;
    [Tooltip("Manual two-way links, e.g. stair bottom <-> stair top.")]
    public WaypointNode[] extraLinks;

    [System.NonSerialized] public List<WaypointNode> neighbors = new List<WaypointNode>();

    public Vector2 Pos { get { return transform.position; } }

    void OnEnable()
    {
        if (!All.Contains(this)) All.Add(this);
        linksBuilt = false;
    }

    void OnDisable()
    {
        All.Remove(this);
        linksBuilt = false;
    }

    static void BuildLinks()
    {
        foreach (WaypointNode n in All) n.neighbors.Clear();

        for (int i = 0; i < All.Count; i++)
        {
            for (int j = i + 1; j < All.Count; j++)
            {
                Vector2 a = All[i].Pos;
                Vector2 b = All[j].Pos;
                if (Mathf.Abs(a.y - b.y) < 0.1f && Mathf.Abs(a.x - b.x) <= AutoLinkMaxDx)
                    Link(All[i], All[j]);
            }
        }

        foreach (WaypointNode n in All)
        {
            if (n.extraLinks == null) continue;
            foreach (WaypointNode m in n.extraLinks)
                if (m != null) Link(n, m);
        }

        linksBuilt = true;
    }

    static void Link(WaypointNode a, WaypointNode b)
    {
        if (a == b) return;
        if (!a.neighbors.Contains(b)) a.neighbors.Add(b);
        if (!b.neighbors.Contains(a)) b.neighbors.Add(a);
    }

    public static WaypointNode Nearest(Vector2 p)
    {
        WaypointNode best = null;
        float bestD = float.MaxValue;
        foreach (WaypointNode n in All)
        {
            Vector2 d = n.Pos - p;
            d.y *= 2f; // prefer nodes on the same floor
            float m = d.sqrMagnitude;
            if (m < bestD)
            {
                bestD = m;
                best = n;
            }
        }
        return best;
    }

    // Breadth-first search: shortest path (fewest hops) from start to the first node that satisfies isGoal.
    public static List<WaypointNode> FindPath(WaypointNode start, System.Func<WaypointNode, bool> isGoal)
    {
        if (start == null) return null;
        if (!linksBuilt) BuildLinks();

        Dictionary<WaypointNode, WaypointNode> prev = new Dictionary<WaypointNode, WaypointNode>();
        Queue<WaypointNode> queue = new Queue<WaypointNode>();
        prev[start] = null;
        queue.Enqueue(start);

        while (queue.Count > 0)
        {
            WaypointNode cur = queue.Dequeue();
            if (isGoal(cur))
            {
                List<WaypointNode> path = new List<WaypointNode>();
                for (WaypointNode n = cur; n != null; n = prev[n]) path.Add(n);
                path.Reverse();
                return path;
            }
            foreach (WaypointNode nb in cur.neighbors)
            {
                if (!prev.ContainsKey(nb))
                {
                    prev[nb] = cur;
                    queue.Enqueue(nb);
                }
            }
        }
        return null;
    }

    void OnDrawGizmos()
    {
        bool hasExtra = extraLinks != null && extraLinks.Length > 0;
        Gizmos.color = isExit ? Color.green : (hasExtra ? Color.yellow : Color.cyan);
        Gizmos.DrawSphere(transform.position, 0.2f);
        if (hasExtra)
        {
            foreach (WaypointNode m in extraLinks)
                if (m != null) Gizmos.DrawLine(transform.position, m.transform.position);
        }
    }
}
