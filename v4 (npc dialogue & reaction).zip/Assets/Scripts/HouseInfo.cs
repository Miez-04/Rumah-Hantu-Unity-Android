using UnityEngine;

/// <summary>Maklumat rumah dalam scene. Diletak pada objek "Level" oleh LevelPopulator.</summary>
public class HouseInfo : MonoBehaviour
{
    public string title = "Rumah";
    public int floors = 3;

    public static HouseInfo Current
    {
        get
        {
#if UNITY_2023_1_OR_NEWER
            return Object.FindFirstObjectByType<HouseInfo>();
#else
            return Object.FindObjectOfType<HouseInfo>();
#endif
        }
    }
}
