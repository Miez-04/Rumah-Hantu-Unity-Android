using UnityEngine;

// The player.
//  - joystick (TouchPad, bottom-left): the ghost flies freely in any direction (it passes through walls, it has no collider)
//  - tap a Possessable: the ghost flies in and possesses it
//  - while possessed: joystick to move, plus on-screen buttons (TouchPad) to jump, use the object's special power, or leave (KELUAR)
public class GhostController : MonoBehaviour
{
    public static GhostController Instance { get; private set; }

    [Header("References")]
    public Transform visual;          // child with SpriteRenderer + SpriteSheetAnimator
    public LayerMask furnitureMask;   // the Furniture layer
    public Camera cam;

    [Header("Movement")]
    public float moveSpeed = 8f;
    [Tooltip("Had kawasan terbang dengan joystick (bawah-kiri dan atas-kanan bangunan).")]
    public Vector2 flightMin = new Vector2(0.8f, 0.8f);
    public Vector2 flightMax = new Vector2(23.2f, 21f);
    public float bobHeight = 0.12f;
    [Tooltip("How generous touches are when picking furniture (world units).")]
    public float pickRadius = 0.5f;

    [Header("Energy (spent by special powers)")]
    public float maxEnergy = 100f;
    [Tooltip("Tenaga pulih sendiri bila kuasa tak digunakan seketika.")]
    public bool autoRefill = true;
    [Tooltip("Saat selepas kuasa terakhir digunakan sebelum tenaga mula pulih.")]
    public float refillDelay = 2.5f;
    [Tooltip("Kelajuan pulih, dalam peratus tenaga penuh setiap saat (4 = 4%/saat).")]
    public float refillPercentPerSecond = 4f;

    // Medan lama, tidak digunakan lagi. Dikekalkan supaya skrip lain yang masih merujuknya tidak ralat compile.
    [HideInInspector] public bool regenerates;
    [HideInInspector] public float regenPerSecond = 6f;
    [Tooltip("Tenaga yang diberi bila seorang manusia mula lari. 0 = tiada ganjaran (tenaga hanya berkurang).")]
    public float refillWhenGuestFlees = 15f;

    [Header("Tenaga ikut bilangan tetamu")]
    [Tooltip("Tenaga penuh pada awal malam = Energy Base + Energy Per Guest x bilangan tetamu. Tetapkan kedua-duanya 0 untuk guna Max Energy tetap.")]
    public float energyBase = 30f;
    public float energyPerGuest = 35f;

    public float Energy { get; private set; }
    public float Energy01 { get { return maxEnergy > 0f ? Energy / maxEnergy : 0f; } }
    public bool IsPossessing { get { return inside && possessed != null; } }
    // Masa terakhir kuasa ditolak kerana tenaga tak cukup (untuk amaran dalam HUD).
    public float LastDeniedTime { get; private set; }
    public bool IsRefilling { get { return autoRefill && Energy < maxEnergy - 0.01f && Time.time - lastSpendTime >= refillDelay; } }
    float lastSpendTime = -99f;

    SpriteRenderer sr;
    SpriteSheetAnimator anim;
    TouchPad pad;
    Possessable possessed;
    Possessable approaching;
    bool inside;
    Vector2 goal;

    void Awake()
    {
        Instance = this;
        Energy = maxEnergy;
        LastDeniedTime = -99f;
        goal = transform.position;
        if (cam == null) cam = Camera.main;
        if (visual == null && transform.childCount > 0) visual = transform.GetChild(0);
        if (visual != null)
        {
            sr = visual.GetComponent<SpriteRenderer>();
            anim = visual.GetComponent<SpriteSheetAnimator>();
        }
        pad = GetComponent<TouchPad>();
        if (pad == null) pad = gameObject.AddComponent<TouchPad>();
    }

    void Start()
    {
        if (anim != null && anim.Load("Sprites/ghost"))
        {
            anim.Define("float", 0, 4, 6f);
            anim.Define("possess", 4, 1, 1f);
            anim.Play("float");
        }
    }

    void Update()
    {
        bool playing = GameManager.Instance == null || GameManager.Instance.State == GameState.Playing;
        float dt = Time.deltaTime;

        if (playing) HandleInput();
        else ExitPossession();

        // the possessed object was smashed
        if (inside && possessed == null) ExitPossession();

        if (pad != null)
        {
            bool possessing = inside && possessed != null;
            pad.Visible = playing;            // joystick sentiasa ada semasa bermain
            pad.FlightMode = !possessing;     // butang LOMPAT / KUASA / KELUAR hanya semasa merasuk
            if (playing && possessing)
            {
                pad.ActionLabel = possessed.SpecialLabel + "\n(" + Mathf.RoundToInt(possessed.specialEnergy) + ")";
                pad.ActionAffordable = Energy >= possessed.specialEnergy;
            }
        }

        Vector2 pos = transform.position;
        Vector2 flight = (pad != null && pad.Visible && pad.FlightMode) ? pad.MoveAxis : Vector2.zero;
        if (!inside && playing)
        {
            if (flight.sqrMagnitude > 0.0004f)
            {
                approaching = null; // joystick mengambil alih daripada terbang ke perabot
                goal = ClampToBuilding(pos + flight * moveSpeed * dt);
            }
            else if (approaching == null)
            {
                goal = pos; // lepas joystick = hantu berhenti
            }
        }
        Vector2 target = goal;
        if (inside) target = possessed.transform.position;
        else if (approaching != null) target = approaching.transform.position;

        Vector2 next = inside
            ? Vector2.Lerp(pos, target, 1f - Mathf.Exp(-14f * dt))
            : Vector2.MoveTowards(pos, target, moveSpeed * dt);
        transform.position = new Vector3(next.x, next.y, 0f);

        if (!inside && approaching != null && Vector2.Distance(next, target) < 0.8f)
            EnterPossession(approaching);

        float dx = target.x - pos.x;
        if (!inside && approaching == null && flight.sqrMagnitude > 0.0004f) dx = flight.x; // hadap arah joystick
        if (sr != null)
        {
            sr.enabled = !inside; // the ghost is inside the object
            if (Mathf.Abs(dx) > 0.05f) sr.flipX = dx < 0f;
        }
        if (visual != null) visual.localPosition = new Vector3(0f, Mathf.Sin(Time.time * 3f) * bobHeight, 0f);
        if (anim != null) anim.Play(inside ? "possess" : "float");

        if (IsRefilling) Energy = Mathf.Min(maxEnergy, Energy + maxEnergy * (refillPercentPerSecond / 100f) * dt);
    }

    void HandleInput()
    {
        if (cam == null) return;

        // while possessing, all input goes to the TouchPad (joystick / jump / special / KELUAR)
        if (inside)
        {
            if (pad != null && pad.ExitDown) ExitPossession();
            return;
        }

        // joystick menggerakkan hantu (lihat Update); ketukan hanya untuk merasuk perabot
        if (Input.touchCount > 0)
        {
            for (int i = 0; i < Input.touchCount; i++)
            {
                Touch t = Input.GetTouch(i);
                if (t.phase != TouchPhase.Began) continue;
                if (pad != null && t.fingerId == pad.JoystickFinger) continue; // jari joystick
                TryTapPossess(t.position, t.fingerId);
            }
        }
        else if (Input.GetMouseButtonDown(0) && (pad == null || pad.JoystickFinger != -2))
        {
            TryTapPossess(Input.mousePosition, -1);
        }

        // ketukan pantas dalam zon joystick = ketukan biasa (bukan seretan)
        if (pad != null && pad.TapPending)
        {
            pad.TapPending = false;
            TryTapPossess(pad.TapScreenPos, -99);
        }
    }

    void TryTapPossess(Vector2 screenPos, int fingerId)
    {
        if (PointerBlocked(screenPos, fingerId)) return;
        Possessable p = PickPossessable(cam.ScreenToWorldPoint(screenPos));
        if (p != null) approaching = p;
    }

    // Ketukan pada butang jeda / LANGKAU (IMGUI) atau UI uGUI bukan arahan merasuk.
    static bool PointerBlocked(Vector2 screenPos, int fingerId)
    {
        if (PauseMenu.Blocks(screenPos) || Tutorial.Blocks(screenPos)) return true;
        if (fingerId == -99) return false;

        UnityEngine.EventSystems.EventSystem es = UnityEngine.EventSystems.EventSystem.current;
        if (es == null) return false;
        return fingerId >= 0 ? es.IsPointerOverGameObject(fingerId) : es.IsPointerOverGameObject();
    }

    Vector2 ClampToBuilding(Vector2 p)
    {
        return new Vector2(Mathf.Clamp(p.x, flightMin.x, flightMax.x), Mathf.Clamp(p.y, flightMin.y, flightMax.y));
    }

    Possessable PickPossessable(Vector2 wp)
    {
        Collider2D[] cols = Physics2D.OverlapCircleAll(wp, pickRadius, furnitureMask);
        Possessable best = null;
        float bestD = float.MaxValue;
        foreach (Collider2D c in cols)
        {
            Possessable q = c.GetComponentInParent<Possessable>();
            if (q == null) continue;
            float d = Vector2.Distance(c.ClosestPoint(wp), wp);
            if (d < bestD)
            {
                bestD = d;
                best = q;
            }
        }
        return best;
    }

    void EnterPossession(Possessable p)
    {
        possessed = p;
        approaching = null;
        inside = true;
        p.BeginPossess(); // Possessable sendiri memainkan bunyi "moan"
    }

    void ExitPossession()
    {
        if (possessed != null)
        {
            possessed.EndPossession();
            AudioManager.Play("whoosh", 0.35f, 1.4f);
        }
        possessed = null;
        inside = false;
        goal = transform.position;
    }

    // Called when the possessed object is destroyed.
    public void ForceRelease()
    {
        ExitPossession();
    }

    // Dipanggil oleh GameManager di awal malam. overrideMax > 0 = nilai tetap dari LevelConfig.
    public void SetupForGuests(int guests, float overrideMax)
    {
        if (overrideMax > 0f) maxEnergy = overrideMax;
        else if (energyBase > 0f || energyPerGuest > 0f) maxEnergy = energyBase + energyPerGuest * Mathf.Max(1, guests);
        Energy = maxEnergy;
        lastSpendTime = -99f;
        Debug.Log("[Tenaga] " + guests + " tetamu -> tenaga penuh " + Mathf.RoundToInt(maxEnergy));
    }

    public bool TrySpend(float amount)
    {
        if (Energy < amount)
        {
            LastDeniedTime = Time.time;
            AudioManager.Play("denied", 0.8f, 1f, 0f);
            return false;
        }
        Energy -= amount;
        lastSpendTime = Time.time;
        return true;
    }

    // Untuk ganjaran masa depan (contoh: tambah tenaga bila manusia lari). Tidak melebihi maxEnergy.
    public void Refill(float amount)
    {
        Energy = Mathf.Min(maxEnergy, Energy + amount);
    }

    // Dipanggil oleh HumanAI bila seorang manusia mula lari.
    public void RewardForFlee()
    {
        if (refillWhenGuestFlees > 0f) Refill(refillWhenGuestFlees);
    }

    public void Spend(float amount)
    {
        Energy = Mathf.Max(0f, Energy - amount);
        lastSpendTime = Time.time;
    }
}
