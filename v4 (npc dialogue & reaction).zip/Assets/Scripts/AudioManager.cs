using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

/// <summary>
/// Pengurus audio Hantu Rumah.
///
/// - Dicipta sendiri semasa game bermula (tak perlu letak dalam scene).
/// - Hidup merentasi scene (DontDestroyOnLoad).
/// - Muzik: Resources/Audio/Music/menu dan game, bertukar ikut scene dengan fade.
/// - Kesan bunyi: Resources/Audio/SFX/&lt;nama&gt;, dimainkan melalui AudioManager.Play("nama").
///   (Dinamakan Play, bukan Sfx, kerana projek ini sudah ada kelas Sfx sendiri.)
/// - Semua butang UI dapat bunyi "click" secara automatik.
/// - Sfx.Play(...) lama (Possessable, HumanAI) dihantar ke sini, jadi hanya ada satu sistem bunyi.
/// - Fail yang tiada hanya beri amaran sekali, game tak ralat.
///
/// Penggunaan dari skrip lain:
///   AudioManager.Play("denied");
///   AudioManager.Play("scare", 0.8f);
///   AudioManager.Music("game");      // tukar lagu
///   AudioManager.Music(null);        // fade keluar (cth. sebelum bunyi menang)
/// </summary>
public class AudioManager : MonoBehaviour
{
    public static AudioManager Instance { get; private set; }

    [Header("Volume")]
    [Range(0f, 1f)] public float musicVolume = 0.45f;
    [Range(0f, 1f)] public float sfxVolume = 0.9f;
    public float musicFadeTime = 1.0f;

    [Header("Scene")]
    public string menuScene = "MainMenu";

    const string MusicPath = "Audio/Music/";
    const string SfxPath = "Audio/SFX/";      // placeholder daripada zip audio
    const string OwnSfxPath = "Sfx/";         // fail kamu sendiri (diutamakan)
    const int PoolSize = 10;
    const float MinRepeatGap = 0.04f; // elak bunyi sama bertindih terlalu rapat

    AudioSource musicSrc;
    AudioSource[] pool;
    int poolIndex;

    readonly Dictionary<string, AudioClip> cache = new Dictionary<string, AudioClip>();
    readonly Dictionary<string, float> lastPlayed = new Dictionary<string, float>();
    readonly HashSet<string> warned = new HashSet<string>();

    string currentMusic;
    string wantedMusic;
    float musicGain;
    int lastSceneHandle = -1;

    // ---------- Permulaan ----------

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    static void Bootstrap()
    {
        if (Instance != null) return;
        var go = new GameObject("AudioManager");
        go.AddComponent<AudioManager>();
    }

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
        DontDestroyOnLoad(gameObject);

        musicSrc = gameObject.AddComponent<AudioSource>();
        musicSrc.loop = true;
        musicSrc.playOnAwake = false;
        musicSrc.spatialBlend = 0f;
        musicSrc.volume = 0f;

        pool = new AudioSource[PoolSize];
        for (int i = 0; i < PoolSize; i++)
        {
            var s = gameObject.AddComponent<AudioSource>();
            s.playOnAwake = false;
            s.spatialBlend = 0f;
            s.ignoreListenerPause = true; // supaya klik butang jeda/sambung masih berbunyi
            pool[i] = s;
        }

        // Hormati tetapan bunyi daripada menu (HIDUP/MATI)
        AudioListener.volume = PlayerPrefs.GetInt("sound_on", 1) == 1 ? 1f : 0f;

        SceneManager.sceneLoaded += OnSceneLoaded;
    }

    void Start()
    {
        // sceneLoaded mungkin tak dicetus untuk scene pertama, jadi kendalikan sendiri
        HandleScene(SceneManager.GetActiveScene());
    }

    void OnDestroy()
    {
        if (Instance == this)
        {
            SceneManager.sceneLoaded -= OnSceneLoaded;
            Instance = null;
        }
    }

    void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        HandleScene(scene);
    }

    void HandleScene(Scene scene)
    {
        if (!scene.IsValid() || scene.handle == lastSceneHandle) return;
        lastSceneHandle = scene.handle;

        wantedMusic = scene.name == menuScene ? "menu" : "game";
        HookButtons(scene);
    }

    // ---------- Muzik ----------

    void Update()
    {
        // Fade guna masa tak terskala supaya berfungsi walaupun game dijeda
        float dt = Time.unscaledDeltaTime;
        float step = musicFadeTime <= 0.01f ? 1f : dt / musicFadeTime;

        if (currentMusic != wantedMusic)
        {
            musicGain -= step;
            if (musicGain <= 0f)
            {
                musicGain = 0f;
                SwitchMusic(wantedMusic);
            }
        }
        else if (musicGain < 1f)
        {
            musicGain = Mathf.Min(1f, musicGain + step);
        }

        musicSrc.volume = musicVolume * musicGain;
    }

    void SwitchMusic(string name)
    {
        currentMusic = name;
        AudioClip clip = string.IsNullOrEmpty(name) ? null : Load(MusicPath + name);
        musicSrc.clip = clip;
        if (clip != null) musicSrc.Play(); else musicSrc.Stop();
    }

    public static void Music(string name)
    {
        if (Instance != null) Instance.wantedMusic = name;
    }

    // ---------- Kesan bunyi ----------

    public static void Play(string name, float volume = 1f, float pitch = 1f, float pitchJitter = 0.05f)
    {
        if (Instance != null) Instance.PlaySfx(name, volume, pitch, pitchJitter);
    }

    void PlaySfx(string name, float volume, float pitch, float jitter)
    {
        if (string.IsNullOrEmpty(name)) return;

        float now = Time.unscaledTime;
        float last;
        if (lastPlayed.TryGetValue(name, out last) && now - last < MinRepeatGap) return;
        lastPlayed[name] = now;

        AudioClip clip = LoadSfx(name);
        if (clip == null) return;

        AudioSource s = pool[poolIndex];
        poolIndex = (poolIndex + 1) % pool.Length;

        s.clip = clip;
        s.volume = Mathf.Clamp01(volume * sfxVolume);
        s.pitch = pitch + Random.Range(-jitter, jitter);
        s.Play();
    }

    AudioClip Load(string path)
    {
        AudioClip clip;
        if (cache.TryGetValue(path, out clip)) return clip;

        clip = Resources.Load<AudioClip>(path);
        cache[path] = clip;
        if (clip == null && warned.Add(path))
            Debug.LogWarning("[AudioManager] Fail bunyi tiada: Assets/Resources/" + path + " (.wav/.ogg/.mp3)");
        return clip;
    }

    AudioClip LoadSfx(string name)
    {
        string key = "sfx:" + name;
        AudioClip clip;
        if (cache.TryGetValue(key, out clip)) return clip;

        clip = Resources.Load<AudioClip>(OwnSfxPath + name);
        if (clip == null) clip = Resources.Load<AudioClip>(SfxPath + name);
        cache[key] = clip;

        if (clip == null && warned.Add(key))
            Debug.LogWarning("[AudioManager] Bunyi '" + name + "' tiada. Letak fail dalam Assets/Resources/Sfx/ atau Assets/Resources/Audio/SFX/");
        return clip;
    }

    // ---------- Sambungan automatik ----------

    void HookButtons(Scene scene)
    {
        // FindObjectsOfTypeAll juga menjumpai butang dalam panel yang tak aktif
        var buttons = Resources.FindObjectsOfTypeAll<Button>();
        foreach (var b in buttons)
        {
            if (b == null || b.gameObject.scene.handle != scene.handle) continue;
            b.onClick.AddListener(PlayClick);
        }
    }

    static void PlayClick()
    {
        Play("click", 0.7f, 1f, 0.02f);
    }
}
