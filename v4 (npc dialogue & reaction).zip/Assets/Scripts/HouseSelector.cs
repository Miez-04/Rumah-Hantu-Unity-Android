using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>
/// Memilih rumah (scene) seterusnya secara rawak. Rumah ialah mana-mana scene dalam Build Settings yang laluannya
/// mengandungi "/Houses/" (dibina oleh Ghost > 5 - Build All Houses). Tiada senarai untuk diselenggara.
///
/// Kaedah "beg": setiap rumah muncul sekali sebelum mana-mana rumah diulang, dan rumah yang sama tak muncul
/// dua kali berturut-turut. Jika tiada rumah dalam Build Settings, scene sandaran dimuat (cth. "Main").
/// </summary>
public static class HouseSelector
{
    public const string FolderMarker = "/Houses/";

    static readonly List<string> bag = new List<string>();
    static string last;

    static List<string> AllHouses()
    {
        List<string> list = new List<string>();
        int n = SceneManager.sceneCountInBuildSettings;
        for (int i = 0; i < n; i++)
        {
            string path = SceneUtility.GetScenePathByBuildIndex(i);
            if (!string.IsNullOrEmpty(path) && path.Contains(FolderMarker)) list.Add(path);
        }
        return list;
    }

    public static int HouseCount { get { return AllHouses().Count; } }

    // Muat rumah rawak seterusnya. fallbackScene dimuat jika tiada rumah (null = muat semula scene semasa).
    public static void LoadNext(string fallbackScene)
    {
        string next = PickNext();
        if (next != null)
        {
            last = next;
            SceneManager.LoadScene(next);
        }
        else if (!string.IsNullOrEmpty(fallbackScene))
        {
            SceneManager.LoadScene(fallbackScene);
        }
        else
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }
    }

    static string PickNext()
    {
        List<string> all = AllHouses();
        if (all.Count == 0) return null;
        if (all.Count == 1) return all[0];

        // buang entri beg yang sudah tiada dalam Build Settings
        bag.RemoveAll(p => !all.Contains(p));

        if (bag.Count == 0)
        {
            bag.AddRange(all);
            for (int i = bag.Count - 1; i > 0; i--) // kocok Fisher-Yates
            {
                int j = Random.Range(0, i + 1);
                string tmp = bag[i]; bag[i] = bag[j]; bag[j] = tmp;
            }
            // beg baharu tak boleh bermula dengan rumah yang baru dimain
            if (bag[0] == last)
            {
                string tmp = bag[0]; bag[0] = bag[bag.Count - 1]; bag[bag.Count - 1] = tmp;
            }
        }

        // jangan pilih rumah yang sedang dimain (cth. bila Editor terus Play dari satu rumah)
        string current = SceneManager.GetActiveScene().path;
        int idx = 0;
        if (bag[0] == current && bag.Count > 1) idx = 1;

        string pick = bag[idx];
        bag.RemoveAt(idx);
        return pick;
    }
}
