using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Letak pada objek yang ada Image. Semasa game bermula, ia memasang sprite yang dijana UiKit
/// (segi empat bulat, garis tepi, cahaya, bintang atau kecerunan). Dipasang oleh alat pembina menu.
/// Dalam Scene view (sebelum Play) Image ini kelihatan sebagai segi empat putih, itu normal.
/// </summary>
[RequireComponent(typeof(Image))]
public class UiSkin : MonoBehaviour
{
    public enum Kind { Round, Ring, Glow, Star, Gradient, Triangle }

    public Kind kind = Kind.Round;
    public int radius = 24;
    public int ringThickness = 3;
    public Color gradientTop = Color.white;
    public Color gradientBottom = Color.white;

    void Awake()
    {
        Image img = GetComponent<Image>();
        switch (kind)
        {
            case Kind.Round:
                img.sprite = UiKit.RoundSprite(radius);
                img.type = Image.Type.Sliced;
                break;
            case Kind.Ring:
                img.sprite = UiKit.RingSprite(radius, ringThickness);
                img.type = Image.Type.Sliced;
                break;
            case Kind.Glow:
                img.sprite = UiKit.GlowSprite();
                img.type = Image.Type.Simple;
                break;
            case Kind.Star:
                img.sprite = UiKit.StarSprite();
                img.type = Image.Type.Simple;
                break;
            case Kind.Triangle:
                img.sprite = UiKit.TriangleSprite();
                img.type = Image.Type.Simple;
                break;
            case Kind.Gradient:
                img.sprite = UiKit.GradientSprite(gradientTop, gradientBottom);
                img.type = Image.Type.Simple;
                break;
        }
    }
}
