using UnityEngine;

// Small helpers for effects: screen shake, debris / dust bursts and shockwave rings.
public static class Fx
{
    static Sprite[] shards;
    static Sprite ring;

    public static void Shake(float duration, float magnitude)
    {
        CameraFollow2D.Shake(duration, magnitude);
    }

    public static void Burst(Vector2 pos, int count, Color tint, float speed = 4f, float up = 5f, float life = 0.9f)
    {
        if (shards == null || shards.Length == 0) shards = Resources.LoadAll<Sprite>("Sprites/shard");
        if (shards == null || shards.Length == 0) return;

        for (int i = 0; i < count; i++)
        {
            GameObject go = new GameObject("Fx");
            go.transform.position = pos + Random.insideUnitCircle * 0.3f;
            SpriteRenderer r = go.AddComponent<SpriteRenderer>();
            r.sprite = shards[Random.Range(0, shards.Length)];
            r.color = tint;
            r.sortingOrder = 12;
            ShardFly f = go.AddComponent<ShardFly>();
            f.velocity = new Vector2(Random.Range(-speed, speed), Random.Range(up * 0.3f, up));
            f.life = life;
        }
    }

    // Needs Assets/Resources/Sprites/glow.png
    public static void Ring(Vector2 pos, float worldSize, Color tint, float life = 0.45f)
    {
        if (ring == null) ring = Resources.Load<Sprite>("Sprites/glow");
        if (ring == null) return;

        GameObject go = new GameObject("Ring");
        go.transform.position = pos;
        SpriteRenderer r = go.AddComponent<SpriteRenderer>();
        r.sprite = ring;
        r.color = tint;
        r.sortingOrder = 11;
        RingFx fx = go.AddComponent<RingFx>();
        fx.maxScale = worldSize / Mathf.Max(0.01f, ring.bounds.size.x);
        fx.life = life;
    }
}
