using UnityEngine;

// An expanding, fading ring (shockwave). Created by Fx.Ring.
public class RingFx : MonoBehaviour
{
    public float maxScale = 4f;
    public float life = 0.45f;

    float age;
    SpriteRenderer sr;
    Color baseColor;

    void Awake()
    {
        sr = GetComponent<SpriteRenderer>();
    }

    void Start()
    {
        baseColor = sr.color;
        transform.localScale = Vector3.one * 0.2f;
    }

    void Update()
    {
        age += Time.deltaTime;
        float t = Mathf.Clamp01(age / life);
        float eased = 1f - (1f - t) * (1f - t);
        transform.localScale = Vector3.one * Mathf.Lerp(0.2f, maxScale, eased);
        Color c = baseColor;
        c.a = baseColor.a * (1f - t);
        sr.color = c;
        if (age >= life) Destroy(gameObject);
    }
}
