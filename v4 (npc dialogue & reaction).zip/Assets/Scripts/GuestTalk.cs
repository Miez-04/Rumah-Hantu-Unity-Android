using UnityEngine;

/// <summary>Ayat-ayat tetamu (Bahasa Melayu). Tambah atau ubah ayat di sini tanpa menyentuh logik AI.</summary>
public static class GuestTalk
{
    static string Pick(string[] a) { return a[Random.Range(0, a.Length)]; }

    // ---- perbualan dua orang: baris selang-seli, mula dengan orang pertama ----
    static readonly string[][] Convos =
    {
        new[] { "Rumah ni cantik, tapi sejuk sangat.", "Betul. Bulu roma aku meremang.", "Mungkin sebab dah malam." },
        new[] { "Kamu rasa rumah ni berhantu?", "Merepek. Itu cerita orang tua.", "Harap-harap macam tu la." },
        new[] { "Pesta tadi seronok kan?", "Seronok. Tapi lampu tu asyik berkelip.", "Aku pun perasan." },
        new[] { "Mana tuan rumah pergi?", "Entah. Dari tadi tak nampak.", "Pelik juga." },
        new[] { "Aku dengar bunyi kaki tadi.", "Itu kita punya la.", "Hmm, mungkin." },
        new[] { "Dah lewat ni. Nak balik?", "Sekejap lagi. Aku nak habiskan minum.", "Jangan lama sangat." },
        new[] { "Cuba tengok lukisan tu.", "Macam mata dia ikut kita pula.", "Jangan cakap macam tu!" },
        new[] { "Sofa ni empuk gila.", "Jangan duduk lama, nanti tertidur.", "Tak apa, kamu kejutkan aku." },
        new[] { "Kamu pernah masuk rumah ni dulu?", "Sekali, masa kecil.", "Ada apa-apa yang pelik?", "Tak ingat. Tapi aku rasa tak selesa." },
        new[] { "Aku lapar la.", "Tadi kan ada kuih.", "Dah habis dimakan kamu!" },
    };

    public static string[] Convo() { return Convos[Random.Range(0, Convos.Length)]; }

    // ---- gumaman bersendirian ----
    static readonly string[] Nervous =
    {
        "Aku tak sedap hati...", "Jom keluar cepat?", "Rumah ni... pelik.", "Siapa buka tingkap tadi?", "Aku rasa ada orang tengok kita.",
    };
    static readonly string[] Neutral =
    {
        "Hmm, sunyi pula.", "Mana yang lain?", "Cantik rumah ni.", "Dah pukul berapa ni?", "Hawa dia sejuk sikit.",
    };
    static readonly string[] Brave =
    {
        "Hantu? Merepek.", "Aku tak percaya semua tu.", "Tak ada apa-apa pun.", "Rumah lama memang berderit.",
    };

    public static string Mutter(string type)
    {
        if (type == "penakut") return Pick(Nervous);
        if (type == "berani") return Pick(Brave);
        return Pick(Neutral);
    }

    // ---- bila terdengar bunyi ----
    static readonly string[] HeardLines = { "Eh? Bunyi apa tu?", "Kamu dengar tak?", "Dari mana bunyi tu?", "Ada orang kat sana ke?", "Apa tu tadi?" };
    public static string Heard() { return Pick(HeardLines); }

    static readonly string[] GoLines = { "Aku periksa kejap.", "Jap, aku tengok.", "Aku pergi tengok." };
    static readonly string[] BraveGoLines = { "Biar aku periksa.", "Aku tak takut. Aku pergi.", "Mesti tikus." };
    public static string Go(string type) { return type == "berani" ? Pick(BraveGoLines) : Pick(GoLines); }

    static readonly string[] DismissLines = { "Tak ada apa-apa...", "Mungkin tikus.", "Angin kot.", "Pelik..." };
    static readonly string[] BraveDismissLines = { "Tak ada apa pun. Penakut betul.", "Aku dah cakap, tak ada apa-apa." };
    public static string Dismiss(string type) { return type == "berani" ? Pick(BraveDismissLines) : Pick(DismissLines); }

    static readonly string[] CompanyLines = { "Jom... jangan tinggalkan aku.", "Aku ikut kamu.", "Aku nak dekat dengan orang lain." };
    public static string Company() { return Pick(CompanyLines); }

    static readonly string[] AloneLines = { "A-aku tunggu sini je...", "Aku tak nak pergi sana.", "Aku tak berani..." };
    public static string Alone() { return Pick(AloneLines); }

    static readonly string[] NoWayLines = { "Entah dari mana tu...", "Jauh bunyi tu.", "Hmm..." };
    public static string NoWay() { return Pick(NoWayLines); }

    static readonly string[] CalmLines = { "Tenang... mungkin angin je.", "Jangan risau, tak ada apa-apa.", "Tarik nafas. Okay?" };
    public static string Calm() { return Pick(CalmLines); }

    // ---- bila ditakutkan ----
    public static string React(ScareKind kind)
    {
        switch (kind)
        {
            case ScareKind.Impact: return "Bunyi apa tu?!";
            case ScareKind.Smash: return "Ada benda pecah!";
            case ScareKind.Sound: return "Siapa ketawa tu?!";
            case ScareKind.Light: return "Lampu tu berkelip!";
            case ScareKind.Shake: return "Rumah bergegar!";
            case ScareKind.Panic: return "Dia lari! Kenapa?!";
            default: return "Perabot tu bergerak!";
        }
    }

    static readonly string[] FleeLines = { "Lari!!!", "HANTU!!", "Tolong!!", "Aku nak keluar!" };
    public static string Flee() { return Pick(FleeLines); }
}
