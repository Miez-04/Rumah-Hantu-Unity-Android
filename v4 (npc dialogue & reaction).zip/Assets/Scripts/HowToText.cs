/// <summary>Teks "Cara Main" yang dikongsi oleh menu utama dan menu jeda (satu sumber sahaja).</summary>
public static class HowToText
{
    public static readonly string[] Rows =
    {
        "Guna joystick di kiri bawah untuk terbangkan hantu ke mana-mana.",
        "Ketuk perabot untuk merasuk dan mengawalnya.",
        "Joystick untuk gerak, LOMPAT untuk melompat, dan KUASA khas perabot itu. KELUAR untuk keluar.",
        "Hentaman dan kaca pecah menakutkan tetamu berdekatan.",
        "Tetamu jadi kebal kalau gangguan sama diulang. Campurkan cara!",
    };

    public const string NoteEnergy = "Tenaga pulih perlahan bila tak guna kuasa, dan bertambah bila tetamu lari.";
    public const string NoteWin = "MENANG: semua tetamu keluar sebelum masa tamat.";
}
