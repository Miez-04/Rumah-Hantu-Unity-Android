using UnityEngine;

// Keeps the camera centred on the building horizontally and follows the ghost up and down.
// Orthographic size 6.75 shows 13.5 tiles tall; on a 16:9 screen that is 24 tiles wide = the whole building.
[RequireComponent(typeof(Camera))]
public class CameraFollow2D : MonoBehaviour
{
    public static CameraFollow2D Instance { get; private set; }

    public Transform target;
    public float orthographicSize = 6.75f;
    public float fixedX = 12f;
    public float minY = 6.75f;
    public float maxY = 15.25f;
    public float smooth = 6f;

    Camera cam;
    float shakeTime;
    float shakeDuration = 0.01f;
    float shakeMagnitude;

    public static void Shake(float duration, float magnitude)
    {
        if (Instance == null) return;
        Instance.shakeDuration = Mathf.Max(0.01f, duration);
        Instance.shakeTime = Instance.shakeDuration;
        Instance.shakeMagnitude = magnitude;
    }

    void Awake()
    {
        Instance = this;
    }

    void Start()
    {
        cam = GetComponent<Camera>();
        cam.orthographic = true;
        cam.orthographicSize = orthographicSize;
        if (target == null && GhostController.Instance != null) target = GhostController.Instance.transform;
    }

    void LateUpdate()
    {
        if (target == null) return;
        float y = Mathf.Clamp(target.position.y, minY, maxY);
        Vector3 p = transform.position;
        p.x = fixedX;
        p.y = Mathf.Lerp(p.y, y, 1f - Mathf.Exp(-smooth * Time.deltaTime));
        p.z = -10f;

        if (shakeTime > 0f)
        {
            shakeTime -= Time.deltaTime;
            float falloff = Mathf.Max(0f, shakeTime / shakeDuration);
            p += (Vector3)(Random.insideUnitCircle * shakeMagnitude * falloff);
        }
        transform.position = p;
    }
}
