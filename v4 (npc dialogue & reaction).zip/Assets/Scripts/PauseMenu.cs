using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>
/// Menu jeda dalam game, dilukis dengan IMGUI (sama seperti HUD dan TouchPad) supaya sentiasa ada pada telefon
/// tanpa bergantung pada objek yang dibina dalam scene. Dicipta sendiri oleh GameManager jika belum ada.
///
/// Butang jeda (II) sentiasa kelihatan di sebelah kanan pemasa semasa bermain.
/// Jeda = Time.timeScale 0, bunyi dijeda, input hantu dimatikan dan TouchPad disembunyikan.
/// Dari sini pemain boleh Sambung, buka Cara Main (dan mulakan tutorial berpandu), Ulang, atau pulang ke Menu Utama.
/// </summary>
public class PauseMenu : MonoBehaviour
{
    public static PauseMenu Instance { get; private set; }

    public string menuScene = "MainMenu";

    // Medan lama (versi menu jeda uGUI). Tidak digunakan lagi, dikekalkan kosong supaya salinan lama
    // PauseMenuBuilder yang tertinggal dalam projek tidak menyebabkan ralat compile.
    [HideInInspector] public GameObject pausePanel;
    [HideInInspector] public GameObject howToPanel;
    [HideInInspector] public GameObject pauseButton;

    enum Page { None, Pause, HowTo }
    Page page = Page.None;

    GhostController ghost;
    bool ghostWasEnabled;

    // Kawasan butang jeda (unit GUI) supaya GhostController tak anggap ketukan itu sebagai arahan terbang.
    static Rect buttonRect;
    static float buttonScale = 1f;
    static bool buttonActive;

    public bool IsPaused { get { return page != Page.None; } }

    public static bool Blocks(Vector2 screenPos)
    {
        if (!buttonActive) return false;
        Vector2 g = new Vector2(screenPos.x / buttonScale, (Screen.height - screenPos.y) / buttonScale);
        Rect r = new Rect(buttonRect.x - 8f, buttonRect.y - 8f, buttonRect.width + 16f, buttonRect.height + 16f);
        return r.Contains(g);
    }

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;

        // Canvas jeda lama (versi uGUI) dimatikan supaya tak ada dua butang jeda.
        GameObject legacy = GameObject.Find("PauseCanvas");
        if (legacy != null) legacy.SetActive(false);
    }

    void Start()
    {
        // Pastikan keadaan bersih bila scene dimuat (contoh selepas Ulang)
        Time.timeScale = 1f;
        AudioListener.pause = false;
        page = Page.None;
    }

    void OnDestroy()
    {
        // Jangan tinggalkan game dalam keadaan beku
        Time.timeScale = 1f;
        AudioListener.pause = false;
        buttonActive = false;
        if (Instance == this) Instance = null;
    }

    void Update()
    {
        GameManager gm = GameManager.Instance;
        bool ended = gm != null && gm.State != GameState.Playing;
        if (ended) return; // tiada jeda semasa skrin BERJAYA / MASA TAMAT

        // Butang Back Android (Escape pada PC): tutup Cara Main dahulu, kemudian jeda / sambung
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (page == Page.HowTo) HideHowTo();
            else if (page == Page.Pause) Resume();
            else Pause();
        }
    }

    void OnApplicationPause(bool paused)
    {
        // Auto-jeda bila pemain tukar app atau ada panggilan masuk
        GameManager gm = GameManager.Instance;
        bool playing = gm == null || gm.State == GameState.Playing;
        if (paused && page == Page.None && playing) Pause();
    }

    // ---------- Tindakan ----------

    public void Pause()
    {
        if (page != Page.None) return;
        page = Page.Pause;

        Time.timeScale = 0f;
        AudioListener.pause = true;

        ghost = GhostController.Instance;
        if (ghost != null)
        {
            ghostWasEnabled = ghost.enabled;
            ghost.enabled = false;

            // Sembunyikan TouchPad. Jangan matikan komponennya: TouchPad.Update yang terus berjalan
            // mengosongkan nilai gerak / lompat / kuasa, jadi Possessable tak menerima input lapuk.
            TouchPad pad = ghost.GetComponent<TouchPad>();
            if (pad != null) pad.Visible = false;
        }
    }

    public void Resume()
    {
        if (page == Page.None) return;
        page = Page.None;

        Time.timeScale = 1f;
        AudioListener.pause = false;

        if (ghost != null) ghost.enabled = ghostWasEnabled;
    }

    public void ShowHowTo()
    {
        if (page != Page.None) page = Page.HowTo;
    }

    public void HideHowTo()
    {
        if (page == Page.HowTo) page = Page.Pause;
    }

    // Sambung permainan dan mulakan tutorial berpandu dari mana-mana level.
    public void StartTutorial()
    {
        Resume();
        GameManager gm = GameManager.Instance;
        if (gm != null) Tutorial.Begin(gm.gameObject);
    }

    public void Restart()
    {
        Time.timeScale = 1f;
        AudioListener.pause = false;
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    public void ExitToMenu()
    {
        Time.timeScale = 1f;
        AudioListener.pause = false;
        SceneManager.LoadScene(menuScene);
    }

    // ---------- Lukisan (IMGUI) ----------

    void OnGUI()
    {
        GameManager gm = GameManager.Instance;
        bool playing = gm == null || gm.State == GameState.Playing;

        GUI.depth = -100; // di atas HUD dan tutorial
        float s = Screen.height / 540f;
        GUI.matrix = Matrix4x4.Scale(new Vector3(s, s, 1f));
        float W = Screen.width / s;
        const float H = 540f;

        Page p = page; // salinan: halaman mungkin bertukar semasa klik, tetapi lukisan satu laluan kekal sama

        buttonActive = false;
        if (p == Page.None)
        {
            if (!playing) return;

            Rect b = new Rect(W / 2f + 74f, 8f, 46f, 40f);
            buttonRect = b;
            buttonScale = s;
            buttonActive = true;
            if (UiKit.Button(b, "II", UiKit.HudPanel, UiKit.WithAlpha(UiKit.Ghost, 0.85f), UiKit.Ghost, 20, 20)) Pause();
            return;
        }

        GUI.color = new Color(0f, 0f, 0.04f, 0.74f);
        GUI.DrawTexture(new Rect(0f, 0f, W, H), Texture2D.whiteTexture);
        GUI.color = Color.white;

        if (p == Page.Pause) DrawPausePage(W, H);
        else DrawHowToPage(W, H);
    }

    void DrawPausePage(float W, float H)
    {
        Rect card = new Rect(W / 2f - 190f, H / 2f - 200f, 380f, 400f);
        UiKit.Glow(new Rect(card.x - 60f, card.y - 60f, card.width + 120f, card.height + 120f), UiKit.WithAlpha(UiKit.Ghost, 0.12f));
        UiKit.Round(card, UiKit.Panel, 28);
        UiKit.Ring(card, UiKit.WithAlpha(UiKit.PanelEdge, 0.95f), 28, 3);
        UiKit.Text(new Rect(card.x, card.y + 14f, card.width, 60f), "JEDA", 40, UiKit.Ghost);

        float bx = card.x + 40f;
        float bw = card.width - 80f;
        Color soft = new Color(1f, 1f, 1f, 0.5f);

        if (UiKit.Button(new Rect(bx, card.y + 90f, bw, 54f), "SAMBUNG", UiKit.Ghost, soft, UiKit.Dark, 22, 27)) Resume();
        if (UiKit.Button(new Rect(bx, card.y + 158f, bw, 54f), "CARA MAIN", UiKit.ButtonSecondary, UiKit.PanelEdge, UiKit.TextMain, 22, 27)) ShowHowTo();
        if (UiKit.Button(new Rect(bx, card.y + 226f, bw, 54f), "ULANG", UiKit.ButtonSecondary, UiKit.PanelEdge, UiKit.TextMain, 22, 27)) Restart();
        if (UiKit.Button(new Rect(bx, card.y + 294f, bw, 54f), "MENU UTAMA", UiKit.ButtonQuiet, UiKit.WithAlpha(UiKit.Danger, 0.7f), UiKit.TextMain, 22, 27)) ExitToMenu();
    }

    void DrawHowToPage(float W, float H)
    {
        Rect card = new Rect(W / 2f - 370f, H / 2f - 245f, 740f, 490f);
        UiKit.Round(card, UiKit.Panel, 28);
        UiKit.Ring(card, UiKit.WithAlpha(UiKit.PanelEdge, 0.95f), 28, 3);
        UiKit.Text(new Rect(card.x, card.y + 12f, card.width, 50f), "CARA MAIN", 34, UiKit.Ghost);

        string[] rows = HowToText.Rows;
        for (int i = 0; i < rows.Length; i++)
        {
            float y = card.y + 72f + i * 56f;
            Rect badge = new Rect(card.x + 26f, y + 8f, 32f, 32f);
            UiKit.Round(badge, UiKit.Ghost, 16);
            UiKit.Text(badge, (i + 1).ToString(), 18, UiKit.Dark, TextAnchor.MiddleCenter, false);
            UiKit.Text(new Rect(card.x + 72f, y, card.width - 100f, 48f), rows[i], 16, UiKit.TextMain,
                       TextAnchor.MiddleLeft, true, FontStyle.Normal, true);
        }

        UiKit.Text(new Rect(card.x, card.y + 356f, card.width, 24f), HowToText.NoteEnergy, 15, UiKit.Warm);
        UiKit.Text(new Rect(card.x, card.y + 380f, card.width, 24f), HowToText.NoteWin, 15, UiKit.TextDim,
                   TextAnchor.MiddleCenter, false, FontStyle.Normal);

        Color soft = new Color(1f, 1f, 1f, 0.5f);
        if (UiKit.Button(new Rect(card.x + 30f, card.y + 424f, 250f, 46f), "KEMBALI", UiKit.ButtonSecondary, UiKit.PanelEdge, UiKit.TextMain, 20, 23))
            HideHowTo();
        if (UiKit.Button(new Rect(card.xMax - 30f - 400f, card.y + 424f, 400f, 46f), "MULAKAN TUTORIAL", UiKit.Ghost, soft, UiKit.Dark, 20, 23))
            StartTutorial();
    }
}
