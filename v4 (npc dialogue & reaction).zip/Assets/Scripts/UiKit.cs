using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Tema UI Hantu Rumah (malam ungu + cahaya hantu biru), dikongsi oleh menu (uGUI) dan HUD (IMGUI).
/// Semua bentuk (segi empat bulat, bulatan cahaya, bintang) dijana melalui kod, jadi tiada aset baharu diperlukan.
/// </summary>
public static class UiKit
{
    // ================= Palet =================
    public static readonly Color Night     = new Color(0.04f, 0.03f, 0.10f, 1f);
    public static readonly Color Panel     = new Color(0.08f, 0.07f, 0.18f, 0.95f);
    public static readonly Color HudPanel  = new Color(0.06f, 0.05f, 0.14f, 0.74f);
    public static readonly Color PanelEdge = new Color(0.42f, 0.38f, 0.82f, 0.85f);
    public static readonly Color Ghost     = new Color(0.62f, 0.88f, 1.00f, 1f);
    public static readonly Color GhostDeep = new Color(0.28f, 0.55f, 0.95f, 1f);
    public static readonly Color Warm      = new Color(1.00f, 0.80f, 0.38f, 1f);
    public static readonly Color Danger    = new Color(1.00f, 0.36f, 0.42f, 1f);
    public static readonly Color TextMain  = new Color(0.93f, 0.95f, 1.00f, 1f);
    public static readonly Color TextDim   = new Color(0.68f, 0.70f, 0.90f, 1f);
    public static readonly Color Dark      = new Color(0.05f, 0.06f, 0.16f, 1f);

    public static readonly Color ButtonSecondary = new Color(0.20f, 0.17f, 0.42f, 0.96f);
    public static readonly Color ButtonQuiet     = new Color(0.30f, 0.12f, 0.24f, 0.96f);

    public static Color WithAlpha(Color c, float a) { return new Color(c.r, c.g, c.b, a); }
    static Color Mul(Color a, Color b) { return new Color(a.r * b.r, a.g * b.g, a.b * b.b, a.a * b.a); }

    // ================= Penjana tekstur =================
    static readonly Dictionary<string, Texture2D> textures = new Dictionary<string, Texture2D>();
    static readonly Dictionary<string, Sprite> sprites = new Dictionary<string, Sprite>();
    static readonly Dictionary<int, GUIStyle> bgStyles = new Dictionary<int, GUIStyle>();
    static readonly Dictionary<int, GUIStyle> textStyles = new Dictionary<int, GUIStyle>();

    static Texture2D NewTex(int w, int h)
    {
        Texture2D t = new Texture2D(w, h, TextureFormat.RGBA32, false);
        t.wrapMode = TextureWrapMode.Clamp;
        t.filterMode = FilterMode.Bilinear;
        t.hideFlags = HideFlags.HideAndDontSave;
        return t;
    }

    static Texture2D Cached(string key, System.Func<Texture2D> make)
    {
        Texture2D t;
        if (textures.TryGetValue(key, out t) && t != null) return t;
        t = make();
        textures[key] = t;
        return t;
    }

    // Segi empat bulat. ring = 0 -> penuh; ring > 0 -> hanya garis tepi setebal "ring" piksel.
    public static Texture2D RoundTex(int radius, int ring)
    {
        return Cached("round_" + radius + "_" + ring, () => MakeRound(radius, ring));
    }

    static Texture2D MakeRound(int radius, int ring)
    {
        int size = radius * 2 + 2;
        Texture2D t = NewTex(size, size);
        Color32[] px = new Color32[size * size];
        float half = size * 0.5f;
        float inner = half - radius;
        for (int y = 0; y < size; y++)
        {
            for (int x = 0; x < size; x++)
            {
                float dx = Mathf.Abs(x + 0.5f - half) - inner;
                float dy = Mathf.Abs(y + 0.5f - half) - inner;
                float ox = Mathf.Max(dx, 0f);
                float oy = Mathf.Max(dy, 0f);
                float d = Mathf.Sqrt(ox * ox + oy * oy) + Mathf.Min(Mathf.Max(dx, dy), 0f) - radius; // <0 = di dalam
                float a = Mathf.Clamp01(0.5f - d);
                if (ring > 0) a *= 1f - Mathf.Clamp01(0.5f - (d + ring));
                px[y * size + x] = new Color32(255, 255, 255, (byte)Mathf.RoundToInt(a * 255f));
            }
        }
        t.SetPixels32(px);
        t.Apply(false, false);
        return t;
    }

    // Bulatan cahaya lembut (pudar ke tepi).
    public static Texture2D GlowTex()
    {
        return Cached("glow", () =>
        {
            const int size = 128;
            Texture2D t = NewTex(size, size);
            Color32[] px = new Color32[size * size];
            float half = size * 0.5f;
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float dx = x + 0.5f - half;
                    float dy = y + 0.5f - half;
                    float r = Mathf.Sqrt(dx * dx + dy * dy) / half;
                    float a = Mathf.Pow(Mathf.Clamp01(1f - r), 2.2f);
                    px[y * size + x] = new Color32(255, 255, 255, (byte)Mathf.RoundToInt(a * 255f));
                }
            }
            t.SetPixels32(px);
            t.Apply(false, false);
            return t;
        });
    }

    // Bintang lima bucu.
    public static Texture2D StarTex()
    {
        return Cached("star", () =>
        {
            const int size = 96;
            Texture2D t = NewTex(size, size);
            Vector2[] v = new Vector2[10];
            for (int i = 0; i < 10; i++)
            {
                float ang = Mathf.PI * 0.5f + i * Mathf.PI / 5f;
                float rr = (i % 2 == 0 ? 0.47f : 0.22f) * size;
                v[i] = new Vector2(size * 0.5f + Mathf.Cos(ang) * rr, size * 0.5f + Mathf.Sin(ang) * rr - size * 0.02f);
            }
            Color32[] px = new Color32[size * size];
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    int hit = 0;
                    for (int sy = 0; sy < 3; sy++)
                        for (int sx = 0; sx < 3; sx++)
                            if (InPoly(v, x + (sx + 0.5f) / 3f, y + (sy + 0.5f) / 3f)) hit++;
                    px[y * size + x] = new Color32(255, 255, 255, (byte)Mathf.RoundToInt(hit / 9f * 255f));
                }
            }
            t.SetPixels32(px);
            t.Apply(false, false);
            return t;
        });
    }

    static bool InPoly(Vector2[] v, float px, float py)
    {
        bool inside = false;
        for (int i = 0, j = v.Length - 1; i < v.Length; j = i++)
        {
            if (((v[i].y > py) != (v[j].y > py)) &&
                (px < (v[j].x - v[i].x) * (py - v[i].y) / (v[j].y - v[i].y) + v[i].x))
                inside = !inside;
        }
        return inside;
    }

    // Segi tiga sama kaki (puncak di atas), untuk bumbung.
    public static Texture2D TriangleTex()
    {
        return Cached("triangle", () =>
        {
            const int size = 64;
            Texture2D t = NewTex(size, size);
            Vector2 a = new Vector2(size * 0.5f, size - 0.5f);
            Vector2 b = new Vector2(0f, 0f);
            Vector2 c = new Vector2(size, 0f);
            Color32[] px = new Color32[size * size];
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    int hit = 0;
                    for (int sy = 0; sy < 3; sy++)
                        for (int sx = 0; sx < 3; sx++)
                            if (InTri(new Vector2(x + (sx + 0.5f) / 3f, y + (sy + 0.5f) / 3f), a, b, c)) hit++;
                    px[y * size + x] = new Color32(255, 255, 255, (byte)Mathf.RoundToInt(hit / 9f * 255f));
                }
            }
            t.SetPixels32(px);
            t.Apply(false, false);
            return t;
        });
    }

    static bool InTri(Vector2 p, Vector2 a, Vector2 b, Vector2 c)
    {
        float d1 = (p.x - b.x) * (a.y - b.y) - (a.x - b.x) * (p.y - b.y);
        float d2 = (p.x - c.x) * (b.y - c.y) - (b.x - c.x) * (p.y - c.y);
        float d3 = (p.x - a.x) * (c.y - a.y) - (c.x - a.x) * (p.y - a.y);
        bool neg = d1 < 0f || d2 < 0f || d3 < 0f;
        bool pos = d1 > 0f || d2 > 0f || d3 > 0f;
        return !(neg && pos);
    }

    // Kecerunan menegak (atas -> bawah), alpha ikut warna.
    public static Texture2D GradientTex(Color top, Color bottom)
    {
        string key = "grad_" + ColorUtility.ToHtmlStringRGBA(top) + "_" + ColorUtility.ToHtmlStringRGBA(bottom);
        return Cached(key, () =>
        {
            const int h = 128;
            Texture2D t = NewTex(2, h);
            Color[] px = new Color[2 * h];
            for (int y = 0; y < h; y++)
            {
                Color c = Color.Lerp(bottom, top, y / (float)(h - 1));
                px[y * 2] = c;
                px[y * 2 + 1] = c;
            }
            t.SetPixels(px);
            t.Apply(false, false);
            return t;
        });
    }

    // ================= Sprite (untuk uGUI) =================
    static Sprite SpriteFrom(string key, Texture2D t, int border)
    {
        Sprite s;
        if (sprites.TryGetValue(key, out s) && s != null) return s;
        s = Sprite.Create(t, new Rect(0, 0, t.width, t.height), new Vector2(0.5f, 0.5f), 100f, 0,
                          SpriteMeshType.FullRect, new Vector4(border, border, border, border));
        s.hideFlags = HideFlags.HideAndDontSave;
        sprites[key] = s;
        return s;
    }

    public static Sprite RoundSprite(int radius) { return SpriteFrom("rs_" + radius, RoundTex(radius, 0), radius); }
    public static Sprite RingSprite(int radius, int thickness) { return SpriteFrom("rr_" + radius + "_" + thickness, RoundTex(radius, thickness), radius); }
    public static Sprite GlowSprite() { return SpriteFrom("gs", GlowTex(), 0); }
    public static Sprite StarSprite() { return SpriteFrom("ss", StarTex(), 0); }
    public static Sprite TriangleSprite() { return SpriteFrom("ts", TriangleTex(), 0); }
    public static Sprite GradientSprite(Color top, Color bottom)
    {
        string key = "gr_" + ColorUtility.ToHtmlStringRGBA(top) + "_" + ColorUtility.ToHtmlStringRGBA(bottom);
        return SpriteFrom(key, GradientTex(top, bottom), 0);
    }

    // ================= Pembantu IMGUI (HUD, TouchPad, skrin akhir) =================
    static GUIStyle BgStyle(int radius, int ring)
    {
        int key = radius * 100 + ring;
        GUIStyle st;
        if (bgStyles.TryGetValue(key, out st) && st.normal.background != null) return st;
        st = new GUIStyle();
        st.normal.background = RoundTex(radius, ring);
        st.border = new RectOffset(radius, radius, radius, radius);
        bgStyles[key] = st;
        return st;
    }

    static int ClampRadius(Rect r, int radius)
    {
        return Mathf.Max(2, Mathf.Min(radius, Mathf.FloorToInt(Mathf.Min(r.width, r.height) * 0.5f)));
    }

    public static void Round(Rect r, Color c, int radius = 14)
    {
        if (Event.current.type != EventType.Repaint) return;
        if (r.width < 2f || r.height < 2f) return;
        Color prev = GUI.color;
        GUI.color = Mul(c, prev);
        BgStyle(ClampRadius(r, radius), 0).Draw(r, false, false, false, false);
        GUI.color = prev;
    }

    public static void Ring(Rect r, Color c, int radius = 14, int thickness = 2)
    {
        if (Event.current.type != EventType.Repaint) return;
        if (r.width < 2f || r.height < 2f) return;
        Color prev = GUI.color;
        GUI.color = Mul(c, prev);
        BgStyle(ClampRadius(r, radius), thickness).Draw(r, false, false, false, false);
        GUI.color = prev;
    }

    public static void Glow(Rect r, Color c)
    {
        if (Event.current.type != EventType.Repaint) return;
        Color prev = GUI.color;
        GUI.color = Mul(c, prev);
        GUI.DrawTexture(r, GlowTex());
        GUI.color = prev;
    }

    public static void Star(Rect r, Color c)
    {
        if (Event.current.type != EventType.Repaint) return;
        Color prev = GUI.color;
        GUI.color = Mul(c, prev);
        GUI.DrawTexture(r, StarTex());
        GUI.color = prev;
    }

    static GUIStyle TextStyle(int size, TextAnchor anchor, FontStyle style, bool wrap)
    {
        int key = size * 1000 + (int)anchor * 100 + (int)style * 10 + (wrap ? 1 : 0);
        GUIStyle st;
        if (textStyles.TryGetValue(key, out st)) return st;
        st = new GUIStyle(GUI.skin.label);
        st.fontSize = size;
        st.alignment = anchor;
        st.fontStyle = style;
        st.wordWrap = wrap;
        st.clipping = TextClipping.Overflow;
        st.richText = false;
        textStyles[key] = st;
        return st;
    }

    // Saiz teks dalam unit GUI (untuk saiz gelembung cakap).
    public static Vector2 Measure(string text, int size, FontStyle style)
    {
        return TextStyle(size, TextAnchor.MiddleCenter, style, false).CalcSize(new GUIContent(text));
    }

    public static void Text(Rect r, string text, int size, Color color,
                            TextAnchor anchor = TextAnchor.MiddleCenter, bool shadow = true,
                            FontStyle style = FontStyle.Bold, bool wrap = false)
    {
        GUIStyle st = TextStyle(size, anchor, style, wrap);
        if (shadow)
        {
            Rect sr = r;
            sr.x += 1f;
            sr.y += 1.5f;
            st.normal.textColor = new Color(0f, 0f, 0.05f, 0.65f * color.a);
            GUI.Label(sr, text, st);
        }
        st.normal.textColor = color;
        GUI.Label(r, text, st);
    }

    // Butang IMGUI bulat: dilukis sendiri, hit-area dari GUI.Button tanpa gaya. Mengembalikan true bila diklik.
    // Mesti dipanggil pada setiap acara (bukan hanya Repaint) supaya klik berdaftar.
    public static bool Button(Rect r, string label, Color fill, Color ringColor, Color textColor, int size, int radius)
    {
        bool pressed = Input.GetMouseButton(0) && r.Contains(Event.current.mousePosition);
        Rect v = r;
        if (pressed) v.y += 2f;
        Round(v, pressed ? Color.Lerp(fill, Color.black, 0.25f) : fill, radius);
        Ring(v, ringColor, radius, 2);
        Text(v, label, size, textColor, TextAnchor.MiddleCenter, false);

        bool clicked = GUI.Button(r, GUIContent.none, GUIStyle.none);
        if (clicked) AudioManager.Play("click", 0.7f);
        return clicked;
    }
}
