using UnityEngine;

// Pintu lama untuk kesan bunyi. Semua panggilan Sfx.Play("nama", volume, pitch) dalam game
// kini dihantar ke AudioManager (satu sistem sahaja: jeda, bunyi HIDUP/MATI, cache dan amaran fail tiada).
//
// Fail dicari mengikut urutan ini:
//   1) Assets/Resources/Sfx/<nama>          (fail kamu sendiri, diutamakan)
//   2) Assets/Resources/Audio/SFX/<nama>    (placeholder daripada zip audio)
public static class Sfx
{
    public static void Play(string name, float volume = 1f, float pitch = 1f)
    {
        AudioManager.Play(name, volume, pitch, 0f); // pitch sudah dirawakkan oleh pemanggil
    }
}
