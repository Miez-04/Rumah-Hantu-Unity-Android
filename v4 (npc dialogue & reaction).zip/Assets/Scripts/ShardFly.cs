using UnityEngine;

// A glass shard / debris chunk that flies, falls and fades.
public class ShardFly : MonoBehaviour
{
    public Vector2 velocity;
    public float life = 1.2f;
    public float gravity = 20f;
    public float spinSpeed = 360f;

    float age;
    SpriteRenderer sr;

    void Awake()
    {
        sr = GetComponent<SpriteRenderer>();
    }

    void Update()
    {
        float dt = Time.deltaTime;
        age += dt;
        velocity.y -= gravity * dt;
        transform.position += (Vector3)(velocity * dt);
        transform.Rotate(0f, 0f, spinSpeed * dt);

        if (sr != null)
        {
            Color c = sr.color;
            c.a = Mathf.Clamp01(1f - age / life);
            sr.color = c;
        }
        if (age >= life) Destroy(gameObject);
    }
}
