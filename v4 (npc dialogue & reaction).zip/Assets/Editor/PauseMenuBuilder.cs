#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>
/// Menu: Ghost > 4 - Build Pause Menu
/// Menu jeda kini dilukis oleh kod (IMGUI) dan dicipta sendiri oleh GameManager, jadi langkah ini TIDAK lagi wajib.
/// Menjalankannya hanya membuang canvas jeda lama (uGUI) dan meletakkan objek PauseMenu dalam scene supaya kamu boleh
/// melihatnya dalam Hierarchy. Selamat dijalankan berulang kali.
/// </summary>
public static class PauseMenuBuilder
{
    [MenuItem("Ghost/4 - Build Pause Menu")]
    public static void Build()
    {
        Scene scene = SceneManager.GetActiveScene();
        if (scene.name == "MainMenu")
        {
            EditorUtility.DisplayDialog("Pause Menu",
                "Buka scene Main (scene permainan) dahulu, kemudian jalankan semula menu ini.", "OK");
            return;
        }

        DestroyAll("PauseCanvas");
        DestroyAll("PauseMenu");

        var go = new GameObject("PauseMenu");
        go.AddComponent<PauseMenu>();

        EditorSceneManager.MarkSceneDirty(scene);
        if (!string.IsNullOrEmpty(scene.path)) EditorSceneManager.SaveScene(scene);

        Debug.Log("Menu jeda siap. Ia dilukis oleh kod semasa Play: butang II sentiasa ada di sebelah kanan pemasa.");
    }

    static void DestroyAll(string name)
    {
        var go = GameObject.Find(name);
        while (go != null)
        {
            Object.DestroyImmediate(go);
            go = GameObject.Find(name);
        }
    }
}
#endif
