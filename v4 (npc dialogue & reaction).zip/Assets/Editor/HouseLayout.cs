#if UNITY_EDITOR
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Denah satu rumah, ditakrif sebagai data. Peraturan geometri (sama seperti MansionBuilder asal kamu):
///  - 1 jubin = 1 unit. Dinding bata di indeks x = 0 dan x = 23. Ruang dalam x = 1..22.
///  - Papak lantai pada baris y = 7 * tingkat. Permukaan berjalan = 7 * tingkat + 1. Rasuk siling pada baris 7 * bilangan tingkat.
///  - Tangga ialah 7 jubin menyerong. Jubin ke-k berada di (bx + dir * k, 7 * from + 1 + k). dir = +1 menaik ke kanan, -1 ke kiri.
///  - Dua jubin lantai di atas hujung tangga dikosongkan sebagai lubang (supaya kepala tak tersekat).
///  - Nod tangga: bawah = (bx + 0.5 - 0.5 * dir), atas = (bx + 0.5 + 6.5 * dir). Garis ini melalui tengah semua jubin tangga.
/// Validate() menyemak denah tanpa membina apa-apa: tangga, lubang, ruang kepala, pautan, capaian ke pintu keluar dan perabot.
/// </summary>
public class HouseLayout
{
    public const int Step = 7;
    const float AutoLinkMaxDx = 7f; // sama dengan WaypointNode.AutoLinkMaxDx

    public class Stair
    {
        public int from, bx, dir;
        public Stair(int from, int bx, int dir) { this.from = from; this.bx = bx; this.dir = dir; }
        public int TopTileX { get { return bx + dir * (Step - 1); } }
    }

    public class NodeDef
    {
        public string name; public float x; public int floor; public bool exit, spawn;
        public NodeDef(string name, float x, int floor, bool exit, bool spawn)
        { this.name = name; this.x = x; this.floor = floor; this.exit = exit; this.spawn = spawn; }
    }

    public class PropDef
    {
        public string name; public float x, y; public bool onProp;
        public PropDef(string name, float x, float y, bool onProp)
        { this.name = name; this.x = x; this.y = y; this.onProp = onProp; }
    }

    public class DecoDef
    {
        public string name; public float x, y;
        public DecoDef(string name, float x, float y) { this.name = name; this.x = x; this.y = y; }
    }

    public readonly string id;
    public readonly string title;
    public readonly int floors;
    public readonly Vector2 ghostSpawn;
    public bool mirrored;

    public readonly List<Stair> stairs = new List<Stair>();
    public readonly List<NodeDef> nodes = new List<NodeDef>();
    public readonly List<PropDef> props = new List<PropDef>();
    public readonly List<DecoDef> decos = new List<DecoDef>();

    public HouseLayout(string id, string title, int floors, Vector2 ghostSpawn)
    {
        this.id = id; this.title = title; this.floors = floors; this.ghostSpawn = ghostSpawn;
    }

    public HouseLayout AddStair(int from, int bx, int dir) { stairs.Add(new Stair(from, bx, dir)); return this; }
    public HouseLayout AddNode(string name, float x, int floor, bool exit, bool spawn) { nodes.Add(new NodeDef(name, x, floor, exit, spawn)); return this; }
    public HouseLayout AddProp(string name, float x, float y, bool onProp) { props.Add(new PropDef(name, x, y, onProp)); return this; }
    public HouseLayout AddDeco(string name, float x, float y) { decos.Add(new DecoDef(name, x, y)); return this; }

    public static float FloorY(int floor) { return Step * floor + 1f; }
    public float CamMinY { get { return 6.75f; } }
    public float CamMaxY { get { return Step * floors - 5.75f; } }
    public float FlightMaxY { get { return Step * floors; } }

    public Vector2 StairBottomNode(Stair s) { return new Vector2(s.bx + 0.5f - 0.5f * s.dir, FloorY(s.from)); }
    public Vector2 StairTopNode(Stair s) { return new Vector2(s.bx + 0.5f + 6.5f * s.dir, FloorY(s.from + 1)); }
    public string StairBottomName(int i) { return "S" + i + "_Bot"; }
    public string StairTopName(int i) { return "S" + i + "_Top"; }

    // Cerminkan rumah ke kiri / kanan. Indeks jubin x -> 23 - x, koordinat dunia x -> 24 - x.
    public HouseLayout Mirror()
    {
        HouseLayout m = new HouseLayout(id + "_M", title + " (Cermin)", floors, new Vector2(24f - ghostSpawn.x, ghostSpawn.y));
        m.mirrored = !mirrored;
        foreach (Stair s in stairs) m.AddStair(s.from, 23 - s.bx, -s.dir);
        foreach (NodeDef n in nodes) m.AddNode(n.name, 24f - n.x, n.floor, n.exit, n.spawn);
        foreach (PropDef p in props) m.AddProp(p.name, 24f - p.x, p.y, p.onProp);
        foreach (DecoDef d in decos) m.AddDeco(d.name, 24f - d.x, d.y);
        return m;
    }

    // ---------- jisim / boleh pecah / tergantung (sama seperti LevelPopulator asal) ----------
    public static void PropDefaults(string name, out float mass, out bool breakable, out bool pinned)
    {
        mass = 3f; breakable = false; pinned = false;
        switch (name)
        {
            case "grandfather_clock": mass = 10f; break;
            case "couch": mass = 8f; break;
            case "doll": mass = 1f; break;
            case "table": mass = 4f; break;
            case "vase": mass = 0.5f; breakable = true; break;
            case "chair": mass = 2f; break;
            case "bookshelf": mass = 12f; break;
            case "picture_frame": mass = 0.5f; pinned = true; break;
            case "mirror": mass = 2f; breakable = true; pinned = true; break;
            case "floor_lamp": mass = 2f; breakable = true; break;
            case "chandelier": mass = 3f; breakable = true; pinned = true; break;
            case "candle": mass = 0.2f; break;
            case "bottle": mass = 0.3f; breakable = true; break;
        }
    }

    // saiz anggaran (lebar, tinggi) untuk semakan sahaja
    static Vector2 SizeOf(string name)
    {
        switch (name)
        {
            case "grandfather_clock": return new Vector2(1.0f, 3.1f);
            case "couch": return new Vector2(3.1f, 1.4f);
            case "doll": return new Vector2(0.7f, 1.0f);
            case "table": return new Vector2(1.9f, 1.5f);
            case "vase": return new Vector2(0.55f, 1.0f);
            case "chair": return new Vector2(0.8f, 1.4f);
            case "bookshelf": return new Vector2(2.05f, 3.1f);
            case "picture_frame": return new Vector2(1.0f, 1.0f);
            case "mirror": return new Vector2(1.1f, 2.1f);
            case "floor_lamp": return new Vector2(0.8f, 2.4f);
            case "chandelier": return new Vector2(1.3f, 2.25f);
            case "candle": return new Vector2(0.3f, 0.5f);
            case "bottle": return new Vector2(0.4f, 0.9f);
        }
        return new Vector2(1f, 1f);
    }

    // ---------- jadual terbitan ----------
    HashSet<int> stairTiles;
    Dictionary<int, HashSet<int>> holes; // baris papak -> set x

    static int Key(int x, int y) { return x * 1000 + y; }

    void BuildTables()
    {
        stairTiles = new HashSet<int>();
        holes = new Dictionary<int, HashSet<int>>();
        foreach (Stair s in stairs)
        {
            for (int k = 0; k < Step; k++) stairTiles.Add(Key(s.bx + s.dir * k, Step * s.from + 1 + k));
            int row = Step * (s.from + 1);
            if (!holes.ContainsKey(row)) holes[row] = new HashSet<int>();
            holes[row].Add(s.TopTileX - 2 * s.dir);
            holes[row].Add(s.TopTileX - s.dir);
        }
    }

    public bool IsHole(int x, int row)
    {
        if (holes == null) BuildTables();
        return holes.ContainsKey(row) && holes[row].Contains(x);
    }

    public bool IsStairTile(int x, int y)
    {
        if (stairTiles == null) BuildTables();
        return stairTiles.Contains(Key(x, y));
    }

    // Adakah jubin (x, y) pepejal?
    public bool IsSolid(int x, int y)
    {
        if (stairTiles == null) BuildTables();
        if (x <= 0 || x >= 23) return y >= 0 && y <= Step * floors;
        if (stairTiles.Contains(Key(x, y))) return true;
        bool slabRow = (y >= 0 && y < Step * floors && y % Step == 0) || y == Step * floors;
        if (slabRow) return !IsHole(x, y);
        return false;
    }

    class VNode
    {
        public string name; public float x, y; public bool exit, spawn; public int kind; // 0 biasa, 1 bawah tangga, 2 atas tangga
    }

    // ---------- pengesah ----------
    public List<string> Validate()
    {
        BuildTables();
        List<string> errs = new List<string>();

        // tangga
        Dictionary<int, int> seen = new Dictionary<int, int>();
        for (int i = 0; i < stairs.Count; i++)
        {
            Stair s = stairs[i];
            if (s.from < 0 || s.from + 1 > floors) errs.Add("tangga " + i + ": tingkat " + s.from + " di luar julat");
            if (s.dir != 1 && s.dir != -1) errs.Add("tangga " + i + ": arah mesti +1 atau -1");
            for (int k = 0; k < Step; k++)
            {
                int x = s.bx + s.dir * k;
                if (x < 1 || x > 22) errs.Add("tangga " + i + ": jubin x=" + x + " terkeluar dinding");
                int key = Key(x, Step * s.from + 1 + k);
                if (seen.ContainsKey(key)) errs.Add("tangga " + i + " bertindih tangga " + seen[key]);
                seen[key] = i;
            }
            int[] holeXs = { s.TopTileX - 2 * s.dir, s.TopTileX - s.dir };
            foreach (int hx in holeXs)
            {
                for (int r = Step * (s.from + 1) + 1; r <= Step * (s.from + 1) + 2; r++)
                    if (IsSolid(hx, r)) errs.Add("tangga " + i + ": ruang kepala di atas lubang x=" + hx + " baris " + r + " tersekat");
            }
        }

        // nod
        List<VNode> all = new List<VNode>();
        foreach (NodeDef n in nodes)
        {
            VNode v = new VNode();
            v.name = n.name; v.x = n.x; v.y = FloorY(n.floor); v.exit = n.exit; v.spawn = n.spawn; v.kind = 0;
            if (n.floor < 0 || n.floor >= floors) errs.Add("nod " + n.name + ": tingkat " + n.floor + " tiada");
            all.Add(v);
        }
        for (int i = 0; i < stairs.Count; i++)
        {
            Vector2 b = StairBottomNode(stairs[i]);
            Vector2 t = StairTopNode(stairs[i]);
            all.Add(new VNode { name = StairBottomName(i), x = b.x, y = b.y, kind = 1 });
            all.Add(new VNode { name = StairTopName(i), x = t.x, y = t.y, kind = 2 });
        }

        HashSet<string> names = new HashSet<string>();
        foreach (VNode v in all)
        {
            if (!names.Add(v.name)) errs.Add("nama nod berganda: " + v.name);
            if (v.x < 1f || v.x > 22f) errs.Add("nod " + v.name + " x=" + v.x + " terlalu dekat dinding");
            if (v.kind == 0)
            {
                for (int tx = Mathf.FloorToInt(v.x - 0.3f); tx <= Mathf.FloorToInt(v.x + 0.3f); tx++)
                    for (int ty = Mathf.FloorToInt(v.y + 0.05f); ty < Mathf.CeilToInt(v.y + 2f); ty++)
                        if (IsSolid(tx, ty)) errs.Add("nod " + v.name + " (" + v.x + "," + v.y + "): ruang kepala tersekat oleh jubin (" + tx + "," + ty + ")");
            }
        }

        // pautan (sama seperti WaypointNode.BuildLinks) dan semakan lubang
        Dictionary<string, HashSet<string>> links = new Dictionary<string, HashSet<string>>();
        foreach (VNode v in all) links[v.name] = new HashSet<string>();
        for (int a = 0; a < all.Count; a++)
        {
            for (int b = a + 1; b < all.Count; b++)
            {
                VNode na = all[a], nb = all[b];
                if (Mathf.Abs(na.y - nb.y) < 0.1f && Mathf.Abs(na.x - nb.x) <= AutoLinkMaxDx)
                {
                    float lo = Mathf.Min(na.x, nb.x), hi = Mathf.Max(na.x, nb.x);
                    int row = Mathf.RoundToInt(na.y) - 1;
                    if (holes.ContainsKey(row))
                        foreach (int hx in holes[row])
                            if (lo < hx + 1 && hi > hx) errs.Add("pautan " + na.name + "-" + nb.name + " melintasi lubang x=" + hx);
                    links[na.name].Add(nb.name);
                    links[nb.name].Add(na.name);
                }
            }
        }
        for (int i = 0; i < stairs.Count; i++)
        {
            links[StairBottomName(i)].Add(StairTopName(i));
            links[StairTopName(i)].Add(StairBottomName(i));
        }

        // capaian ke pintu keluar
        List<string> exits = new List<string>();
        foreach (VNode v in all) if (v.exit) exits.Add(v.name);
        if (exits.Count == 0) errs.Add("tiada pintu keluar");
        foreach (VNode v in all)
        {
            if (!Reaches(v.name, exits, links)) errs.Add("nod " + v.name + (v.spawn ? " (spawn)" : "") + " tak dapat sampai ke pintu keluar");
        }

        // perabot
        foreach (PropDef p in props)
        {
            Vector2 size = SizeOf(p.name);
            float x0 = p.x - size.x / 2f, x1 = p.x + size.x / 2f;
            if (x0 < 0.99f || x1 > 23.01f) errs.Add("perabot " + p.name + " x=" + p.x + " terkeluar dinding");
            for (int tx = Mathf.FloorToInt(x0 + 0.02f); tx < Mathf.CeilToInt(x1 - 0.02f); tx++)
                for (int ty = Mathf.FloorToInt(p.y + 0.02f); ty < Mathf.CeilToInt(p.y + size.y - 0.02f); ty++)
                    if (IsSolid(tx, ty)) errs.Add("perabot " + p.name + " (" + p.x + "," + p.y + ") bertindih jubin (" + tx + "," + ty + ")");

            float baseRow = p.y - 1f;
            int r = Mathf.RoundToInt(baseRow);
            if (!p.onProp && Mathf.Abs(baseRow - r) < 0.02f && r % Step == 0 && r / Step < floors)
            {
                for (int tx = Mathf.FloorToInt(x0 + 0.02f); tx < Mathf.CeilToInt(x1 - 0.02f); tx++)
                    if (!IsSolid(tx, r)) errs.Add("perabot " + p.name + " (" + p.x + "," + p.y + ") tak bersandar penuh: kosong di x=" + tx);
            }
        }
        return errs;
    }

    static bool Reaches(string start, List<string> goals, Dictionary<string, HashSet<string>> links)
    {
        Queue<string> q = new Queue<string>();
        HashSet<string> seen = new HashSet<string>();
        q.Enqueue(start); seen.Add(start);
        while (q.Count > 0)
        {
            string c = q.Dequeue();
            if (goals.Contains(c)) return true;
            foreach (string nb in links[c])
                if (seen.Add(nb)) q.Enqueue(nb);
        }
        return false;
    }
}
#endif
