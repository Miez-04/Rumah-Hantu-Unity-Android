#if UNITY_EDITOR
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Pustaka denah rumah. DIJANA daripada model yang telah disahkan (setiap denah dan versi cerminnya lulus pengesah).
/// Untuk menambah rumah baharu: salin satu kaedah, ubah data, tambah ke All(), kemudian jalankan Ghost > 6 - Check Houses.
/// </summary>
public static class HouseLibrary
{
    // Semua rumah beserta versi cermin masing-masing.
    public static List<HouseLayout> All()
    {
        List<HouseLayout> list = new List<HouseLayout>();
        foreach (HouseLayout h in Bases())
        {
            list.Add(h);
            list.Add(h.Mirror());
        }
        return list;
    }

    public static List<HouseLayout> Bases()
    {
        List<HouseLayout> list = new List<HouseLayout>();
        list.Add(Klasik());
        list.Add(Kampung());
        list.Add(Menara());
        list.Add(Padat());
        return list;
    }

    // Banglo Klasik: 3 tingkat
    public static HouseLayout Klasik()
    {
        HouseLayout h = new HouseLayout("klasik", "Banglo Klasik", 3, new Vector2(16.0f, 4.0f));
        h.AddStair(0, 3, 1);
        h.AddStair(1, 20, -1);
        h.AddNode("G1", 8.0f, 0, false, true);
        h.AddNode("G2", 13.0f, 0, false, true);
        h.AddNode("G3", 17.5f, 0, false, true);
        h.AddNode("G_Exit", 21.0f, 0, true, false);
        h.AddNode("M1", 14.0f, 1, false, true);
        h.AddNode("M2", 17.5f, 1, false, true);
        h.AddNode("T1", 3.0f, 2, false, true);
        h.AddNode("T2", 7.5f, 2, false, true);
        h.AddNode("T3", 11.0f, 2, false, true);
        h.AddProp("grandfather_clock", 1.56f, 1.0f, false);
        h.AddProp("couch", 12.56f, 1.0f, false);
        h.AddProp("doll", 12.375f, 2.31f, true);
        h.AddProp("table", 18.06f, 1.0f, false);
        h.AddProp("vase", 18.1f, 2.3f, true);
        h.AddProp("chair", 20.56f, 1.0f, false);
        h.AddProp("bookshelf", 2.06f, 8.0f, false);
        h.AddProp("picture_frame", 5.56f, 11.375f, false);
        h.AddProp("picture_frame", 9.56f, 11.375f, false);
        h.AddProp("mirror", 12.56f, 8.81f, false);
        h.AddProp("floor_lamp", 14.44f, 8.0f, false);
        h.AddProp("grandfather_clock", 21.56f, 8.0f, false);
        h.AddProp("chandelier", 10.06f, 18.75f, false);
        h.AddProp("table", 12.06f, 15.0f, false);
        h.AddProp("vase", 12.375f, 16.125f, true);
        h.AddProp("chair", 14.56f, 15.0f, false);
        h.AddProp("candle", 6.22f, 15.0f, false);
        h.AddProp("bottle", 7.22f, 15.0f, false);
        h.AddProp("picture_frame", 6.56f, 18.375f, false);
        h.AddDeco("window", 12.06f, 2.875f);
        h.AddDeco("window", 18.06f, 2.875f);
        h.AddDeco("window", 4.06f, 9.875f);
        h.AddDeco("window", 12.06f, 9.875f);
        h.AddDeco("window", 4.06f, 16.875f);
        h.AddDeco("window", 19.06f, 16.875f);
        h.AddDeco("door_closed", 21.81f, 1.0f);
        h.AddDeco("door_closed", 21.81f, 15.0f);
        return h;
    }

    // Rumah Kampung: 2 tingkat
    public static HouseLayout Kampung()
    {
        HouseLayout h = new HouseLayout("kampung", "Rumah Kampung", 2, new Vector2(16.0f, 4.0f));
        h.AddStair(0, 20, -1);
        h.AddNode("G1", 17.0f, 0, false, true);
        h.AddNode("G2", 12.0f, 0, false, true);
        h.AddNode("G3", 7.0f, 0, false, true);
        h.AddNode("G_Exit", 2.0f, 0, true, false);
        h.AddNode("U1", 10.0f, 1, false, true);
        h.AddNode("U2", 6.0f, 1, false, true);
        h.AddNode("U3", 2.5f, 1, false, true);
        h.AddProp("bookshelf", 4.8f, 1.0f, false);
        h.AddProp("grandfather_clock", 7.06f, 1.0f, false);
        h.AddProp("table", 10.06f, 1.0f, false);
        h.AddProp("vase", 10.1f, 2.3f, true);
        h.AddProp("couch", 13.6f, 1.0f, false);
        h.AddProp("doll", 13.4f, 2.31f, true);
        h.AddProp("chair", 16.4f, 1.0f, false);
        h.AddProp("bookshelf", 3.06f, 8.0f, false);
        h.AddProp("picture_frame", 5.56f, 11.375f, false);
        h.AddProp("mirror", 9.56f, 8.81f, false);
        h.AddProp("floor_lamp", 12.06f, 8.0f, false);
        h.AddProp("chandelier", 7.56f, 11.75f, false);
        h.AddProp("candle", 7.9f, 8.0f, false);
        h.AddProp("bottle", 8.5f, 8.0f, false);
        h.AddProp("chair", 19.06f, 8.0f, false);
        h.AddProp("grandfather_clock", 21.56f, 8.0f, false);
        h.AddDeco("door_closed", 2.19f, 1.0f);
        h.AddDeco("window", 9.06f, 2.875f);
        h.AddDeco("window", 15.06f, 2.875f);
        h.AddDeco("window", 5.06f, 9.875f);
        h.AddDeco("window", 12.06f, 9.875f);
        h.AddDeco("window", 19.06f, 9.875f);
        return h;
    }

    // Menara Empat Tingkat: 4 tingkat
    public static HouseLayout Menara()
    {
        HouseLayout h = new HouseLayout("menara", "Menara Empat Tingkat", 4, new Vector2(16.0f, 4.0f));
        h.AddStair(0, 3, 1);
        h.AddStair(1, 20, -1);
        h.AddStair(2, 3, 1);
        h.AddNode("G1", 8.0f, 0, false, true);
        h.AddNode("G2", 13.0f, 0, false, true);
        h.AddNode("G3", 17.5f, 0, false, true);
        h.AddNode("G_Exit", 21.0f, 0, true, false);
        h.AddNode("M1", 14.0f, 1, false, true);
        h.AddNode("M2", 17.5f, 1, false, true);
        h.AddNode("T2", 7.5f, 2, false, true);
        h.AddNode("T3", 11.0f, 2, false, true);
        h.AddNode("P1", 14.0f, 3, false, true);
        h.AddNode("P2", 17.5f, 3, false, true);
        h.AddNode("P3", 20.5f, 3, false, true);
        h.AddProp("grandfather_clock", 1.56f, 1.0f, false);
        h.AddProp("couch", 12.56f, 1.0f, false);
        h.AddProp("doll", 12.375f, 2.31f, true);
        h.AddProp("table", 18.06f, 1.0f, false);
        h.AddProp("vase", 18.1f, 2.3f, true);
        h.AddProp("chair", 20.56f, 1.0f, false);
        h.AddProp("bookshelf", 2.06f, 8.0f, false);
        h.AddProp("picture_frame", 5.56f, 11.375f, false);
        h.AddProp("picture_frame", 9.56f, 11.375f, false);
        h.AddProp("mirror", 12.56f, 8.81f, false);
        h.AddProp("floor_lamp", 14.44f, 8.0f, false);
        h.AddProp("grandfather_clock", 21.56f, 8.0f, false);
        h.AddProp("chandelier", 12.56f, 18.75f, false);
        h.AddProp("table", 12.06f, 15.0f, false);
        h.AddProp("vase", 12.375f, 16.125f, true);
        h.AddProp("chair", 14.56f, 15.0f, false);
        h.AddProp("candle", 6.22f, 15.0f, false);
        h.AddProp("bottle", 7.22f, 15.0f, false);
        h.AddProp("picture_frame", 19.56f, 18.375f, false);
        h.AddProp("bookshelf", 2.06f, 22.0f, false);
        h.AddProp("picture_frame", 5.56f, 25.375f, false);
        h.AddProp("table", 13.06f, 22.0f, false);
        h.AddProp("vase", 13.1f, 23.3f, true);
        h.AddProp("chair", 15.6f, 22.0f, false);
        h.AddProp("floor_lamp", 17.44f, 22.0f, false);
        h.AddProp("mirror", 19.56f, 22.81f, false);
        h.AddProp("chandelier", 14.06f, 25.75f, false);
        h.AddDeco("window", 12.06f, 2.875f);
        h.AddDeco("window", 18.06f, 2.875f);
        h.AddDeco("window", 4.06f, 9.875f);
        h.AddDeco("window", 12.06f, 9.875f);
        h.AddDeco("window", 4.06f, 16.875f);
        h.AddDeco("window", 19.06f, 16.875f);
        h.AddDeco("window", 12.06f, 23.875f);
        h.AddDeco("window", 20.06f, 23.875f);
        h.AddDeco("door_closed", 21.81f, 1.0f);
        h.AddDeco("door_closed", 21.81f, 15.0f);
        return h;
    }

    // Banglo Padat: 3 tingkat
    public static HouseLayout Padat()
    {
        HouseLayout h = new HouseLayout("padat", "Banglo Padat", 3, new Vector2(16.0f, 4.0f));
        h.AddStair(0, 5, 1);
        h.AddStair(1, 17, -1);
        h.AddNode("G0", 2.5f, 0, false, true);
        h.AddNode("G1", 9.0f, 0, false, true);
        h.AddNode("G2", 14.0f, 0, false, true);
        h.AddNode("G3", 18.0f, 0, false, true);
        h.AddNode("G_Exit", 21.0f, 0, true, false);
        h.AddNode("M1", 15.0f, 1, false, true);
        h.AddNode("M2", 21.0f, 1, false, true);
        h.AddNode("T1", 3.5f, 2, false, true);
        h.AddNode("T2", 7.5f, 2, false, true);
        h.AddProp("grandfather_clock", 1.56f, 1.0f, false);
        h.AddProp("chair", 3.5f, 1.0f, false);
        h.AddProp("table", 9.2f, 1.0f, false);
        h.AddProp("vase", 9.2f, 2.3f, true);
        h.AddProp("couch", 14.0f, 1.0f, false);
        h.AddProp("doll", 13.8f, 2.31f, true);
        h.AddProp("floor_lamp", 19.44f, 1.0f, false);
        h.AddProp("bookshelf", 2.06f, 8.0f, false);
        h.AddProp("picture_frame", 5.56f, 11.375f, false);
        h.AddProp("picture_frame", 7.56f, 11.375f, false);
        h.AddProp("grandfather_clock", 12.56f, 8.0f, false);
        h.AddProp("floor_lamp", 13.44f, 8.0f, false);
        h.AddProp("chair", 19.5f, 8.0f, false);
        h.AddProp("chandelier", 6.56f, 18.75f, false);
        h.AddProp("table", 7.0f, 15.0f, false);
        h.AddProp("vase", 7.0f, 16.3f, true);
        h.AddProp("candle", 4.0f, 15.0f, false);
        h.AddProp("bottle", 4.8f, 15.0f, false);
        h.AddProp("picture_frame", 10.0f, 18.375f, false);
        h.AddProp("chair", 19.0f, 15.0f, false);
        h.AddProp("mirror", 16.5f, 15.81f, false);
        h.AddProp("grandfather_clock", 17.5f, 15.0f, false);
        h.AddDeco("window", 12.06f, 2.875f);
        h.AddDeco("window", 19.06f, 2.875f);
        h.AddDeco("window", 4.06f, 9.875f);
        h.AddDeco("window", 18.06f, 16.875f);
        h.AddDeco("window", 10.06f, 16.875f);
        h.AddDeco("door_closed", 21.81f, 1.0f);
        h.AddDeco("door_closed", 21.81f, 15.0f);
        return h;
    }
}
#endif
