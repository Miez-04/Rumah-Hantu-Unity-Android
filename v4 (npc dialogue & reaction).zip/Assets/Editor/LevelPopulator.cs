#if UNITY_EDITOR
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

// Menu: Ghost > 2 - Populate Level
// Mencipta perabot, tingkap, pintu, titik laluan, hantu, prefab manusia, GameManager dan menetapkan kamera.
// Menu ini memasang Banglo Klasik (rumah asal). Populate(HouseLayout) memasang mana-mana denah dalam HouseLibrary.
// Menjalankannya semula memadam dan mencipta semula "Level", "Ghost" dan "GameManager".
public static class LevelPopulator
{
    [MenuItem("Ghost/2 - Populate Level (props, waypoints, ghost, camera, manager)")]
    public static void Populate()
    {
        Populate(HouseLibrary.Klasik());
    }

    public static bool Populate(HouseLayout layout)
    {
        int furnitureLayer = EnsureLayer("Furniture");
        if (furnitureLayer < 0) return false;

        DestroyIfExists("Level");
        DestroyIfExists("Ghost");
        DestroyIfExists("GameManager");

        GameObject root = new GameObject("Level");
        HouseInfo info = root.AddComponent<HouseInfo>();
        info.title = layout.title;
        info.floors = layout.floors;

        // ---- props ----
        Transform propsRoot = new GameObject("Props").transform;
        propsRoot.SetParent(root.transform, false);
        Sprite eyesSprite = LoadPropSprite("eyes");

        foreach (HouseLayout.DecoDef d in layout.decos)
        {
            Sprite sp = LoadPropSprite(d.name);
            if (sp == null)
            {
                Debug.LogWarning("LevelPopulator: sprite '" + d.name + "' tidak dijumpai. Letak PNG perabot dalam Assets/Art/Props/.");
                continue;
            }
            GameObject go = new GameObject(d.name);
            go.transform.SetParent(propsRoot, false);
            go.transform.position = new Vector3(d.x, d.y, 0f);
            SpriteRenderer dsr = go.AddComponent<SpriteRenderer>();
            dsr.sprite = sp;
            dsr.sortingOrder = 1;
            dsr.flipX = layout.mirrored; // pintu dan tingkap turut dicerminkan
        }

        foreach (HouseLayout.PropDef p in layout.props)
        {
            Sprite sp = LoadPropSprite(p.name);
            if (sp == null)
            {
                Debug.LogWarning("LevelPopulator: sprite '" + p.name + "' tidak dijumpai. Letak PNG perabot dalam Assets/Art/Props/.");
                continue;
            }

            float mass; bool breakable; bool pinned;
            HouseLayout.PropDefaults(p.name, out mass, out breakable, out pinned);

            GameObject go = new GameObject(p.name);
            go.transform.SetParent(propsRoot, false);
            go.transform.position = new Vector3(p.x, p.y, 0f);
            go.layer = furnitureLayer;

            // sprite berada pada anak supaya boleh mengempis, meregang dan bergoyang tanpa menyentuh pelanggar fizik
            GameObject vis = new GameObject("Visual");
            vis.transform.SetParent(go.transform, false);
            SpriteRenderer sr = vis.AddComponent<SpriteRenderer>();
            sr.sprite = sp;
            sr.sortingOrder = 3;

            Rigidbody2D rb = go.AddComponent<Rigidbody2D>();
            rb.mass = mass;
            rb.gravityScale = 2f;
            rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;
            rb.interpolation = RigidbodyInterpolation2D.Interpolate;

            BoxCollider2D box = go.AddComponent<BoxCollider2D>();
            box.size = sp.bounds.size;
            box.offset = sp.bounds.center;

            Rig rig = RigFor(p.name);
            Possessable po = go.AddComponent<Possessable>();
            po.pinnedUntilPossessed = pinned;
            po.breakable = breakable || pinned;
            po.special = rig.special;
            po.specialEnergy = rig.energy;
            po.moveSpeed = rig.speed;
            po.jumpSpeed = rig.jump;
            po.hopWalk = rig.hop;
            po.breakSpeed = rig.breakSpeed;
            po.shardCount = rig.shards;
            po.breakSfx = rig.breakSfx;
            po.idleSprite = sp;
            po.walkFrames = LoadWalkFrames(p.name);
            po.eyesSprite = eyesSprite;
        }

        // ---- waypoints ----
        Transform wpRoot = new GameObject("Waypoints").transform;
        wpRoot.SetParent(root.transform, false);
        foreach (HouseLayout.NodeDef n in layout.nodes)
        {
            WaypointNode wn = MakeNode(wpRoot, n.name, n.x, HouseLayout.FloorY(n.floor));
            wn.isExit = n.exit;
            wn.spawnable = n.spawn;
        }
        for (int i = 0; i < layout.stairs.Count; i++)
        {
            Vector2 bp = layout.StairBottomNode(layout.stairs[i]);
            Vector2 tp = layout.StairTopNode(layout.stairs[i]);
            WaypointNode bot = MakeNode(wpRoot, layout.StairBottomName(i), bp.x, bp.y);
            WaypointNode topNode = MakeNode(wpRoot, layout.StairTopName(i), tp.x, tp.y);
            bot.spawnable = false;
            topNode.spawnable = false;
            bot.extraLinks = new WaypointNode[] { topNode }; // pautan dua hala: bawah tangga <-> atas tangga
        }

        // ---- camera ----
        Camera cam = Camera.main;
        if (cam == null)
        {
            GameObject cg = new GameObject("Main Camera");
            cg.tag = "MainCamera";
            cam = cg.AddComponent<Camera>();
            cg.AddComponent<AudioListener>();
        }
        cam.orthographic = true;
        cam.orthographicSize = 6.75f;
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = new Color(0.055f, 0.063f, 0.14f);
        cam.transform.position = new Vector3(12f, layout.CamMinY, -10f);

        // ---- ghost ----
        GameObject ghost = new GameObject("Ghost");
        ghost.transform.position = new Vector3(layout.ghostSpawn.x, layout.ghostSpawn.y, 0f);
        GameObject ghostVis = new GameObject("Visual");
        ghostVis.transform.SetParent(ghost.transform, false);
        SpriteRenderer gsr = ghostVis.AddComponent<SpriteRenderer>();
        gsr.sortingOrder = 10;
        ghostVis.AddComponent<SpriteSheetAnimator>();
        GhostController gc = ghost.AddComponent<GhostController>();
        gc.visual = ghostVis.transform;
        gc.furnitureMask = 1 << furnitureLayer;
        gc.cam = cam;
        gc.flightMax = new Vector2(23.2f, layout.FlightMaxY); // had terbang ikut ketinggian rumah

        CameraFollow2D follow = cam.GetComponent<CameraFollow2D>();
        if (follow == null) follow = cam.gameObject.AddComponent<CameraFollow2D>();
        follow.target = ghost.transform;
        follow.fixedX = 12f;
        follow.minY = layout.CamMinY;
        follow.maxY = layout.CamMaxY;
        follow.orthographicSize = 6.75f;

        // ---- human prefab + game manager ----
        if (!AssetDatabase.IsValidFolder("Assets/Prefabs")) AssetDatabase.CreateFolder("Assets", "Prefabs");
        GameObject human = new GameObject("Human");
        SpriteRenderer hsr = human.AddComponent<SpriteRenderer>();
        hsr.sortingOrder = 5;
        human.AddComponent<SpriteSheetAnimator>();
        human.AddComponent<HumanAI>();
        GameObject prefab = PrefabUtility.SaveAsPrefabAsset(human, "Assets/Prefabs/Human.prefab");
        Object.DestroyImmediate(human);

        GameObject gmGo = new GameObject("GameManager");
        GameManager gm = gmGo.AddComponent<GameManager>();
        gm.humanPrefab = prefab;

        AddSceneToBuildSettings();
        EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
        Debug.Log("LevelPopulator: " + layout.title + " siap. Simpan scene (Ctrl+S) dan tekan Play.");
        return true;
    }

    static WaypointNode MakeNode(Transform parent, string name, float x, float y)
    {
        GameObject g = new GameObject(name);
        g.transform.SetParent(parent, false);
        g.transform.position = new Vector3(x, y, 0f);
        return g.AddComponent<WaypointNode>();
    }

    struct Rig
    {
        public HauntKind special;
        public float energy, speed, jump, breakSpeed;
        public bool hop;
        public int shards;
        public string breakSfx;

        public Rig(HauntKind special, float energy, float speed, float jump, bool hop, float breakSpeed = 8f, int shards = 10, string breakSfx = "glass_break")
        {
            this.special = special;
            this.energy = energy;
            this.speed = speed;
            this.jump = jump;
            this.hop = hop;
            this.breakSpeed = breakSpeed;
            this.shards = shards;
            this.breakSfx = breakSfx;
        }
    }

    static Rig RigFor(string n)
    {
        switch (n)
        {
            case "table": return new Rig(HauntKind.Stomp, 20f, 3.2f, 9f, false);
            case "chair": return new Rig(HauntKind.Charge, 15f, 5f, 9.5f, false);
            case "couch": return new Rig(HauntKind.Pounce, 22f, 2.4f, 8f, false);
            case "doll": return new Rig(HauntKind.Giggle, 14f, 3.6f, 9f, false);
            case "bookshelf": return new Rig(HauntKind.Topple, 25f, 1.6f, 5f, true);
            case "floor_lamp": return new Rig(HauntKind.Flash, 12f, 3.5f, 9f, true, 9f, 8);
            case "grandfather_clock": return new Rig(HauntKind.Gong, 18f, 2f, 6f, true);
            case "vase": return new Rig(HauntKind.Throw, 8f, 3.5f, 7f, true, 8f, 10);
            case "bottle": return new Rig(HauntKind.Throw, 8f, 4f, 7f, true, 8f, 8);
            case "candle": return new Rig(HauntKind.Throw, 6f, 3.5f, 7f, true);
            case "mirror": return new Rig(HauntKind.Drop, 15f, 0f, 0f, false, 8f, 14);
            case "picture_frame": return new Rig(HauntKind.Drop, 12f, 0f, 0f, false, 8f, 6);
            case "chandelier": return new Rig(HauntKind.Drop, 25f, 0f, 0f, false, 8f, 20, "crash_big");
            default: return new Rig(HauntKind.Stomp, 18f, 3.5f, 9f, true);
        }
    }

    static Sprite[] LoadWalkFrames(string n)
    {
        List<Sprite> frames = new List<Sprite>();
        for (int i = 0; i < 4; i++)
        {
            Sprite f = LoadPropSprite(n + "_walk_" + i);
            if (f != null) frames.Add(f);
        }
        return frames.Count == 4 ? frames.ToArray() : null;
    }

    static void DestroyIfExists(string objName)
    {
        GameObject go = GameObject.Find(objName);
        while (go != null)
        {
            Object.DestroyImmediate(go);
            go = GameObject.Find(objName);
        }
    }

    static Sprite LoadPropSprite(string spriteName)
    {
        string[] guids = AssetDatabase.FindAssets(spriteName + " t:Texture2D");
        foreach (string g in guids)
        {
            string path = AssetDatabase.GUIDToAssetPath(g);
            if (Path.GetFileNameWithoutExtension(path) != spriteName) continue;
            EnsurePropImport(path);
            return AssetDatabase.LoadAssetAtPath<Sprite>(path);
        }
        return null;
    }

    // Sprite tunggal, 16 PPU, penapis titik, tanpa mampatan, pivot di tengah bawah.
    static void EnsurePropImport(string path)
    {
        TextureImporter ti = AssetImporter.GetAtPath(path) as TextureImporter;
        if (ti == null) return;

        TextureImporterSettings s = new TextureImporterSettings();
        ti.ReadTextureSettings(s);
        bool ok = ti.textureType == TextureImporterType.Sprite
                  && ti.spriteImportMode == SpriteImportMode.Single
                  && Mathf.Approximately(ti.spritePixelsPerUnit, 16f)
                  && ti.filterMode == FilterMode.Point
                  && ti.textureCompression == TextureImporterCompression.Uncompressed
                  && s.spriteAlignment == (int)SpriteAlignment.BottomCenter;
        if (ok) return;

        ti.textureType = TextureImporterType.Sprite;
        ti.spriteImportMode = SpriteImportMode.Single;
        ti.spritePixelsPerUnit = 16f;
        ti.filterMode = FilterMode.Point;
        ti.textureCompression = TextureImporterCompression.Uncompressed;
        ti.ReadTextureSettings(s);
        s.spriteAlignment = (int)SpriteAlignment.BottomCenter;
        ti.SetTextureSettings(s);
        ti.SaveAndReimport();
    }

    static int EnsureLayer(string layerName)
    {
        int existing = LayerMask.NameToLayer(layerName);
        if (existing >= 0) return existing;

        Object[] assets = AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/TagManager.asset");
        if (assets == null || assets.Length == 0)
        {
            Debug.LogError("LevelPopulator: tak dapat buka TagManager. Cipta layer bernama '" + layerName + "' dalam Project Settings > Tags and Layers, kemudian jalankan menu ini semula.");
            return -1;
        }

        SerializedObject tagManager = new SerializedObject(assets[0]);
        SerializedProperty layers = tagManager.FindProperty("layers");
        for (int i = 8; i < layers.arraySize; i++)
        {
            SerializedProperty el = layers.GetArrayElementAtIndex(i);
            if (string.IsNullOrEmpty(el.stringValue))
            {
                el.stringValue = layerName;
                tagManager.ApplyModifiedProperties();
                return i;
            }
        }

        Debug.LogError("LevelPopulator: tiada slot layer kosong untuk '" + layerName + "'. Kosongkan satu dalam Tags and Layers.");
        return -1;
    }

    static void AddSceneToBuildSettings()
    {
        Scene scene = SceneManager.GetActiveScene();
        if (string.IsNullOrEmpty(scene.path))
        {
            Debug.LogWarning("LevelPopulator: scene belum disimpan. Simpan (File > Save As) dan tambah ke Build Settings, atau butang Cuba Lagi tak akan berfungsi.");
            return;
        }

        List<EditorBuildSettingsScene> list = new List<EditorBuildSettingsScene>(EditorBuildSettings.scenes);
        foreach (EditorBuildSettingsScene s in list)
            if (s.path == scene.path) return;
        list.Add(new EditorBuildSettingsScene(scene.path, true));
        EditorBuildSettings.scenes = list.ToArray();
    }
}
#endif
