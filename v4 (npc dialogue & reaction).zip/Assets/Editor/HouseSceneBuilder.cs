#if UNITY_EDITOR
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>
/// Menu: Ghost > 5 - Build All Houses
///   Membina satu scene untuk setiap rumah dalam HouseLibrary (termasuk versi cermin) dalam Assets/Scenes/Houses/.
///   Setiap scene ialah salinan Assets/Scenes/Main.unity (supaya Global Light 2D, pasca-pemprosesan dan tetapan lain
///   kekal sama), kemudian tilemap, perabot, titik laluan, hantu dan kamera dibina semula mengikut denah.
///   Scene ditambah ke Build Settings. Selamat dijalankan berulang kali (scene lama diganti).
///
/// Menu: Ghost > 6 - Check Houses
///   Menjalankan pengesah pada semua denah tanpa mengubah scene. Gunakan selepas menyunting HouseLibrary.
/// </summary>
public static class HouseSceneBuilder
{
    const string SourceScene = "Assets/Scenes/Main.unity";
    const string Folder = "Assets/Scenes/Houses";

    [MenuItem("Ghost/5 - Build All Houses")]
    public static void BuildAll()
    {
        if (!File.Exists(SourceScene))
        {
            EditorUtility.DisplayDialog("Build All Houses",
                "Scene sumber " + SourceScene + " tiada. Jalankan Ghost > 1 dan Ghost > 2 pada scene Main dan simpan sebagai Assets/Scenes/Main.unity dahulu.", "OK");
            return;
        }
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;

        string returnTo = SceneManager.GetActiveScene().path;
        if (!AssetDatabase.IsValidFolder("Assets/Scenes")) AssetDatabase.CreateFolder("Assets", "Scenes");
        if (!AssetDatabase.IsValidFolder(Folder)) AssetDatabase.CreateFolder("Assets/Scenes", "Houses");

        List<HouseLayout> all = HouseLibrary.All();
        List<string> built = new List<string>();
        List<string> failed = new List<string>();

        try
        {
            for (int i = 0; i < all.Count; i++)
            {
                HouseLayout layout = all[i];
                EditorUtility.DisplayProgressBar("Membina rumah", layout.title + " (" + (i + 1) + "/" + all.Count + ")", (float)i / all.Count);

                List<string> errs = layout.Validate();
                if (errs.Count > 0)
                {
                    failed.Add(layout.id);
                    Debug.LogError("[Rumah] " + layout.id + " ditolak oleh pengesah:\n - " + string.Join("\n - ", errs.ToArray()));
                    continue;
                }

                string path = Folder + "/" + layout.id + ".unity";
                if (File.Exists(path)) AssetDatabase.DeleteAsset(path);
                if (!AssetDatabase.CopyAsset(SourceScene, path))
                {
                    failed.Add(layout.id);
                    Debug.LogError("[Rumah] gagal menyalin scene untuk " + layout.id);
                    continue;
                }

                Scene sc = EditorSceneManager.OpenScene(path, OpenSceneMode.Single);
                bool ok = MansionBuilder.Build(layout) && LevelPopulator.Populate(layout);
                if (ok)
                {
                    EditorSceneManager.MarkSceneDirty(sc);
                    EditorSceneManager.SaveScene(sc);
                    built.Add(layout.id);
                }
                else
                {
                    failed.Add(layout.id);
                }
            }
        }
        finally
        {
            EditorUtility.ClearProgressBar();
        }

        if (!string.IsNullOrEmpty(returnTo)) EditorSceneManager.OpenScene(returnTo, OpenSceneMode.Single);
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();

        Debug.Log("[Rumah] Siap: " + built.Count + " rumah dibina (" + string.Join(", ", built.ToArray()) + ")." +
                  (failed.Count > 0 ? " GAGAL: " + string.Join(", ", failed.ToArray()) : "") +
                  " Tekan Play dari MainMenu dan setiap malam akan memilih rumah secara rawak.");
    }

    [MenuItem("Ghost/6 - Check Houses")]
    public static void CheckAll()
    {
        List<HouseLayout> all = HouseLibrary.All();
        int bad = 0;
        foreach (HouseLayout layout in all)
        {
            List<string> errs = layout.Validate();
            if (errs.Count == 0)
            {
                Debug.Log("[Rumah] " + layout.id + " (" + layout.floors + " tingkat): LULUS");
            }
            else
            {
                bad++;
                Debug.LogError("[Rumah] " + layout.id + " ada " + errs.Count + " masalah:\n - " + string.Join("\n - ", errs.ToArray()));
            }
        }
        Debug.Log("[Rumah] Semakan selesai: " + (all.Count - bad) + " / " + all.Count + " lulus.");
    }
}
#endif
