#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Tilemaps;

// Menu: Ghost > 1 - Build Mansion Tilemaps
// Membina tilemap rumah daripada mansion_tileset.png (mesti dihiris 16x16 dahulu).
// Menu ini membina Banglo Klasik (rumah asal). Build(HouseLayout) membina mana-mana denah dalam HouseLibrary.
// 1 jubin = 1 unit. Bangunan: x 0..24. Permukaan lantai: y = 7 * tingkat + 1.
public static class MansionBuilder
{
    const string TilesetName = "mansion_tileset";
    const string TileFolder = "Assets/Art/TileAssets";

    [MenuItem("Ghost/1 - Build Mansion Tilemaps")]
    public static void Build()
    {
        Build(HouseLibrary.Klasik());
    }

    public static bool Build(HouseLayout layout)
    {
        Tile[] t = LoadTiles();
        if (t == null) return false;

        int F = layout.floors;
        int top = HouseLayout.Step * F; // baris rasuk siling

        GameObject gridGo = GameObject.Find("MansionGrid");
        if (gridGo == null)
        {
            gridGo = new GameObject("MansionGrid");
            gridGo.AddComponent<Grid>();
        }
        // perabot dan titik laluan diletak dari (0,0), jadi grid mesti tepat di asal
        gridGo.transform.position = Vector3.zero;
        gridGo.transform.rotation = Quaternion.identity;
        gridGo.transform.localScale = Vector3.one;

        Tilemap walls = GetLayer(gridGo.transform, "Walls", 0);
        Tilemap decor = GetLayer(gridGo.transform, "Decor", 1);
        Tilemap solids = GetLayer(gridGo.transform, "Solids", 2);
        walls.ClearAllTiles();
        decor.ClearAllTiles();
        solids.ClearAllTiles();

        // ---- Walls (latar) ----
        for (int f = 0; f < F; f++)
        {
            int b = HouseLayout.Step * f;
            Fill(walls, t[0], 1, b + 4, 22, b + 6);               // kertas dinding
            Fill(walls, t[2], 1, b + 3, 22, b + 3);               // rel kerusi
            Fill(walls, t[3], 1, f == 0 ? 1 : b, 22, b + 2);      // wainscot (juga di belakang baris papak)

            // kertas dinding rosak: kedudukan berulang mengikut tingkat, dicerminkan jika rumah dicerminkan
            int[] dmg = (f % 3 == 0) ? new int[] { 9, 20 } : (f % 3 == 1) ? new int[] { 16, 3 } : new int[] { 5, 19 };
            foreach (int dx in dmg)
                walls.SetTile(new Vector3Int(layout.mirrored ? 23 - dx : dx, b + 5, 0), t[1]);
        }

        // ---- Solids (berlanggar) ----
        Fill(solids, t[7], 0, 0, 0, top);    // bata, dinding kiri
        Fill(solids, t[7], 23, 0, 23, top);  // bata, dinding kanan
        Fill(solids, t[6], 1, top, 22, top); // rasuk siling
        for (int f = 0; f < F; f++)
            for (int x = 1; x <= 22; x++)
                solids.SetTile(new Vector3Int(x, HouseLayout.Step * f, 0), t[x % 2 == 0 ? 4 : 5]);

        // lubang di atas setiap tangga
        foreach (HouseLayout.Stair s in layout.stairs)
        {
            int row = HouseLayout.Step * (s.from + 1);
            solids.SetTile(new Vector3Int(s.TopTileX - 2 * s.dir, row, 0), null);
            solids.SetTile(new Vector3Int(s.TopTileX - s.dir, row, 0), null);
        }

        // tangga: dir +1 menaik ke kanan (jubin 8), dir -1 menaik ke kiri (jubin 9)
        foreach (HouseLayout.Stair s in layout.stairs)
        {
            for (int k = 0; k < HouseLayout.Step; k++)
                solids.SetTile(new Vector3Int(s.bx + s.dir * k, HouseLayout.Step * s.from + 1 + k, 0), s.dir > 0 ? t[8] : t[9]);
        }

        // ---- Decor (tindihan) ----
        for (int f = 0; f < F; f++)
        {
            int y = HouseLayout.Step * f + 6;
            for (int x = 1; x <= 22; x++) decor.SetTile(new Vector3Int(x, y, 0), t[15]);
            decor.SetTile(new Vector3Int(1, y, 0), t[13]);
            decor.SetTile(new Vector3Int(22, y, 0), t[14]);
        }

        // ruang gelap di bawah tangga (separa telus supaya orang yang lalu di situ masih kelihatan)
        Tile dark = GetDarkTile();
        if (dark != null)
        {
            foreach (HouseLayout.Stair s in layout.stairs)
            {
                for (int i = 1; i < HouseLayout.Step; i++)
                    for (int yy = HouseLayout.Step * s.from + 1; yy <= HouseLayout.Step * s.from + i; yy++)
                        decor.SetTile(new Vector3Int(s.bx + s.dir * i, yy, 0), dark);
            }
        }

        // ---- Pelanggar pada Solids ----
        if (solids.GetComponent<TilemapCollider2D>() == null) solids.gameObject.AddComponent<TilemapCollider2D>();
        CompositeCollider2D comp = solids.GetComponent<CompositeCollider2D>();
        if (comp == null) comp = solids.gameObject.AddComponent<CompositeCollider2D>();
        comp.geometryType = CompositeCollider2D.GeometryType.Polygons;
        solids.GetComponent<TilemapCollider2D>().usedByComposite = true;
        Rigidbody2D rb = solids.GetComponent<Rigidbody2D>();
        if (rb != null) rb.bodyType = RigidbodyType2D.Static;

        EditorSceneManager.MarkSceneDirty(SceneManager.GetActiveScene());
        Selection.activeGameObject = gridGo;
        Debug.Log("MansionBuilder: " + layout.title + " siap (" + F + " tingkat). Seterusnya: Ghost > 2 - Populate Level.");
        return true;
    }

    static Tile GetDarkTile()
    {
        const string path = "Assets/Art/dark_tile.png";
        if (!AssetDatabase.IsValidFolder("Assets/Art")) AssetDatabase.CreateFolder("Assets", "Art");
        if (!AssetDatabase.IsValidFolder(TileFolder)) AssetDatabase.CreateFolder("Assets/Art", "TileAssets");

        if (!File.Exists(path))
        {
            Texture2D tex = new Texture2D(16, 16, TextureFormat.RGBA32, false);
            Color32 c = new Color32(22, 16, 28, 170);
            Color32[] px = new Color32[256];
            for (int i = 0; i < px.Length; i++) px[i] = c;
            tex.SetPixels32(px);
            File.WriteAllBytes(path, tex.EncodeToPNG());
            Object.DestroyImmediate(tex);
            AssetDatabase.ImportAsset(path);
        }

        TextureImporter ti = AssetImporter.GetAtPath(path) as TextureImporter;
        if (ti != null && (ti.textureType != TextureImporterType.Sprite || !Mathf.Approximately(ti.spritePixelsPerUnit, 16f)))
        {
            ti.textureType = TextureImporterType.Sprite;
            ti.spriteImportMode = SpriteImportMode.Single;
            ti.spritePixelsPerUnit = 16f;
            ti.filterMode = FilterMode.Point;
            ti.textureCompression = TextureImporterCompression.Uncompressed;
            ti.SaveAndReimport();
        }

        Sprite sp = AssetDatabase.LoadAssetAtPath<Sprite>(path);
        if (sp == null) return null;

        string assetPath = TileFolder + "/tile_dark.asset";
        Tile tile = AssetDatabase.LoadAssetAtPath<Tile>(assetPath);
        if (tile == null)
        {
            tile = ScriptableObject.CreateInstance<Tile>();
            AssetDatabase.CreateAsset(tile, assetPath);
        }
        tile.sprite = sp;
        tile.colliderType = Tile.ColliderType.None;
        EditorUtility.SetDirty(tile);
        return tile;
    }

    static void Fill(Tilemap m, TileBase tile, int x0, int y0, int x1, int y1)
    {
        for (int x = x0; x <= x1; x++)
            for (int y = y0; y <= y1; y++)
                m.SetTile(new Vector3Int(x, y, 0), tile);
    }

    static Tilemap GetLayer(Transform parent, string layerName, int order)
    {
        Transform c = parent.Find(layerName);
        GameObject go;
        if (c == null)
        {
            go = new GameObject(layerName);
            go.transform.SetParent(parent, false);
        }
        else
        {
            go = c.gameObject;
        }

        go.transform.localPosition = Vector3.zero;
        go.transform.localRotation = Quaternion.identity;
        go.transform.localScale = Vector3.one;

        Tilemap tm = go.GetComponent<Tilemap>();
        if (tm == null) tm = go.AddComponent<Tilemap>();
        TilemapRenderer tr = go.GetComponent<TilemapRenderer>();
        if (tr == null) tr = go.AddComponent<TilemapRenderer>();
        tr.sortingOrder = order;
        return tm;
    }

    // Mencipta aset Tile daripada tileset yang dihiris. Indeks ditentukan daripada kedudukan setiap sprite
    // (8 lajur x 2 baris, baris 0 di atas), jadi tak bergantung pada cara Unity menomborkan hirisan.
    static Tile[] LoadTiles()
    {
        string texPath = null;
        string[] guids = AssetDatabase.FindAssets(TilesetName + " t:Texture2D");
        foreach (string g in guids)
        {
            string p = AssetDatabase.GUIDToAssetPath(g);
            if (Path.GetFileNameWithoutExtension(p) == TilesetName)
            {
                texPath = p;
                break;
            }
        }
        if (texPath == null)
        {
            Debug.LogError("MansionBuilder: mansion_tileset.png tidak dijumpai. Letak dalam Assets/Art/Tiles/.");
            return null;
        }

        if (!AssetDatabase.IsValidFolder("Assets/Art")) AssetDatabase.CreateFolder("Assets", "Art");
        if (!AssetDatabase.IsValidFolder(TileFolder)) AssetDatabase.CreateFolder("Assets/Art", "TileAssets");

        Tile[] tiles = new Tile[16];
        Object[] all = AssetDatabase.LoadAllAssetsAtPath(texPath);
        foreach (Object o in all)
        {
            Sprite sp = o as Sprite;
            if (sp == null) continue;
            if (Mathf.RoundToInt(sp.rect.width) != 16 || Mathf.RoundToInt(sp.rect.height) != 16)
            {
                Debug.LogError("MansionBuilder: mansion_tileset.png belum dihiris 16x16. Guna Sprite Editor > Slice > Grid By Cell Size 16 x 16.");
                return null;
            }

            int col = Mathf.RoundToInt(sp.rect.x / 16f);
            int rowFromTop = Mathf.RoundToInt((sp.texture.height - sp.rect.yMax) / 16f);
            int idx = rowFromTop * 8 + col;
            if (idx < 0 || idx > 15) continue;

            string assetPath = TileFolder + "/tile_" + idx + ".asset";
            Tile tile = AssetDatabase.LoadAssetAtPath<Tile>(assetPath);
            if (tile == null)
            {
                tile = ScriptableObject.CreateInstance<Tile>();
                AssetDatabase.CreateAsset(tile, assetPath);
            }
            tile.sprite = sp;
            tile.colliderType = Tile.ColliderType.Sprite;
            EditorUtility.SetDirty(tile);
            tiles[idx] = tile;
        }
        AssetDatabase.SaveAssets();

        for (int i = 0; i < 16; i++)
        {
            if (tiles[i] == null)
            {
                Debug.LogError("MansionBuilder: jubin " + i + " tiada. Semak tileset dihiris 16 x 16 (16 sprite).");
                return null;
            }
        }
        return tiles;
    }
}
#endif
